package com.zelvyn.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ZelvynColorScheme = darkColorScheme(
    primary = AccentWarm,
    secondary = TextSecondary,
    tertiary = TextTertiary,
    background = CanvasDark,
    surface = SurfaceSubtle,
    surfaceVariant = SurfaceElevated,
    onPrimary = Color.Black,
    onSecondary = Color.White,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun ZelvynTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ZelvynColorScheme,
        content = content
    )
}
