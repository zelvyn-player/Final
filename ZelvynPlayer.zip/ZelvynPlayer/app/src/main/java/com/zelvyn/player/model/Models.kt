package com.zelvyn.player.model

import android.net.Uri

object SupportedLanguages {
    val ALL_LANGUAGES = listOf(
        "Auto Detect", "Spanish", "Hindi", "French", "German",
        "Japanese", "Urdu", "Bengali", "Mandarin", "Portuguese",
        "Arabic", "Russian", "Korean", "Turkish", "Italian",
        "Vietnamese", "English"
    )
}

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val resolution: String = "4K HDR",
    val hdrType: String? = "HDR10+",
    val year: String = "2024",
    val folder: String = "Movies",
    val lastPositionMs: Long = 0L
)

data class TranslationSegment(
    val sessionId: Long,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val originalText: String,
    val translatedText: String,
    val sourceLang: String,
    val targetLang: String
)

enum class TranslationStatus {
    IDLE, CAPTURING_AUDIO, TRANSLATING, ACTIVE, NO_SPEECH,
    ERROR_NO_INTERNET, ERROR_API_KEY, ERROR_GENERIC
}

enum class TranslationMode {
    VOICE, SUBTITLE, VOICE_AND_SUBTITLE
}

enum class SpeechStyle {
    NATURAL, CLEAR
}

enum class EqualizerPresetType {
    FLAT, POP, ROCK, BASS, CUSTOM
}

data class EqualizerBandState(
    val bandIndex: Int,
    val frequencyLabel: String,
    val gainDb: Float
)

data class PlaylistItem(
    val id: String,
    val name: String,
    val videoCount: Int
)

data class MediaTrackInfo(
    val groupIndex: Int,
    val trackIndex: Int,
    val id: String,
    val label: String,
    val language: String?,
    val isSelected: Boolean
)

data class UserPreferences(
    val geminiApiKey: String = "",
    val defaultTargetLang: String = "Spanish",
    val subtitleFontSizeSp: Int = 15,
    val subtitleBackgroundAlpha: Float = 0.88f,
    val hasCompletedOnboarding: Boolean = false
)
