package com.zelvyn.player.ui.privacy

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.ui.theme.*

@Composable
fun PrivacyPolicyScreen(
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasDark)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Privacy Policy",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize().padding(top = 8.dp, bottom = 24.dp)
        ) {
            item {
                Text(
                    text = "Last updated: August 2026",
                    fontSize = 12.sp,
                    color = TextTertiary
                )
            }

            item {
                PrivacySection(
                    title = "1. Local Playback & Media Storage",
                    body = "ZELVYN Player functions as an offline, on-device media player. Media stored on your device is queried locally via Android's MediaStore API and is never uploaded or tracked."
                )
            }

            item {
                PrivacySection(
                    title = "2. Audio Processing & Live Translation",
                    body = "When you explicitly activate Translation during playback, audio is intercepted directly from the media decoding pipeline. No microphone or system recording is used. Rolling audio chunks are sent via HTTPS to Google's Gemini API solely to generate text transcripts and translations."
                )
            }

            item {
                PrivacySection(
                    title = "3. Gemini API & Data Retention",
                    body = "Audio data sent to the Gemini API is processed ephemerally. No raw audio or transcripts are permanently saved on our servers. Processing conforms with Google Generative AI terms."
                )
            }

            item {
                PrivacySection(
                    title = "4. Permissions Requested",
                    body = "• READ_MEDIA_VIDEO / READ_EXTERNAL_STORAGE: Required to index and play local videos.\n• INTERNET & ACCESS_NETWORK_STATE: Required to send translation requests to the Gemini API endpoint."
                )
            }
        }
    }
}

@Composable
fun PrivacySection(
    title: String,
    body: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceSubtle)
            .padding(14.dp)
    ) {
        Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = body, fontSize = 12.sp, color = TextSecondary, lineHeight = 17.sp)
    }
}
