package com.zelvyn.player.ui.navigation

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.ui.theme.BorderSubtle
import com.zelvyn.player.ui.theme.SurfaceSubtle
import com.zelvyn.player.ui.theme.TextPrimary
import com.zelvyn.player.ui.theme.TextTertiary

enum class AppTab(val title: String, val icon: ImageVector) {
    LIBRARY("Library", Icons.Rounded.VideoLibrary),
    TRANSLATE("Translate", Icons.Rounded.Translate),
    SETTINGS("Settings", Icons.Rounded.Settings),
    PRIVACY("Privacy", Icons.Rounded.Security)
}

@Composable
fun ZelvynBottomNavBar(
    selectedTab: AppTab,
    onTabSelected: (AppTab) -> Unit
) {
    NavigationBar(
        containerColor = SurfaceSubtle,
        tonalElevation = 0.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp))
    ) {
        AppTab.entries.forEach { tab ->
            val isSelected = tab == selectedTab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.title,
                        tint = if (isSelected) TextPrimary else TextTertiary
                    )
                },
                label = {
                    Text(
                        text = tab.title,
                        fontSize = 11.sp,
                        color = if (isSelected) TextPrimary else TextTertiary
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = BorderSubtle
                )
            )
        }
    }
}
