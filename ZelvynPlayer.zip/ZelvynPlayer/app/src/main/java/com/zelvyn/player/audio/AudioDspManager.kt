package com.zelvyn.player.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import com.zelvyn.player.model.EqualizerBandState
import com.zelvyn.player.model.EqualizerPresetType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AudioDspManager {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    private val _bands = MutableStateFlow(
        listOf(
            EqualizerBandState(0, "60Hz", 0f),
            EqualizerBandState(1, "230Hz", 0f),
            EqualizerBandState(2, "910Hz", 0f),
            EqualizerBandState(3, "3.6kHz", 0f),
            EqualizerBandState(4, "14kHz", 0f)
        )
    )
    val bands: StateFlow<List<EqualizerBandState>> = _bands.asStateFlow()

    private val _currentPreset = MutableStateFlow(EqualizerPresetType.FLAT)
    val currentPreset: StateFlow<EqualizerPresetType> = _currentPreset.asStateFlow()

    fun bindAudioSession(audioSessionId: Int) {
        if (audioSessionId <= 0) return
        try {
            release()
            equalizer = Equalizer(0, audioSessionId).apply { enabled = true }
            bassBoost = BassBoost(0, audioSessionId).apply { enabled = true }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setBandGain(bandIndex: Int, gainDb: Float) {
        val currentList = _bands.value.toMutableList()
        if (bandIndex in currentList.indices) {
            currentList[bandIndex] = currentList[bandIndex].copy(gainDb = gainDb)
            _bands.value = currentList
            _currentPreset.value = EqualizerPresetType.CUSTOM

            equalizer?.let { eq ->
                try {
                    val minLevel = eq.bandLevelRange[0]
                    val maxLevel = eq.bandLevelRange[1]
                    val calculated = ((gainDb / 10f) * maxLevel).toInt().coerceIn(minLevel.toInt(), maxLevel.toInt())
                    eq.setBandLevel(bandIndex.toShort(), calculated.toShort())
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun applyPreset(preset: EqualizerPresetType) {
        _currentPreset.value = preset
        val gains = when (preset) {
            EqualizerPresetType.FLAT -> listOf(0f, 0f, 0f, 0f, 0f)
            EqualizerPresetType.POP -> listOf(-1f, 1f, 3f, 2f, -1f)
            EqualizerPresetType.ROCK -> listOf(4f, 2f, -1f, 2f, 4f)
            EqualizerPresetType.BASS -> listOf(6f, 4f, 1f, 0f, -1f)
            EqualizerPresetType.CUSTOM -> return
        }

        val updated = _bands.value.mapIndexed { index, band ->
            band.copy(gainDb = gains.getOrElse(index) { 0f })
        }
        _bands.value = updated
        updated.forEach { setBandGain(it.bandIndex, it.gainDb) }
    }

    fun release() {
        try {
            equalizer?.release()
            bassBoost?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        equalizer = null
        bassBoost = null
    }
}
