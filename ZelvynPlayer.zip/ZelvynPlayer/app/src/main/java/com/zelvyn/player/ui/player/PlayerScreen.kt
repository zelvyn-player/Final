package com.zelvyn.player.ui.player

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.audio.DeviceHardwareController
import com.zelvyn.player.data.ExoPlayerTrackManager
import com.zelvyn.player.model.TranslationSegment
import com.zelvyn.player.model.TranslationStatus
import com.zelvyn.player.model.VideoItem
import com.zelvyn.player.ui.theme.*

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    exoPlayer: ExoPlayer,
    video: VideoItem,
    activeSegment: TranslationSegment?,
    translationStatus: TranslationStatus,
    translationStatusMsg: String?,
    isTranslationActive: Boolean,
    audioDspManager: AudioDspManager,
    hardwareController: DeviceHardwareController,
    trackManager: ExoPlayerTrackManager,
    subtitleFontSizeSp: Int,
    subtitleBgAlpha: Float,
    isPiPMode: Boolean,
    onEnterPiP: () -> Unit,
    onBackPress: () -> Unit,
    onToggleLiveTranslation: () -> Unit
) {
    var controlsVisible by remember { mutableStateOf(true) }
    var isPlaying by remember { mutableStateOf(exoPlayer.isPlaying) }
    var isBuffering by remember { mutableStateOf(exoPlayer.playbackState == Player.STATE_BUFFERING) }
    var currentPos by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var showAdvancedSheet by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }

    var gestureVisible by remember { mutableStateOf(false) }
    var gestureIcon by remember { mutableStateOf(Icons.Rounded.VolumeUp) }
    var gestureLevel by remember { mutableFloatStateOf(0f) }
    var gestureTitle by remember { mutableStateOf("Volume") }

    var isScrubbing by remember { mutableStateOf(false) }
    var scrubTimeMs by remember { mutableLongStateOf(0L) }

    LaunchedEffect(exoPlayer) {
        while (true) {
            currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
            duration = exoPlayer.duration.coerceAtLeast(1L)
            isPlaying = exoPlayer.isPlaying
            isBuffering = exoPlayer.playbackState == Player.STATE_BUFFERING
            kotlinx.coroutines.delay(200)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isPiPMode) {
                if (!isPiPMode) {
                    detectTapGestures(
                        onTap = { controlsVisible = !controlsVisible },
                        onDoubleTap = { offset ->
                            val screenWidth = size.width
                            if (offset.x < screenWidth / 2) {
                                exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0))
                            } else {
                                exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(exoPlayer.duration))
                            }
                        }
                    )
                }
            }
            .pointerInput(isPiPMode) {
                if (!isPiPMode) {
                    detectDragGestures(
                        onDragStart = { gestureVisible = true },
                        onDragEnd = { gestureVisible = false },
                        onDragCancel = { gestureVisible = false },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val screenWidth = size.width
                            if (change.position.x > screenWidth / 2) {
                                hardwareController.adjustVolume(-dragAmount.y / 800f)
                                gestureIcon = Icons.Rounded.VolumeUp
                                gestureLevel = hardwareController.getVolumeLevel()
                                gestureTitle = "Volume ${(gestureLevel * 100).toInt()}%"
                            } else {
                                hardwareController.adjustBrightness(-dragAmount.y / 800f)
                                gestureIcon = Icons.Rounded.BrightnessHigh
                                gestureLevel = hardwareController.getBrightnessLevel()
                                gestureTitle = "Brightness ${(gestureLevel * 100).toInt()}%"
                            }
                        }
                    )
                }
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        if (isBuffering) {
            CircularProgressIndicator(
                color = TextPrimary,
                modifier = Modifier.size(44.dp).align(Alignment.Center)
            )
        }

        DualSubtitleOverlay(
            segment = activeSegment,
            fontSizeSp = subtitleFontSizeSp,
            bgAlpha = subtitleBgAlpha,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = if (controlsVisible && !isPiPMode) 110.dp else 24.dp)
                .padding(horizontal = 20.dp)
        )

        if (!isPiPMode) {
            GestureFeedbackIndicator(
                visible = gestureVisible,
                icon = gestureIcon,
                level = gestureLevel,
                title = gestureTitle,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        AnimatedVisibility(
            visible = controlsVisible && !isPiPMode,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.75f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackPress) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
                    }

                    Column(modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(
                            text = video.title,
                            color = TextPrimary,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            BadgeItem(video.resolution)
                            video.hdrType?.let { BadgeItem(it) }
                        }
                    }

                    IconButton(onClick = onEnterPiP) {
                        Icon(Icons.Rounded.PictureInPictureAlt, contentDescription = "Picture in Picture", tint = TextPrimary)
                    }

                    IconButton(onClick = onToggleLiveTranslation) {
                        Icon(
                            imageVector = Icons.Rounded.Translate,
                            contentDescription = "Translate",
                            tint = if (isTranslationActive) TextPrimary else TextTertiary
                        )
                    }

                    IconButton(onClick = { showAdvancedSheet = true }) {
                        Icon(Icons.Rounded.Tune, contentDescription = "Settings", tint = TextPrimary)
                    }
                }

                if (isTranslationActive && translationStatus != TranslationStatus.ACTIVE && translationStatusMsg != null) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.TopCenter)
                            .padding(top = 70.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(SurfaceElevated.copy(alpha = 0.9f))
                            .border(1.dp, BorderSubtle, RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = translationStatusMsg,
                            color = if (translationStatus == TranslationStatus.ERROR_API_KEY || translationStatus == TranslationStatus.ERROR_NO_INTERNET) AccentWarning else TextSecondary,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Row(
                    modifier = Modifier.align(Alignment.Center),
                    horizontalArrangement = Arrangement.spacedBy(28.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0)) },
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(Icons.Rounded.Replay10, contentDescription = "Rewind", tint = TextPrimary, modifier = Modifier.size(32.dp))
                    }

                    Box(
                        modifier = Modifier
                            .size(60.dp)
                            .clip(CircleShape)
                            .background(SurfaceElevated)
                            .border(1.dp, BorderHighlight, CircleShape)
                            .clickable {
                                if (isPlaying) exoPlayer.pause() else exoPlayer.play()
                                isPlaying = !isPlaying
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                            contentDescription = "Play/Pause",
                            tint = TextPrimary,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    IconButton(
                        onClick = { exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(exoPlayer.duration)) },
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(Icons.Rounded.Forward10, contentDescription = "Forward", tint = TextPrimary, modifier = Modifier.size(32.dp))
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    if (isScrubbing) {
                        Box(
                            modifier = Modifier
                                .align(Alignment.CenterHorizontally)
                                .clip(RoundedCornerShape(6.dp))
                                .background(SurfaceElevated)
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text(text = formatTime(scrubTimeMs), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    Slider(
                        value = if (duration > 0) currentPos.toFloat() / duration else 0f,
                        onValueChange = { frac ->
                            isScrubbing = true
                            scrubTimeMs = (frac * duration).toLong()
                            exoPlayer.seekTo(scrubTimeMs)
                        },
                        onValueChangeFinished = { isScrubbing = false },
                        colors = SliderDefaults.colors(
                            thumbColor = TextPrimary,
                            activeTrackColor = TextPrimary,
                            inactiveTrackColor = BorderSubtle
                        )
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(formatTime(currentPos), color = TextSecondary, fontSize = 11.sp)
                        Text(formatTime(duration), color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }

        if (showAdvancedSheet) {
            AdvancedControlsSheet(
                playbackSpeed = playbackSpeed,
                audioDspManager = audioDspManager,
                trackManager = trackManager,
                onSpeedChange = { newSpeed ->
                    playbackSpeed = newSpeed
                    exoPlayer.playbackParameters = exoPlayer.playbackParameters.withSpeed(newSpeed)
                },
                onDismiss = { showAdvancedSheet = false }
            )
        }
    }
}

@Composable
fun BadgeItem(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(3.dp))
            .background(SurfaceElevated)
            .border(0.5.dp, BorderSubtle, RoundedCornerShape(3.dp))
            .padding(horizontal = 5.dp, vertical = 1.dp)
    ) {
        Text(text = text, color = TextSecondary, fontSize = 8.sp, fontWeight = FontWeight.SemiBold)
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}
