package com.zelvyn.player.data

import android.content.Context
import android.util.Base64
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.google.crypto.tink.Aead
import com.google.crypto.tink.KeyTemplates
import com.google.crypto.tink.aead.AeadConfig
import com.google.crypto.tink.integration.android.AndroidKeysetManager
import com.zelvyn.player.model.UserPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.nio.charset.StandardCharsets

private val Context.dataStore by preferencesDataStore(name = "zelvyn_secure_prefs")

class PreferencesManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val KEY_ENCRYPTED_API = stringPreferencesKey("enc_gemini_api_key")
    private val KEY_DEFAULT_TARGET_LANG = stringPreferencesKey("default_target_lang")
    private val KEY_SUBTITLE_FONT_SIZE = intPreferencesKey("subtitle_font_size")
    private val KEY_SUBTITLE_BG_ALPHA = floatPreferencesKey("subtitle_bg_alpha")
    private val KEY_ONBOARDING_COMPLETED = booleanPreferencesKey("has_completed_onboarding")

    private val _userPreferences = MutableStateFlow(UserPreferences())
    val userPreferences: StateFlow<UserPreferences> = _userPreferences.asStateFlow()

    private val aead: Aead by lazy {
        AeadConfig.register()
        AndroidKeysetManager.Builder()
            .withSharedPref(context, "zelvyn_master_tink_keyset", "zelvyn_tink_prefs")
            .withKeyTemplate(KeyTemplates.get("AES256_GCM"))
            .withMasterKeyUri("android-keystore://zelvyn_master_key")
            .build()
            .keysetHandle
            .getPrimitive(Aead::class.java)
    }

    init {
        scope.launch(Dispatchers.IO) {
            context.dataStore.data.collectLatest { prefs ->
                val encryptedKey = prefs[KEY_ENCRYPTED_API] ?: ""
                val decryptedKey = decrypt(encryptedKey)

                _userPreferences.value = UserPreferences(
                    geminiApiKey = decryptedKey,
                    defaultTargetLang = prefs[KEY_DEFAULT_TARGET_LANG] ?: "Spanish",
                    subtitleFontSizeSp = prefs[KEY_SUBTITLE_FONT_SIZE] ?: 15,
                    subtitleBackgroundAlpha = prefs[KEY_SUBTITLE_BG_ALPHA] ?: 0.88f,
                    hasCompletedOnboarding = prefs[KEY_ONBOARDING_COMPLETED] ?: false
                )
            }
        }
    }

    fun setGeminiApiKey(key: String) {
        scope.launch(Dispatchers.IO) {
            val encrypted = encrypt(key.trim())
            context.dataStore.edit { it[KEY_ENCRYPTED_API] = encrypted }
        }
    }

    fun setDefaultTargetLang(lang: String) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { it[KEY_DEFAULT_TARGET_LANG] = lang }
        }
    }

    fun setSubtitleFontSize(sizeSp: Int) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { it[KEY_SUBTITLE_FONT_SIZE] = sizeSp }
        }
    }

    fun setSubtitleBackgroundAlpha(alpha: Float) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { it[KEY_SUBTITLE_BG_ALPHA] = alpha }
        }
    }

    fun setOnboardingCompleted(completed: Boolean) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { it[KEY_ONBOARDING_COMPLETED] = completed }
        }
    }

    fun saveVideoProgress(videoId: Long, positionMs: Long) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { it[longPreferencesKey("pos_$videoId")] = positionMs }
        }
    }

    suspend fun getVideoProgress(videoId: Long): Long {
        var pos = 0L
        context.dataStore.edit { prefs ->
            pos = prefs[longPreferencesKey("pos_$videoId")] ?: 0L
        }
        return pos
    }

    private fun encrypt(plainText: String): String {
        if (plainText.isBlank()) return ""
        return try {
            val cipher = aead.encrypt(plainText.toByteArray(StandardCharsets.UTF_8), null)
            Base64.encodeToString(cipher, Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    private fun decrypt(cipherText: String): String {
        if (cipherText.isBlank()) return ""
        return try {
            val cipherBytes = Base64.decode(cipherText, Base64.NO_WRAP)
            val decryptedBytes = aead.decrypt(cipherBytes, null)
            String(decryptedBytes, StandardCharsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}
