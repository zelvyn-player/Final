package com.zelvyn.player.utils

import android.content.Context
import android.os.Build
import java.io.File
import java.io.FileWriter
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ZelvynCrashLogger {
    private const val LOG_DIR_NAME = "crash_logs"
    private const val LOG_FILE_NAME = "latest_crash.log"

    fun install(context: Context) {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                writeCrashLog(context, thread, throwable)
            } catch (e: Exception) {
                e.printStackTrace()
            } finally {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }

    private fun writeCrashLog(context: Context, thread: Thread, throwable: Throwable) {
        val logDir = File(context.filesDir, LOG_DIR_NAME).apply { mkdirs() }
        val logFile = File(logDir, LOG_FILE_NAME)
        val sw = StringWriter()
        throwable.printStackTrace(PrintWriter(sw))
        val stackTrace = sw.toString()

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date())
        val logContent = buildString {
            appendLine("================ ZELVYN CRASH REPORT ================")
            appendLine("Timestamp   : $timestamp")
            appendLine("Thread      : ${thread.name} (ID: ${thread.id})")
            appendLine("Device      : ${Build.MANUFACTURER} ${Build.MODEL} (${Build.DEVICE})")
            appendLine("Android OS  : ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})")
            appendLine("App Version : 2.0.0 (Build 4)")
            appendLine("Exception   : ${throwable::class.java.name}: ${throwable.message}")
            appendLine("----------------- STACK TRACE -----------------")
            appendLine(stackTrace)
            appendLine("=====================================================")
        }

        FileWriter(logFile, false).use { it.write(logContent) }
    }

    fun getLatestCrashLog(context: Context): String? {
        return try {
            val file = File(context.filesDir, "$LOG_DIR_NAME/$LOG_FILE_NAME")
            if (file.exists() && file.length() > 0) file.readText() else null
        } catch (e: Exception) {
            null
        }
    }

    fun clearCrashLogs(context: Context) {
        try {
            File(context.filesDir, LOG_DIR_NAME).deleteRecursively()
        } catch (e: Exception) {
            // Ignore
        }
    }
}

