package com.zelvyn.player.ui.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.ui.theme.*

@Composable
fun OnboardingScreen(
    onFinished: () -> Unit
) {
    var step by remember { mutableIntStateOf(0) }

    val pages = listOf(
        OnboardingPage(Icons.Rounded.Headphones, "Universal Playback", "Smooth hardware-accelerated playback for all your local media with studio equalization."),
        OnboardingPage(Icons.Rounded.Translate, "Live Speech Translation", "Understand spoken dialogue in real-time with synchronized dual subtitles and translated voice."),
        OnboardingPage(Icons.Rounded.Security, "Privacy-First Pipeline", "Your local media stays on your device. Audio is processed ephemerally with zero tracking.")
    )
    val current = pages[step]

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(horizontal = 24.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 16.dp)) {
            repeat(pages.size) { index ->
                Box(
                    modifier = Modifier
                        .width(if (index == step) 28.dp else 8.dp)
                        .height(4.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (index == step) BrandAccent else MaterialTheme.colorScheme.surfaceVariant)
                )
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(BrandAccentLight.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(current.icon, contentDescription = null, tint = BrandAccentDark, modifier = Modifier.size(36.dp))
            }
            Spacer(modifier = Modifier.height(24.dp))
            Text(text = current.title, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground, textAlign = TextAlign.Center)
            Spacer(modifier = Modifier.height(10.dp))
            Text(text = current.subtitle, fontSize = 14.sp, color = MaterialTheme.colorScheme.secondary, textAlign = TextAlign.Center, lineHeight = 20.sp)
        }

        Button(
            onClick = {
                if (step < pages.size - 1) step++ else onFinished()
            },
            colors = ButtonDefaults.buttonColors(containerColor = BrandAccent, contentColor = CardSurfaceLight),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().height(50.dp)
        ) {
            Text(text = if (step == pages.size - 1) "Get Started" else "Continue", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

data class OnboardingPage(val icon: ImageVector, val title: String, val subtitle: String)
