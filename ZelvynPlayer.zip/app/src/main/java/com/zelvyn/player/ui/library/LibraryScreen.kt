package com.zelvyn.player.ui.library

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.model.FolderItem
import com.zelvyn.player.model.VideoItem
import com.zelvyn.player.ui.player.formatTime
import com.zelvyn.player.ui.theme.*

@Composable
fun LibraryScreen(
    videos: List<VideoItem>,
    folders: List<FolderItem>,
    hasStoragePermission: Boolean,
    onVideoSelected: (VideoItem) -> Unit,
    onFolderSelected: (String) -> Unit
) {
    val context = LocalContext.current
    var selectedCategory by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var sortOrder by remember { mutableStateOf("Recently Added") }

    val categories = listOf("All", "Videos", "Folders", "Downloads")

    val filteredVideos = remember(videos, selectedCategory, searchQuery, sortOrder) {
        val list = videos.filter { video ->
            val matchesCategory = when (selectedCategory) {
                "Folders" -> false
                "Downloads" -> video.folder.contains("Download", ignoreCase = true)
                else -> true
            }
            val matchesSearch = if (searchQuery.isBlank()) true else video.title.contains(searchQuery, ignoreCase = true)
            matchesCategory && matchesSearch
        }

        when (sortOrder) {
            "Name" -> list.sortedBy { it.title.lowercase() }
            "Duration" -> list.sortedByDescending { it.durationMs }
            "Size" -> list.sortedByDescending { it.sizeBytes }
            else -> list.sortedByDescending { it.dateAdded }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(horizontal = 16.dp)
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.Menu, contentDescription = null, tint = MaterialTheme.colorScheme.onBackground)
                Text(text = "Library", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                IconButton(onClick = {}) {
                    Icon(Icons.Rounded.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.onBackground)
                }
                IconButton(onClick = {}) {
                    Icon(Icons.Rounded.FilterList, contentDescription = "Filter", tint = MaterialTheme.colorScheme.onBackground)
                }
            }
        }

        if (!hasStoragePermission) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Icon(Icons.Rounded.FolderOff, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(54.dp))
                    Text(text = "Storage Permission Required", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Text(
                        text = "ZELVYN Player needs access to your local media to discover and play video files on your device.",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.secondary,
                        textAlign = TextAlign.Center
                    )
                    Button(
                        onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = BrandAccent, contentColor = CardSurfaceLight),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("Grant Permission in Settings")
                    }
                }
            }
        } else {
            // Category Chips (All / Videos / Folders / Downloads)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                items(categories) { category ->
                    val isSelected = category == selectedCategory
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .background(if (isSelected) BrandAccent else MaterialTheme.colorScheme.surface)
                            .border(1.dp, if (isSelected) BrandAccent else MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(20.dp))
                            .clickable { selectedCategory = category }
                            .padding(horizontal = 16.dp, vertical = 7.dp)
                    ) {
                        Text(
                            text = category,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) CardSurfaceLight else MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }

            if (selectedCategory == "Folders") {
                // Folder View matching attached UI
                Text(text = "Sort: Name ▾", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(bottom = 8.dp))
                LazyVerticalGrid(
                    columns = GridCells.Fixed(1),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(folders) { folder ->
                        FolderRowCard(folder = folder, onClick = { onFolderSelected(folder.name) })
                    }
                }
            } else {
                // Video Grid View matching attached UI
                Text(text = "Sort: $sortOrder ▾", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, modifier = Modifier.padding(bottom = 8.dp))

                if (filteredVideos.isEmpty()) {
                    Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                        Text("No videos found in storage.", color = MaterialTheme.colorScheme.secondary, fontSize = 14.sp)
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(3),
                        horizontalArrangement = Arrangement.spacedBy(10.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp),
                        modifier = Modifier.fillMaxSize()
                    ) {
                        items(filteredVideos) { video ->
                            VideoGridCard(video = video, onClick = { onVideoSelected(video) })
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FolderRowCard(folder: FolderItem, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Icon(Icons.Rounded.Folder, contentDescription = null, tint = BrandAccent, modifier = Modifier.size(26.dp))
            Column {
                Text(text = folder.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Text(text = "${folder.videoCount} videos", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
            }
        }
        Icon(Icons.Rounded.MoreVert, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
    }
}

@Composable
fun VideoGridCard(video: VideoItem, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .clickable { onClick() }
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.75f)
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant),
            contentAlignment = Alignment.Center
        ) {
            if (video.thumbnailBitmap != null) {
                Image(
                    bitmap = video.thumbnailBitmap.asImageBitmap(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize()
                )
            } else {
                Icon(Icons.Rounded.PlayCircleOutline, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary, modifier = Modifier.size(32.dp))
            }

            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(5.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(CardSurfaceDark.copy(alpha = 0.75f))
                    .padding(horizontal = 4.dp, vertical = 2.dp)
            ) {
                Text(text = video.resolution, fontSize = 8.sp, color = CardSurfaceLight, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(5.dp))
        Text(text = video.title, fontSize = 11.sp, fontWeight = FontWeight.Medium, color = MaterialTheme.colorScheme.onBackground, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(text = formatTime(video.durationMs), fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
    }
}
