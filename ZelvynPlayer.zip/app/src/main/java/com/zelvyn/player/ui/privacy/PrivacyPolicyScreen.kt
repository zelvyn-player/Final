package com.zelvyn.player.ui.privacy

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.ui.theme.*

@Composable
fun PrivacyPolicyScreen(
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(text = "Privacy Policy", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            item { Text(text = "Last updated: August 2026", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary) }
            item { PrivacySection("1. Local Media Privacy", "ZELVYN Player functions offline on your device. Video and audio files stored in your local storage are discovered via Android's MediaStore API and are never uploaded to any third-party server.") }
            item { PrivacySection("2. Live Audio Translation", "When you activate Translation, audio is intercepted directly from the media decoding pipeline (no microphone recording is used). Encrypted audio chunks are sent ephemerally to Google Gemini API exclusively for generating transcripts.") }
            item { PrivacySection("3. Storage & Permissions", "READ_MEDIA_VIDEO permission is used solely to discover local video files. Your preferences and API key are encrypted on-device with Android KeyStore AES-256-GCM.") }
        }
    }
}

@Composable
fun PrivacySection(title: String, body: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(14.dp)
    ) {
        Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Spacer(modifier = Modifier.height(4.dp))
        Text(text = body, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, lineHeight = 17.sp)
    }
}
