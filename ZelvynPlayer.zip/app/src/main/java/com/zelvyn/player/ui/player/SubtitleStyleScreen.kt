package com.zelvyn.player.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.model.SubtitleBgMode
import com.zelvyn.player.model.SubtitleEncodings
import com.zelvyn.player.model.SubtitleFontFamily
import com.zelvyn.player.ui.theme.*

@Composable
fun SubtitleStyleScreen(
    prefsManager: PreferencesManager,
    onBack: () -> Unit
) {
    val userPrefs by prefsManager.userPreferences.collectAsState()
    var showEncodingDialog by remember { mutableStateOf(false) }

    val colorOptions = listOf(0xFFFFFFFF, 0xFFFFE600, 0xFF00FF66, 0xFF00E5FF, 0xFFBF5AF2, 0xFFFF9500)

    val composeFontFamily = when (userPrefs.subtitleFontFamily) {
        SubtitleFontFamily.SANS_SERIF -> FontFamily.SansSerif
        SubtitleFontFamily.SERIF -> FontFamily.Serif
        SubtitleFontFamily.MONOSPACE -> FontFamily.Monospace
        SubtitleFontFamily.CURSIVE -> FontFamily.Cursive
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
            }
            Text(text = "Subtitle Styling & Encoding", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        }

        // Live Preview Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (userPrefs.subtitleBgMode == SubtitleBgMode.NONE) Color.Transparent else CardSurfaceDark.copy(alpha = userPrefs.subtitleBackgroundAlpha))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "The mountains are calling and I must go.",
                    color = Color(userPrefs.subtitleColorArgb),
                    fontSize = userPrefs.subtitleFontSizeSp.sp,
                    fontWeight = if (userPrefs.subtitleBold) FontWeight.Bold else FontWeight.Normal,
                    fontFamily = composeFontFamily,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Font Family Choice
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "Font Family", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(
                            SubtitleFontFamily.SANS_SERIF to "Sans",
                            SubtitleFontFamily.SERIF to "Serif",
                            SubtitleFontFamily.MONOSPACE to "Mono",
                            SubtitleFontFamily.CURSIVE to "Cursive"
                        ).forEach { (family, label) ->
                            val isSelected = userPrefs.subtitleFontFamily == family
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) BrandAccentLight.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface)
                                    .clickable { prefsManager.updatePreferences { it.copy(subtitleFontFamily = family) } }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 11.sp,
                                    color = if (isSelected) BrandAccentDark else MaterialTheme.colorScheme.onBackground,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }
                }
            }

            // Bold Toggle & Text Encoding Row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Bold Font Style", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                    Switch(
                        checked = userPrefs.subtitleBold,
                        onCheckedChange = { prefsManager.updatePreferences { p -> p.copy(subtitleBold = it) } },
                        colors = SwitchDefaults.colors(checkedThumbColor = CardSurfaceLight, checkedTrackColor = BrandAccent)
                    )
                }
            }

            // Text Size Slider
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(text = "Text Size (${userPrefs.subtitleFontSizeSp}sp)", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "A-", fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary)
                        Slider(
                            value = userPrefs.subtitleFontSizeSp.toFloat(),
                            onValueChange = { prefsManager.updatePreferences { p -> p.copy(subtitleFontSizeSp = it.toInt()) } },
                            valueRange = 12f..28f,
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                            colors = SliderDefaults.colors(thumbColor = BrandAccent, activeTrackColor = BrandAccent)
                        )
                        Text(text = "A+", fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Color Palette Picker
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "Color", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        colorOptions.forEach { colorArgb ->
                            val isSelected = userPrefs.subtitleColorArgb == colorArgb
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(colorArgb))
                                    .border(if (isSelected) 3.dp else 1.dp, if (isSelected) BrandAccent else MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                                    .clickable { prefsManager.updatePreferences { p -> p.copy(subtitleColorArgb = colorArgb) } }
                            )
                        }
                    }
                }
            }

            // Background Mode
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "Background Style", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(SubtitleBgMode.NONE to "None", SubtitleBgMode.SOLID to "Solid").forEach { (mode, label) ->
                            val isSelected = userPrefs.subtitleBgMode == mode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) BrandAccentLight.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface)
                                    .clickable { prefsManager.updatePreferences { p -> p.copy(subtitleBgMode = mode) } }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = label, fontSize = 11.sp, color = if (isSelected) BrandAccentDark else MaterialTheme.colorScheme.onBackground, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                }
            }

            // Opacity Slider
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Background Opacity", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        Text(text = "${(userPrefs.subtitleBackgroundAlpha * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = userPrefs.subtitleBackgroundAlpha,
                        onValueChange = { prefsManager.updatePreferences { p -> p.copy(subtitleBackgroundAlpha = it) } },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = BrandAccent, activeTrackColor = BrandAccent)
                    )
                }
            }

            // Text Encoding Picker (for external .srt / .ass / .vtt)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                        .clickable { showEncodingDialog = true }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Subtitle Text Encoding", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                        Text(text = "Supports non-UTF8 external subtitle files", fontSize = 10.sp, color = MaterialTheme.colorScheme.secondary)
                    }
                    Text(text = "${userPrefs.subtitleEncoding} >", fontSize = 12.sp, color = BrandAccent, fontWeight = FontWeight.Bold)
                }
            }
        }
    }

    if (showEncodingDialog) {
        AlertDialog(
            onDismissRequest = { showEncodingDialog = false },
            title = { Text("Select Text Encoding", fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn {
                    items(SubtitleEncodings.ALL_ENCODINGS.size) { idx ->
                        val enc = SubtitleEncodings.ALL_ENCODINGS[idx]
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    prefsManager.updatePreferences { p -> p.copy(subtitleEncoding = enc) }
                                    showEncodingDialog = false
                                }
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(enc, color = MaterialTheme.colorScheme.onBackground)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showEncodingDialog = false }) { Text("Close") }
            }
        )
    }
}
