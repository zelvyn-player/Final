package com.zelvyn.player.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.model.SubtitleBgMode
import com.zelvyn.player.ui.theme.*

@Composable
fun SubtitleStyleScreen(
    prefsManager: PreferencesManager,
    onBack: () -> Unit
) {
    val userPrefs by prefsManager.userPreferences.collectAsState()
    var selectedTab by remember { mutableStateOf("Style") }
    val tabs = listOf("Style", "Font", "Layout", "Advanced")

    val colorOptions = listOf(0xFFFFFFFF, 0xFFFFE600, 0xFF00FF66, 0xFF00E5FF, 0xFFBF5AF2, 0xFFFF9500)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
            }
            Text(text = "Subtitle Style", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        }

        // Segmented Tabs: Style | Font | Layout | Advanced
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                .padding(3.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            tabs.forEach { tab ->
                val isSelected = tab == selectedTab
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) BrandAccentLight.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface)
                        .clickable { selectedTab = tab }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = tab, fontSize = 11.sp, color = if (isSelected) BrandAccentDark else MaterialTheme.colorScheme.secondary, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Live Preview Card (as in attached UI)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(130.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(if (userPrefs.subtitleBgMode == SubtitleBgMode.NONE) Color.Transparent else CardSurfaceDark.copy(alpha = userPrefs.subtitleBackgroundAlpha))
                    .padding(horizontal = 12.dp, vertical = 6.dp)
            ) {
                Text(
                    text = "The mountains are calling and I must go.",
                    color = Color(userPrefs.subtitleColorArgb),
                    fontSize = userPrefs.subtitleFontSizeSp.sp,
                    fontWeight = FontWeight.Medium,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn(verticalArrangement = Arrangement.spacedBy(14.dp)) {
            // Text Size Slider
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(text = "Text Size", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "A-", fontSize = 12.sp, color = MaterialTheme.colorScheme.tertiary)
                        Slider(
                            value = userPrefs.subtitleFontSizeSp.toFloat(),
                            onValueChange = { prefsManager.updatePreferences { p -> p.copy(subtitleFontSizeSp = it.toInt()) } },
                            valueRange = 12f..26f,
                            modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                            colors = SliderDefaults.colors(thumbColor = BrandAccent, activeTrackColor = BrandAccent)
                        )
                        Text(text = "A+", fontSize = 14.sp, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Color Palette Picker
            item {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "Color", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        colorOptions.forEach { colorArgb ->
                            val isSelected = userPrefs.subtitleColorArgb == colorArgb
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(colorArgb))
                                    .border(if (isSelected) 3.dp else 1.dp, if (isSelected) BrandAccent else MaterialTheme.colorScheme.surfaceVariant, CircleShape)
                                    .clickable { prefsManager.updatePreferences { p -> p.copy(subtitleColorArgb = colorArgb) } }
                            )
                        }
                    }
                }
            }

            // Background Mode: None | Solid | Gradient
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "Background", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(SubtitleBgMode.NONE to "None", SubtitleBgMode.SOLID to "Solid", SubtitleBgMode.GRADIENT to "Gradient").forEach { (mode, label) ->
                            val isSelected = userPrefs.subtitleBgMode == mode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) BrandAccentLight.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface)
                                    .clickable { prefsManager.updatePreferences { p -> p.copy(subtitleBgMode = mode) } }
                                    .padding(vertical = 6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = label, fontSize = 11.sp, color = if (isSelected) BrandAccentDark else MaterialTheme.colorScheme.onBackground, fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal)
                            }
                        }
                    }
                }
            }

            // Opacity Slider
            item {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Opacity", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        Text(text = "${(userPrefs.subtitleBackgroundAlpha * 100).toInt()}%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = userPrefs.subtitleBackgroundAlpha,
                        onValueChange = { prefsManager.updatePreferences { p -> p.copy(subtitleBackgroundAlpha = it) } },
                        valueRange = 0f..1f,
                        colors = SliderDefaults.colors(thumbColor = BrandAccent, activeTrackColor = BrandAccent)
                    )
                }
            }

            // Position (Bottom >)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                        .clickable {
                            val newPos = if (userPrefs.subtitlePosition == "Bottom") "Top" else "Bottom"
                            prefsManager.updatePreferences { p -> p.copy(subtitlePosition = newPos) }
                        }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Position", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                    Text(text = "${userPrefs.subtitlePosition} >", fontSize = 12.sp, color = BrandAccent)
                }
            }
        }
    }
}
