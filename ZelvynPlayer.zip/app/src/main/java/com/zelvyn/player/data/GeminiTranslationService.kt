
package com.zelvyn.player.data

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

sealed class GeminiResult {
    data class Success(val originalText: String, val translatedText: String, val detectedLanguage: String) : GeminiResult()
    data class Failure(val errorType: ErrorType, val message: String) : GeminiResult()

    enum class ErrorType {
        NO_INTERNET, API_KEY_INVALID, RATE_LIMITED, NO_SPEECH, GENERIC
    }
}

class GeminiTranslationService {

    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .writeTimeout(10, TimeUnit.SECONDS)
        .build()

    suspend fun translateAudioChunk(
        apiKey: String,
        rawPcmBytes: ByteArray,
        sampleRate: Int,
        channels: Int,
        targetLanguage: String,
        sourceLanguageOverride: String? = null
    ): GeminiResult = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) {
            return@withContext GeminiResult.Failure(
                GeminiResult.ErrorType.API_KEY_INVALID,
                "API key missing. Enter your Gemini API key in Settings."
            )
        }

        val wavBytes = createWavFile(rawPcmBytes, sampleRate, channels)
        val base64Audio = Base64.encodeToString(wavBytes, Base64.NO_WRAP)

        val srcInstruction = if (sourceLanguageOverride == null || sourceLanguageOverride == "Auto Detect") {
            "Auto-detect the spoken language in the audio."
        } else {
            "The spoken language is $sourceLanguageOverride."
        }

        val prompt = """
            Listen to this audio chunk from a video. $srcInstruction
            Task: Transcribe the dialogue accurately, and translate it to $targetLanguage.
            Return ONLY a valid, raw JSON object with this exact structure:
            {"original": "transcription here", "translated": "translation in $targetLanguage here", "detected_language": "language name"}
            If there is only background music, silence, or no clear speech, return:
            {"original": "", "translated": "", "detected_language": "None"}
        """.trimIndent()

        val requestBodyJson = """
        {
          "contents": [
            {
              "parts": [
                { "text": ${JSONObject.quote(prompt)} },
                {
                  "inline_data": {
                    "mime_type": "audio/wav",
                    "data": "$base64Audio"
                  }
                }
              ]
            }
          ],
          "generationConfig": {
            "response_mime_type": "application/json",
            "temperature": 0.2
          }
        }
        """.trimIndent()

        val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=$apiKey"
        val request = Request.Builder()
            .url(endpoint)
            .post(requestBodyJson.toRequestBody("application/json".toMediaType()))
            .build()

        // Retry loop with exponential backoff for network timeouts & HTTP 429
        var maxRetries = 2
        var currentAttempt = 0
        var backoffMs = 1000L

        while (currentAttempt <= maxRetries) {
            try {
                val response = client.newCall(request).execute()
                val code = response.code
                val bodyString = response.body?.string() ?: ""

                if (!response.isSuccessful) {
                    if (code == 429 && currentAttempt < maxRetries) {
                        currentAttempt++
                        val retryAfterHeader = response.header("Retry-After")?.toLongOrNull()
                        val waitTime = (retryAfterHeader?.times(1000L)) ?: backoffMs
                        delay(waitTime)
                        backoffMs *= 2
                        continue
                    }

                    return@withContext when (code) {
                        400, 401, 403 -> GeminiResult.Failure(
                            GeminiResult.ErrorType.API_KEY_INVALID,
                            "Invalid or unauthorized Gemini API key. Check Settings."
                        )
                        429 -> GeminiResult.Failure(
                            GeminiResult.ErrorType.RATE_LIMITED,
                            "Gemini API rate limit reached. Backing off..."
                        )
                        else -> GeminiResult.Failure(
                            GeminiResult.ErrorType.GENERIC,
                            "Translation service error (HTTP $code)."
                        )
                    }
                }

                val root = JSONObject(bodyString)
                val candidates = root.optJSONArray("candidates")
                if (candidates == null || candidates.length() == 0) {
                    return@withContext GeminiResult.Failure(GeminiResult.ErrorType.NO_SPEECH, "No dialogue in chunk.")
                }

                val content = candidates.getJSONObject(0).optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                var textJson = parts?.getJSONObject(0)?.optString("text") ?: ""

                // Strip potential markdown code blocks
                textJson = textJson.trim()
                if (textJson.startsWith("```json")) {
                    textJson = textJson.removePrefix("```json")
                } else if (textJson.startsWith("```")) {
                    textJson = textJson.removePrefix("```")
                }
                if (textJson.endsWith("```")) {
                    textJson = textJson.removeSuffix("```")
                }
                textJson = textJson.trim()

                val parsed = JSONObject(textJson)
                val orig = parsed.optString("original", "").trim()
                val trans = parsed.optString("translated", "").trim()
                val detected = parsed.optString("detected_language", "Auto")

                if (orig.isEmpty() && trans.isEmpty()) {
                    return@withContext GeminiResult.Failure(GeminiResult.ErrorType.NO_SPEECH, "No dialogue in chunk.")
                }

                return@withContext GeminiResult.Success(
                    originalText = orig,
                    translatedText = trans,
                    detectedLanguage = detected
                )

            } catch (e: IOException) {
                if (currentAttempt < maxRetries) {
                    currentAttempt++
                    delay(backoffMs)
                    backoffMs *= 2
                } else {
                    return@withContext GeminiResult.Failure(
                        GeminiResult.ErrorType.NO_INTERNET,
                        "Connection issue — retrying translation..."
                    )
                }
            } catch (e: Exception) {
                return@withContext GeminiResult.Failure(
                    GeminiResult.ErrorType.GENERIC,
                    "Unable to parse transcript: ${e.localizedMessage ?: "Unknown error"}"
                )
            }
        }

        GeminiResult.Failure(GeminiResult.ErrorType.GENERIC, "Translation request timed out.")
    }

    private fun createWavFile(pcmData: ByteArray, sampleRate: Int, channels: Int): ByteArray {
        val byteRate = sampleRate * channels * 2
        val totalDataLen = pcmData.size + 36
        val totalAudioLen = pcmData.size

        val out = ByteArrayOutputStream()
        out.write("RIFF".toByteArray())
        out.write(intToByteArray(totalDataLen))
        out.write("WAVE".toByteArray())
        out.write("fmt ".toByteArray())
        out.write(intToByteArray(16))
        out.write(shortToByteArray(1))
        out.write(shortToByteArray(channels.toShort()))
        out.write(intToByteArray(sampleRate))
        out.write(intToByteArray(byteRate))
        out.write(shortToByteArray((channels * 2).toShort()))
        out.write(shortToByteArray(16))
        out.write("data".toByteArray())
        out.write(intToByteArray(totalAudioLen))
        out.write(pcmData)

        return out.toByteArray()
    }

    private fun intToByteArray(value: Int): ByteArray = byteArrayOf(
        (value and 0xff).toByte(),
        ((value shr 8) and 0xff).toByte(),
        ((value shr 16) and 0xff).toByte(),
        ((value shr 24) and 0xff).toByte()
    )

    private fun shortToByteArray(value: Short): ByteArray = byteArrayOf(
        (value.toInt() and 0xff).toByte(),
        ((value.toInt() shr 8) and 0xff).toByte()
    )
}

