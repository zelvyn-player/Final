package com.zelvyn.player.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.data.ExoPlayerTrackManager
import com.zelvyn.player.model.EqualizerPresetType
import com.zelvyn.player.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedControlsSheet(
    playbackSpeed: Float,
    audioDspManager: AudioDspManager,
    trackManager: ExoPlayerTrackManager,
    onSpeedChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val bands by audioDspManager.bands.collectAsState()
    val activePreset by audioDspManager.currentPreset.collectAsState()
    val audioTracks by trackManager.audioTracks.collectAsState()
    val subtitleTracks by trackManager.subtitleTracks.collectAsState()

    var sleepTimer by remember { mutableStateOf("Off") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SurfaceElevated,
        tonalElevation = 0.dp
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "Controls & Tracks",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            item {
                Text(text = "PLAYBACK SPEED", fontSize = 11.sp, color = TextTertiary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                        val isSelected = speed == playbackSpeed
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) SurfacePressed else SurfaceSubtle)
                                .clickable { onSpeedChange(speed) }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${speed}x",
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) TextPrimary else TextSecondary
                            )
                        }
                    }
                }
            }

            item {
                Text(text = "MEDIA AUDIO TRACKS (${audioTracks.size})", fontSize = 11.sp, color = TextTertiary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(6.dp))
                if (audioTracks.isEmpty()) {
                    Text(text = "Default stereo track active.", color = TextSecondary, fontSize = 13.sp)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        audioTracks.forEach { track ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SurfaceSubtle)
                                    .clickable { trackManager.selectTrack(track, androidx.media3.common.C.TRACK_TYPE_AUDIO) }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = track.label, color = TextPrimary, fontSize = 13.sp)
                                if (track.isSelected) {
                                    Icon(Icons.Rounded.Check, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "EMBEDDED SUBTITLES", fontSize = 11.sp, color = TextTertiary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                    TextButton(onClick = { trackManager.disableSubtitles() }) {
                        Text("Disable", color = TextTertiary, fontSize = 11.sp)
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                if (subtitleTracks.isEmpty()) {
                    Text(text = "No embedded subtitle tracks in file.", color = TextSecondary, fontSize = 13.sp)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        subtitleTracks.forEach { track ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(SurfaceSubtle)
                                    .clickable { trackManager.selectTrack(track, androidx.media3.common.C.TRACK_TYPE_TEXT) }
                                    .padding(horizontal = 12.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = track.label, color = TextPrimary, fontSize = 13.sp)
                                if (track.isSelected) {
                                    Icon(Icons.Rounded.Check, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }
                }
            }

            item {
                Text(text = "5-BAND EQUALIZER", fontSize = 11.sp, color = TextTertiary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(6.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(
                        EqualizerPresetType.FLAT to "Flat",
                        EqualizerPresetType.POP to "Pop",
                        EqualizerPresetType.ROCK to "Rock",
                        EqualizerPresetType.BASS to "Bass"
                    ).forEach { (preset, label) ->
                        val isSelected = activePreset == preset
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) SurfacePressed else SurfaceSubtle)
                                .clickable { audioDspManager.applyPreset(preset) }
                                .padding(horizontal = 12.dp, vertical = 5.dp)
                        ) {
                            Text(text = label, fontSize = 11.sp, color = if (isSelected) TextPrimary else TextSecondary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    bands.forEach { band ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Slider(
                                value = band.gainDb,
                                onValueChange = { audioDspManager.setBandGain(band.bandIndex, it) },
                                valueRange = -10f..10f,
                                modifier = Modifier.height(100.dp).width(36.dp),
                                colors = SliderDefaults.colors(thumbColor = TextPrimary, activeTrackColor = AccentWarm)
                            )
                            Text(text = band.frequencyLabel, fontSize = 9.sp, color = TextTertiary)
                        }
                    }
                }
            }

            item {
                Text(text = "SLEEP TIMER", fontSize = 11.sp, color = TextTertiary, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Off", "15m", "30m", "45m", "60m").forEach { timer ->
                        val isSelected = timer == sleepTimer
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (isSelected) SurfacePressed else SurfaceSubtle)
                                .clickable { sleepTimer = timer }
                                .padding(vertical = 7.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = timer, fontSize = 11.sp, color = if (isSelected) TextPrimary else TextSecondary)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}