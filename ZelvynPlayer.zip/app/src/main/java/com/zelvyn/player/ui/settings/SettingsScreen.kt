package com.zelvyn.player.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.model.SupportedLanguages
import com.zelvyn.player.ui.theme.*

@Composable
fun SettingsScreen(
    prefsManager: PreferencesManager,
    onNavigatePrivacy: () -> Unit
) {
    val userPrefs by prefsManager.userPreferences.collectAsState()
    var apiKeyInput by remember(userPrefs.geminiApiKey) { mutableStateOf(userPrefs.geminiApiKey) }
    var isApiKeyVisible by remember { mutableStateOf(false) }

    val targetLanguages = SupportedLanguages.ALL_LANGUAGES.filter { it != "Auto Detect" }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasDark)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Settings",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(18.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            item {
                Text(
                    text = "AI SPEECH TRANSLATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextTertiary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceSubtle)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Gemini API Key (Tink-Encrypted)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = TextPrimary
                    )

                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = {
                            apiKeyInput = it
                            prefsManager.setGeminiApiKey(it)
                        },
                        placeholder = { Text("Enter Google AI Studio Key", color = TextTertiary, fontSize = 12.sp) },
                        visualTransformation = if (isApiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isApiKeyVisible = !isApiKeyVisible }) {
                                Icon(
                                    imageVector = if (isApiKeyVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = null,
                                    tint = TextSecondary,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = BorderHighlight,
                            unfocusedBorderColor = BorderSubtle,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary,
                            cursorColor = TextPrimary
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Text(
                        text = "Stored locally using Google Tink AEAD encryption in DataStore. Excluded from device cloud backups.",
                        fontSize = 11.sp,
                        color = TextTertiary,
                        lineHeight = 15.sp
                    )
                }
            }

            item {
                Text(
                    text = "DEFAULT TARGET LANGUAGE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextTertiary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceSubtle)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                        .padding(horizontal = 14.dp, vertical = 6.dp)
                ) {
                    targetLanguages.forEach { lang ->
                        val isSelected = lang == userPrefs.defaultTargetLang
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { prefsManager.setDefaultTargetLang(lang) }
                                .padding(vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = lang, color = TextPrimary, fontSize = 14.sp)
                            if (isSelected) {
                                Icon(Icons.Rounded.Check, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(18.dp))
                            }
                        }
                    }
                }
            }

            item {
                Text(
                    text = "SUBTITLE APPEARANCE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextTertiary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceSubtle)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Font Size (${userPrefs.subtitleFontSizeSp}sp)", fontSize = 13.sp, color = TextPrimary)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(
                            onClick = { prefsManager.setSubtitleFontSize((userPrefs.subtitleFontSizeSp - 2).coerceAtLeast(11)) },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                        ) { Text("-", color = TextPrimary) }
                        Button(
                            onClick = { prefsManager.setSubtitleFontSize((userPrefs.subtitleFontSizeSp + 2).coerceAtMost(22)) },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)
                        ) { Text("+", color = TextPrimary) }
                    }
                }
            }

            item {
                Text(
                    text = "ABOUT & LEGAL",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextTertiary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(8.dp))

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(SurfaceSubtle)
                        .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigatePrivacy() }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Privacy Policy", color = TextPrimary, fontSize = 14.sp)
                        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(18.dp))
                    }

                    HorizontalDivider(color = BorderSubtle, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Version", color = TextPrimary, fontSize = 14.sp)
                        Text(text = "1.2.0 (Build 2026.3)", color = TextTertiary, fontSize = 13.sp)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}