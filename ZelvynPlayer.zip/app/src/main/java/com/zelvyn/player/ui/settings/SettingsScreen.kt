package com.zelvyn.player.ui.settings

import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.model.LibraryLayoutMode
import com.zelvyn.player.ui.theme.AccentError
import com.zelvyn.player.ui.theme.BrandAccent
import com.zelvyn.player.ui.theme.BrandAccentLight
import com.zelvyn.player.utils.ZelvynCrashLogger

@Composable
fun SettingsScreen(
    prefsManager: PreferencesManager,
    onForceRescan: () -> Unit = {},
    onNavigateAbout: () -> Unit = {},
    onNavigatePrivacy: () -> Unit = {},
    onNavigateSubtitleStyle: () -> Unit = {}
) {
    val context = LocalContext.current
    val userPrefs by prefsManager.userPreferences.collectAsState()
    var apiKeyInput by remember(userPrefs.geminiApiKey) { mutableStateOf(userPrefs.geminiApiKey) }
    var isApiKeyVisible by remember { mutableStateOf(false) }
    var showResetConfirmDialog by remember { mutableStateOf(false) }
    var showFullResetDialog by remember { mutableStateOf(false) }
    var showCrashLogDialog by remember { mutableStateOf(false) }
    var crashLogContent by remember { mutableStateOf<String?>(null) }

    // 2-Step PIN Setup Dialog State
    var showPinSetupDialog by remember { mutableStateOf(false) }
    var pinStep by remember { mutableIntStateOf(1) } // 1 = Enter, 2 = Confirm
    var pinSetupFirst by remember { mutableStateOf("") }
    var pinSetupConfirm by remember { mutableStateOf("") }
    var pinSetupError by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Settings",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize().padding(bottom = 16.dp)
        ) {
            // Theme Mode: System | Light | Dark
            item {
                Text(
                    text = "APPEARANCE & THEME",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    listOf("System" to "Auto System", "Light" to "Luxury Light", "Dark" to "Studio Dark").forEach { (mode, label) ->
                        val isSelected = userPrefs.themeMode == mode
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) BrandAccentLight.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface)
                                .clickable { prefsManager.updatePreferences { it.copy(themeMode = mode) } }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = label,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) BrandAccent else MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }
                }
            }

            // Security & Passcode Lock (2-Step Safe Setup)
            item {
                Text(
                    text = "SECURITY & PRIVACY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "App Passcode Lock (PIN)", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.SemiBold)
                            Text(text = if (userPrefs.isPinLockEnabled) "4-digit PIN is active" else "Protect personal media", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        Switch(
                            checked = userPrefs.isPinLockEnabled,
                            onCheckedChange = { enable ->
                                if (enable) {
                                    pinStep = 1
                                    pinSetupFirst = ""
                                    pinSetupConfirm = ""
                                    pinSetupError = null
                                    showPinSetupDialog = true
                                } else {
                                    prefsManager.disableAppPin()
                                    Toast.makeText(context, "PIN protection disabled", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                        )
                    }
                }
            }

            // Gemini API Key Section
            item {
                Text(
                    text = "AI SPEECH TRANSLATION",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = "Gemini API Key (Hardware-Encrypted)",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    OutlinedTextField(
                        value = apiKeyInput,
                        onValueChange = {
                            apiKeyInput = it
                            prefsManager.updatePreferences { p -> p.copy(geminiApiKey = it) }
                        },
                        placeholder = { Text("Enter Google AI Studio Key", fontSize = 12.sp) },
                        visualTransformation = if (isApiKeyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        trailingIcon = {
                            IconButton(onClick = { isApiKeyVisible = !isApiKeyVisible }) {
                                Icon(
                                    if (isApiKeyVisible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.secondary
                                )
                            }
                        },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        text = "Encrypted on-device using Android Keystore AES-256-GCM.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )
                }
            }

            // Subtitle Style & Fonts Row
            item {
                Text(
                    text = "SUBTITLES & PLAYBACK",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateSubtitleStyle() }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Subtitle Styling & Fonts", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                            Text(text = "Font family, size, encoding, and colors", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

                    // Gesture Sensitivity Slider
                    Column(modifier = Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Swipe Gesture Sensitivity", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                            Text(text = "${((userPrefs.gestureSensitivity * 10).toInt() / 10f)}x", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = BrandAccent)
                        }
                        Slider(
                            value = userPrefs.gestureSensitivity,
                            onValueChange = { prefsManager.updatePreferences { p -> p.copy(gestureSensitivity = it) } },
                            valueRange = 0.5f..2.0f,
                            colors = SliderDefaults.colors(thumbColor = BrandAccent, activeTrackColor = BrandAccent)
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

                    // Default Library Layout
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val next = if (userPrefs.libraryLayoutMode == LibraryLayoutMode.GRID) LibraryLayoutMode.LIST else LibraryLayoutMode.GRID
                                prefsManager.updatePreferences { it.copy(libraryLayoutMode = next) }
                            }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Default Library Layout", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                        Text(text = userPrefs.libraryLayoutMode.name, fontSize = 12.sp, color = BrandAccent, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Storage & Maintenance
            item {
                Text(
                    text = "STORAGE & MAINTENANCE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onForceRescan() }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Force Rescan Media Library", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                            Text(text = "Index newly added video files", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        Icon(Icons.Rounded.Refresh, contentDescription = null, tint = BrandAccent)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                try {
                                    context.cacheDir.deleteRecursively()
                                    Toast.makeText(context, "Thumbnail & video cache cleared", Toast.LENGTH_SHORT).show()
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Cache already clear", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Clear Thumbnail & App Cache", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                            Text(text = "Frees temporary storage space", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        Icon(Icons.Rounded.CleaningServices, contentDescription = null, tint = BrandAccent)
                    }
                }
            }

            // Diagnostics & Crash Logs
            item {
                Text(
                    text = "DIAGNOSTICS",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                crashLogContent = ZelvynCrashLogger.getLatestCrashLog(context)
                                showCrashLogDialog = true
                            }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "View Crash & Stability Logs", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                            Text(text = "Local diagnostics recorded on error", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        Icon(Icons.Rounded.BugReport, contentDescription = null, tint = BrandAccent)
                    }
                }
            }

            // Recovery & Full App Reset
            item {
                Text(
                    text = "RECOVERY",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showResetConfirmDialog = true }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Reset Playback & EQ Defaults", fontSize = 13.sp, color = AccentError)
                            Text(text = "Restores audio and speed defaults", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        Icon(Icons.Rounded.RestartAlt, contentDescription = null, tint = AccentError)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showFullResetDialog = true }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = "Reset All App Data", fontSize = 13.sp, color = AccentError, fontWeight = FontWeight.Bold)
                            Text(text = "Wipes preferences, PIN, and cache (videos safe)", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        }
                        Icon(Icons.Rounded.DeleteForever, contentDescription = null, tint = AccentError)
                    }
                }
            }

            // About ZELVYN
            item {
                Text(
                    text = "ABOUT & REFERENCE",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.secondary,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigateAbout() }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "About ZELVYN Player", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onNavigatePrivacy() }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Privacy Policy", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.secondary)
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.surfaceVariant, thickness = 0.5.dp)

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = "Version", fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
                        Text(text = "2.0.0 Pro Edition", fontSize = 12.sp, color = BrandAccent, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }

    // 2-Step Safe PIN Configuration Dialog
    if (showPinSetupDialog) {
        AlertDialog(
            onDismissRequest = { showPinSetupDialog = false },
            title = {
                Text(
                    text = if (pinStep == 1) "Create 4-Digit PIN (Step 1/2)" else "Confirm 4-Digit PIN (Step 2/2)",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = if (pinStep == 1) "Enter a new 4-digit security PIN:" else "Re-enter the PIN to confirm and prevent typos:",
                        fontSize = 13.sp
                    )

                    OutlinedTextField(
                        value = if (pinStep == 1) pinSetupFirst else pinSetupConfirm,
                        onValueChange = { input ->
                            if (input.length <= 4 && input.all { it.isDigit() }) {
                                if (pinStep == 1) pinSetupFirst = input else pinSetupConfirm = input
                                pinSetupError = null
                            }
                        },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true,
                        placeholder = { Text("••••") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    if (pinSetupError != null) {
                        Text(text = pinSetupError!!, color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (pinStep == 1) {
                            if (pinSetupFirst.length == 4) {
                                pinStep = 2
                            } else {
                                pinSetupError = "PIN must be exactly 4 digits."
                            }
                        } else {
                            if (pinSetupConfirm == pinSetupFirst) {
                                prefsManager.setAppPin(pinSetupConfirm)
                                showPinSetupDialog = false
                                Toast.makeText(context, "PIN lock enabled successfully", Toast.LENGTH_SHORT).show()
                            } else {
                                pinSetupError = "PINs do not match. Please re-enter."
                                pinSetupConfirm = ""
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                ) {
                    Text(if (pinStep == 1) "Next" else "Save PIN")
                }
            },
            dismissButton = {
                TextButton(onClick = { showPinSetupDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showCrashLogDialog) {
        AlertDialog(
            onDismissRequest = { showCrashLogDialog = false },
            title = { Text("Local Crash Diagnostics", fontWeight = FontWeight.Bold) },
            text = {
                Column(modifier = Modifier.heightIn(max = 280.dp).fillMaxWidth()) {
                    if (crashLogContent.isNullOrBlank()) {
                        Text("No crashes logged. The player is operating smoothly.", fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
                    } else {
                        LazyColumn {
                            item {
                                Text(
                                    text = crashLogContent!!,
                                    fontSize = 11.sp,
                                    fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace,
                                    lineHeight = 15.sp,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (!crashLogContent.isNullOrBlank()) {
                    Button(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "ZELVYN Crash Log")
                                putExtra(Intent.EXTRA_TEXT, crashLogContent)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, "Export Crash Log"))
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Export Log")
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    ZelvynCrashLogger.clearCrashLogs(context)
                    crashLogContent = null
                    showCrashLogDialog = false
                    Toast.makeText(context, "Crash logs cleared", Toast.LENGTH_SHORT).show()
                }) {
                    Text("Clear Logs")
                }
            }
        )
    }

    if (showResetConfirmDialog) {
        AlertDialog(
            onDismissRequest = { showResetConfirmDialog = false },
            title = { Text("Reset Playback Defaults?", fontWeight = FontWeight.Bold) },
            text = { Text("This will restore playback settings, subtitle styling, and audio equalizer to defaults. Your API key and PIN remain saved.") },
            confirmButton = {
                Button(
                    onClick = {
                        prefsManager.resetPlaybackDefaults()
                        showResetConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentError)
                ) {
                    Text("Reset")
                }
            },
            dismissButton = {
                TextButton(onClick = { showResetConfirmDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showFullResetDialog) {
        AlertDialog(
            onDismissRequest = { showFullResetDialog = false },
            title = { Text("Reset All App Data?", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("This will clear all app preferences, encryption keys, watch history, saved positions, and security PIN.", fontSize = 13.sp)
                    Text("Your video and audio files in device storage will NOT be modified or deleted.", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showFullResetDialog = false
                        prefsManager.clearAllAppData {
                            Toast.makeText(context, "App data reset completed.", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentError)
                ) {
                    Text("Reset Everything")
                }
            },
            dismissButton = {
                TextButton(onClick = { showFullResetDialog = false }) { Text("Cancel") }
            }
        )
    }
}

