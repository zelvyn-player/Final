package com.zelvyn.player.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Headphones
import androidx.compose.material.icons.rounded.Security
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.ui.common.ZelvynHeaderWordmark
import com.zelvyn.player.ui.theme.BrandAccent
import com.zelvyn.player.ui.theme.BrandAccentLight

@Composable
fun AboutScreen(
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
            }
            Text(text = "About ZELVYN", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize().padding(bottom = 20.dp)
        ) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(16.dp))
                        .padding(20.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        ZelvynHeaderWordmark()
                        Text(
                            text = "Next-Generation Media Player with Real-Time AI Speech Translation.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.secondary,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            item {
                AboutFeatureCard(
                    icon = Icons.Rounded.Headphones,
                    title = "Universal High-Performance Playback",
                    description = "Hardware-accelerated media engine powered by AndroidX Media3/ExoPlayer. Full studio 5-band Equalizer, Bass Boost, pitch-preserved time-stretching, and smooth Picture-in-Picture mode."
                )
            }

            item {
                AboutFeatureCard(
                    icon = Icons.Rounded.Translate,
                    title = "AI Live Speech Translation",
                    description = "Intercepts dialogue directly from the playback decoding pipeline. Automatically translates speech across 18+ languages with synchronized dual subtitle overlays and natural synthesized voice dubbing."
                )
            }

            item {
                AboutFeatureCard(
                    icon = Icons.Rounded.Security,
                    title = "Privacy-First Architecture",
                    description = "All local video and audio files remain 100% offline on your device. Audio chunks for translation are processed ephemerally with zero tracking. Your API keys are encrypted with hardware-backed Android KeyStore AES-256-GCM."
                )
            }
        }
    }
}

@Composable
fun AboutFeatureCard(
    icon: ImageVector,
    title: String,
    description: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp))
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(BrandAccentLight.copy(alpha = 0.45f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = BrandAccent, modifier = Modifier.size(22.dp))
        }

        Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            Text(text = description, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary, lineHeight = 18.sp)
        }
    }
}
