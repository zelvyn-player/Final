package com.zelvyn.player.ui.theme

import androidx.compose.ui.graphics.Color

// ZELVYN Studio Obsidian & OLED Blueprint Design Tokens
val ZelvynCanvasDark = Color(0xFF0B0B0E)
val ZelvynSurfaceElevatedDark = Color(0xFF141318)
val ZelvynCardSurfaceDark = Color(0xFF1A1920)
val ZelvynBorderDark = Color(0xFF282632)
val ZelvynBorderSubtle = Color(0xFF1E1D24)

val ZelvynCanvasLight = Color(0xFFF8F6F2)
val ZelvynSurfaceElevatedLight = Color(0xFFEFEBE4)
val ZelvynCardSurfaceLight = Color(0xFFFFFFFF)
val ZelvynBorderLight = Color(0xFFE2DCD2)

// Multi-Accent Theme Palette
val AccentOrangeCopper = Color(0xFFD47A36)
val AccentOrangeLight = Color(0xFFF3D9C4)
val AccentBlue = Color(0xFF3B82F6)
val AccentPurple = Color(0xFF8B5CF6)
val AccentGreen = Color(0xFF10B981)
val AccentRed = Color(0xFFEF4444)

val TextPrimaryDark = Color(0xFFFFFFFF)
val TextSecondaryDark = Color(0xFF8E8A99)
val TextTertiaryDark = Color(0xFF5A5666)

val TextPrimaryLight = Color(0xFF121115)
val TextSecondaryLight = Color(0xFF6B6675)
val TextTertiaryLight = Color(0xFFA09BAA)

val AccentWarning = Color(0xFFF59E0B)
val AccentSuccess = Color(0xFF10B981)
val AccentError = Color(0xFFEF4444)