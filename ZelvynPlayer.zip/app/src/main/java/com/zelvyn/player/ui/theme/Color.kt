package com.zelvyn.player.ui.theme

import androidx.compose.ui.graphics.Color

// ZELVYN Warm Luxury Design System (Light & Dark matching attached UI)
val CanvasLight = Color(0xFFF9F6F0)
val CardSurfaceLight = Color(0xFFFFFFFF)
val SurfaceElevatedLight = Color(0xFFF2EDE4)
val BorderSubtleLight = Color(0xFFE8E1D5)
val BorderHighlightLight = Color(0xFFD4C8B8)

val CanvasDark = Color(0xFF121113)
val CardSurfaceDark = Color(0xFF1B1A1E)
val SurfaceElevatedDark = Color(0xFF242228)
val BorderSubtleDark = Color(0xFF2F2C33)
val BorderHighlightDark = Color(0xFF45414B)

val BrandAccent = Color(0xFFD48A54)
val BrandAccentLight = Color(0xFFF4DFC8)
val BrandAccentDark = Color(0xFFB56A35)

val TextPrimaryLight = Color(0xFF1A191C)
val TextSecondaryLight = Color(0xFF7C766E)
val TextTertiaryLight = Color(0xFFB5AEA3)

val TextPrimaryDark = Color(0xFFF5F3EF)
val TextSecondaryDark = Color(0xFFA39E96)
val TextTertiaryDark = Color(0xFF6E6A63)

val AccentWarning = Color(0xFFD97706)
val AccentSuccess = Color(0xFF10B981)
val AccentError = Color(0xFFDC2626)
