package com.zelvyn.player.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.model.EqualizerPresetType
import com.zelvyn.player.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerSheet(
    audioDspManager: AudioDspManager,
    onDismiss: () -> Unit
) {
    val isEnabled by audioDspManager.isEnabled.collectAsState()
    val bands by audioDspManager.bands.collectAsState()
    val activePreset by audioDspManager.currentPreset.collectAsState()
    val bassBoost by audioDspManager.bassBoostStrength.collectAsState()
    val virtualizer by audioDspManager.virtualizerStrength.collectAsState()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "Studio Equalizer",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    IconButton(onClick = { audioDspManager.resetToDefaults() }) {
                        Icon(Icons.Rounded.RestartAlt, contentDescription = "Reset EQ", tint = BrandAccent)
                    }
                }
                Switch(
                    checked = isEnabled,
                    onCheckedChange = { audioDspManager.setEnabled(it) },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = CardSurfaceLight,
                        checkedTrackColor = BrandAccent
                    )
                )
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(
                    EqualizerPresetType.CUSTOM to "Custom",
                    EqualizerPresetType.ROCK to "Rock",
                    EqualizerPresetType.POP to "Pop",
                    EqualizerPresetType.CLASSIC to "Classic",
                    EqualizerPresetType.FLAT to "Flat"
                ).forEach { (preset, label) ->
                    val isSelected = activePreset == preset
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) BrandAccent else MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { audioDspManager.applyPreset(preset) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) CardSurfaceLight else MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                bands.forEach { band ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = "${band.gainDb.toInt()}dB",
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.secondary
                        )
                        Slider(
                            value = band.gainDb,
                            onValueChange = { audioDspManager.setBandGain(band.bandIndex, it) },
                            valueRange = -12f..12f,
                            modifier = Modifier
                                .height(95.dp)
                                .width(36.dp),
                            colors = SliderDefaults.colors(
                                thumbColor = BrandAccent,
                                activeTrackColor = BrandAccent
                            )
                        )
                        Text(
                            text = band.frequencyLabel,
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.tertiary
                        )
                    }
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Bass Boost (Hardware FX)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${bassBoost.toInt()}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Slider(
                    value = bassBoost,
                    onValueChange = { audioDspManager.setBassBoost(it) },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = BrandAccent,
                        activeTrackColor = BrandAccent
                    )
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Virtualizer (Surround)",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "${virtualizer.toInt()}%",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Slider(
                    value = virtualizer,
                    onValueChange = { audioDspManager.setVirtualizer(it) },
                    valueRange = 0f..100f,
                    colors = SliderDefaults.colors(
                        thumbColor = BrandAccent,
                        activeTrackColor = BrandAccent
                    )
                )
            }
        }
    }
}
