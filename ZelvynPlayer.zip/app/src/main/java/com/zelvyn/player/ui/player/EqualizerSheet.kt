package com.zelvyn.player.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.model.EqualizerPresetType

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EqualizerSheet(
    audioDspManager: AudioDspManager,
    onDismiss: () -> Unit
) {
    val isEnabled by audioDspManager.isEnabled.collectAsState()
    val bands by audioDspManager.bands.collectAsState()
    val activePreset by audioDspManager.currentPreset.collectAsState()
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Equalizer Header & Power Toggle
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Equalizer",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Switch(
                    checked = isEnabled,
                    onCheckedChange = { audioDspManager.setEnabled(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                )
            }

            // Preset Selector Chips
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(10.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                listOf(
                    EqualizerPresetType.FLAT to "Flat",
                    EqualizerPresetType.POP to "Pop",
                    EqualizerPresetType.ROCK to "Rock",
                    EqualizerPresetType.JAZZ to "Jazz",
                    EqualizerPresetType.CLASSIC to "Classic"
                ).forEach { (preset, label) ->
                    val isSelected = activePreset == preset
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (isSelected) MaterialTheme.colorScheme.surface else Color.Transparent)
                            .clickable { audioDspManager.applyPreset(preset) }
                            .padding(vertical = 6.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            // Graphic EQ dB Scale & Vertical Sliders
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text("+12dB", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                    Text("0dB", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                    Text("-12dB", fontSize = 9.sp, color = MaterialTheme.colorScheme.secondary)
                }

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(150.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    bands.forEach { band ->
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .height(120.dp)
                                    .width(36.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Slider(
                                    value = band.gainDb,
                                    onValueChange = { audioDspManager.setBandGain(band.bandIndex, it) },
                                    valueRange = -12f..12f,
                                    modifier = Modifier
                                        .graphicsLayer { rotationZ = 270f }
                                        .width(115.dp),
                                    colors = SliderDefaults.colors(
                                        thumbColor = MaterialTheme.colorScheme.primary,
                                        activeTrackColor = MaterialTheme.colorScheme.primary
                                    )
                                )
                            }
                            Text(
                                text = band.frequencyLabel,
                                fontSize = 9.sp,
                                color = MaterialTheme.colorScheme.secondary
                            )
                        }
                    }
                }
            }
        }
    }
}
