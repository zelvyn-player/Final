package com.zelvyn.player.ui.player

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.audio.DeviceHardwareController
import com.zelvyn.player.data.ExoPlayerTrackManager
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.model.*
import com.zelvyn.player.ui.theme.AccentError
import com.zelvyn.player.ui.theme.AccentSuccess
import com.zelvyn.player.ui.theme.BrandAccent

@OptIn(UnstableApi::class)
@kotlin.OptIn(ExperimentalFoundationApi::class)
@Composable
fun PlayerScreen(
    exoPlayer: ExoPlayer,
    video: VideoItem,
    queue: List<VideoItem>,
    activeSegment: TranslationSegment?,
    translationStatus: TranslationStatus,
    translationStatusMsg: String?,
    isTranslationActive: Boolean,
    audioDspManager: AudioDspManager,
    hardwareController: DeviceHardwareController,
    trackManager: ExoPlayerTrackManager,
    prefsManager: PreferencesManager,
    isPiPMode: Boolean,
    repeatMode: QueueRepeatMode = QueueRepeatMode.OFF,
    isShuffleActive: Boolean = false,
    onToggleRepeat: () -> Unit = {},
    onToggleShuffle: () -> Unit = {},
    onToggleOrientation: () -> Unit = {},
    onEnterPiP: () -> Unit,
    onBackPress: () -> Unit,
    onToggleLiveTranslation: () -> Unit,
    onSelectQueueItem: (VideoItem) -> Unit,
    onNavigateSubtitleStyle: () -> Unit = {}
) {
    val userPrefs by prefsManager.userPreferences.collectAsState()

    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(exoPlayer.isPlaying) }
    var isBuffering by remember { mutableStateOf(exoPlayer.playbackState == Player.STATE_BUFFERING) }
    var currentPos by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var bufferedPos by remember { mutableLongStateOf(0L) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }

    // Pinch-to-zoom and Pan state
    var zoomScale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var aspectRatioMode by remember { mutableStateOf(AspectRatioMode.FIT) }

    var showAudioSheet by remember { mutableStateOf(false) }
    var showSubtitleSheet by remember { mutableStateOf(false) }
    var showSpeedSheet by remember { mutableStateOf(false) }
    var showPlaybackSettingsSheet by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }

    var gestureVisible by remember { mutableStateOf(false) }
    var gestureIcon by remember { mutableStateOf(Icons.Rounded.VolumeUp) }
    var gestureLevel by remember { mutableFloatStateOf(0f) }
    var gestureTitle by remember { mutableStateOf("Volume") }

    LaunchedEffect(exoPlayer) {
        while (true) {
            currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
            duration = exoPlayer.duration.coerceAtLeast(1L)
            bufferedPos = exoPlayer.bufferedPosition.coerceAtLeast(0L)
            isPlaying = exoPlayer.isPlaying
            isBuffering = exoPlayer.playbackState == Player.STATE_BUFFERING
            kotlinx.coroutines.delay(100)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            // Tap gestures
            .pointerInput(isPiPMode) {
                if (!isPiPMode) {
                    detectTapGestures(
                        onTap = {
                            if (!isLocked) controlsVisible = !controlsVisible
                        },
                        onDoubleTap = { offset ->
                            if (!isLocked) {
                                if (zoomScale > 1.05f) {
                                    // Reset zoom on double tap if zoomed in
                                    zoomScale = 1f
                                    panOffset = Offset.Zero
                                } else {
                                    val screenWidth = size.width
                                    if (offset.x < screenWidth / 2) {
                                        exoPlayer.seekTo(
                                            (exoPlayer.currentPosition - userPrefs.skipIntervalSeconds * 1000).coerceAtLeast(0L)
                                        )
                                    } else {
                                        exoPlayer.seekTo(
                                            (exoPlayer.currentPosition + userPrefs.skipIntervalSeconds * 1000).coerceAtMost(exoPlayer.duration)
                                        )
                                    }
                                }
                            }
                        }
                    )
                }
            }
            // Pinch-to-zoom & Pan gesture
            .pointerInput(isPiPMode, isLocked) {
                if (!isPiPMode && !isLocked) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        zoomScale = (zoomScale * zoom).coerceIn(1f, 4f)
                        if (zoomScale > 1f) {
                            val maxPanX = (size.width * (zoomScale - 1f)) / 2f
                            val maxPanY = (size.height * (zoomScale - 1f)) / 2f
                            panOffset = Offset(
                                (panOffset.x + pan.x).coerceIn(-maxPanX, maxPanX),
                                (panOffset.y + pan.y).coerceIn(-maxPanY, maxPanY)
                            )
                        } else {
                            panOffset = Offset.Zero
                        }
                    }
                }
            }
            // Volume & Brightness Vertical Swipe
            .pointerInput(isPiPMode, isLocked, zoomScale) {
                if (!isPiPMode && !isLocked && zoomScale <= 1.05f) {
                    detectDragGestures(
                        onDragStart = { gestureVisible = true },
                        onDragEnd = { gestureVisible = false },
                        onDragCancel = { gestureVisible = false },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val screenWidth = size.width
                            val sens = userPrefs.gestureSensitivity
                            if (change.position.x > screenWidth / 2) {
                                hardwareController.adjustVolume((-dragAmount.y / (600f / sens)))
                                gestureIcon = Icons.Rounded.VolumeUp
                                gestureLevel = hardwareController.getVolumeLevel()
                                gestureTitle = "Volume ${(gestureLevel * 100).toInt()}%"
                            } else {
                                hardwareController.adjustBrightness((-dragAmount.y / (600f / sens)))
                                gestureIcon = Icons.Rounded.BrightnessHigh
                                gestureLevel = hardwareController.getBrightnessLevel()
                                gestureTitle = "Brightness ${(gestureLevel * 100).toInt()}%"
                            }
                        }
                    )
                }
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    resizeMode = when (aspectRatioMode) {
                        AspectRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        AspectRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        AspectRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    }
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { view ->
                view.resizeMode = when (aspectRatioMode) {
                    AspectRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    AspectRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    AspectRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoomScale
                    scaleY = zoomScale
                    translationX = panOffset.x
                    translationY = panOffset.y
                }
        )

        if (isBuffering) {
            CircularProgressIndicator(
                color = BrandAccent,
                modifier = Modifier
                    .size(44.dp)
                    .align(Alignment.Center)
            )
        }

        // Live Translation & Pipeline Status Banner
        if (isTranslationActive && controlsVisible && !isPiPMode) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 64.dp)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.85f))
                    .border(
                        1.dp,
                        if (translationStatus == TranslationStatus.ERROR_API_KEY) AccentError else BrandAccent,
                        RoundedCornerShape(20.dp)
                    )
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val statusDotColor = when (translationStatus) {
                        TranslationStatus.TRANSLATING -> BrandAccent
                        TranslationStatus.ACTIVE -> AccentSuccess
                        TranslationStatus.ERROR_API_KEY, TranslationStatus.ERROR_NO_INTERNET, TranslationStatus.ERROR_GENERIC -> AccentError
                        else -> Color.Gray
                    }
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(statusDotColor))
                    Text(
                        text = translationStatusMsg ?: when (translationStatus) {
                            TranslationStatus.CAPTURING_AUDIO -> "Listening to audio pipeline..."
                            TranslationStatus.TRANSLATING -> "Translating dialogue via Gemini..."
                            TranslationStatus.ACTIVE -> "AI Live Translation Active"
                            TranslationStatus.ERROR_API_KEY -> "Gemini API Key Missing (Add in Settings)"
                            TranslationStatus.ERROR_NO_INTERNET -> "No Internet Connection"
                            TranslationStatus.NO_SPEECH -> "No dialogue detected in scene"
                            else -> "Live Speech Translation Ready"
                        },
                        color = Color.White,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        DualSubtitleOverlay(
            segment = activeSegment,
            fontSizeSp = userPrefs.subtitleFontSizeSp,
            colorArgb = userPrefs.subtitleColorArgb,
            bgMode = userPrefs.subtitleBgMode,
            bgAlpha = userPrefs.subtitleBackgroundAlpha,
            fontFamilyType = userPrefs.subtitleFontFamily,
            isBold = userPrefs.subtitleBold,
            modifier = Modifier
                .align(if (userPrefs.subtitlePosition == "Top") Alignment.TopCenter else Alignment.BottomCenter)
                .padding(
                    bottom = if (controlsVisible && !isPiPMode) 125.dp else 24.dp,
                    top = if (controlsVisible && !isPiPMode) 80.dp else 24.dp
                )
                .padding(horizontal = 20.dp)
        )

        if (!isPiPMode) {
            GestureFeedbackIndicator(
                visible = gestureVisible,
                icon = gestureIcon,
                level = gestureLevel,
                title = gestureTitle,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        AnimatedVisibility(
            visible = controlsVisible && !isPiPMode,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.70f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.88f)
                            )
                        )
                    )
            ) {
                // Top Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackPress) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .padding(horizontal = 6.dp)
                    ) {
                        Text(
                            text = video.title,
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            modifier = Modifier.basicMarquee()
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color.Black.copy(alpha = 0.6f))
                                    .border(0.5.dp, Color.White.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(text = video.resolution, color = BrandAccent, fontSize = 8.sp, fontWeight = FontWeight.Bold)
                            }
                            if (zoomScale > 1.05f) {
                                Text(
                                    text = "${((zoomScale * 10).toInt() / 10f)}x Zoom",
                                    color = BrandAccent,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // Aspect Ratio Button (Fit / Fill / Zoom)
                    IconButton(onClick = {
                        aspectRatioMode = when (aspectRatioMode) {
                            AspectRatioMode.FIT -> AspectRatioMode.FILL
                            AspectRatioMode.FILL -> AspectRatioMode.ZOOM
                            AspectRatioMode.ZOOM -> AspectRatioMode.FIT
                        }
                    }) {
                        Icon(Icons.Rounded.AspectRatio, contentDescription = "Aspect Ratio", tint = Color.White)
                    }
                    IconButton(onClick = { showQueueSheet = true }) {
                        Icon(Icons.Rounded.FormatListNumbered, contentDescription = "Queue", tint = Color.White)
                    }
                    IconButton(onClick = onEnterPiP) {
                        Icon(Icons.Rounded.PictureInPictureAlt, contentDescription = "PiP", tint = Color.White)
                    }
                    IconButton(onClick = { showPlaybackSettingsSheet = true }) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = "More", tint = Color.White)
                    }
                }

                // Middle Transport Controls
                if (!isLocked) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .align(Alignment.Center),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { isLocked = true }) {
                            Icon(Icons.Rounded.LockOpen, contentDescription = "Lock", tint = Color.White)
                        }
                        IconButton(onClick = {
                            exoPlayer.seekTo((exoPlayer.currentPosition - 10000L).coerceAtLeast(0L))
                        }) {
                            Icon(Icons.Rounded.Replay10, contentDescription = "Rewind", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                        IconButton(onClick = { exoPlayer.seekToPreviousMediaItem() }) {
                            Icon(Icons.Rounded.SkipPrevious, contentDescription = "Prev", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(BrandAccent)
                                .clickable {
                                    if (exoPlayer.playbackState == Player.STATE_ENDED) {
                                        exoPlayer.seekTo(0L)
                                        exoPlayer.play()
                                        isPlaying = true
                                    } else if (isPlaying) {
                                        exoPlayer.pause()
                                        isPlaying = false
                                    } else {
                                        exoPlayer.play()
                                        isPlaying = true
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = Color.White,
                                modifier = Modifier.size(36.dp)
                            )
                        }
                        IconButton(onClick = { exoPlayer.seekToNextMediaItem() }) {
                            Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                        IconButton(onClick = {
                            exoPlayer.seekTo((exoPlayer.currentPosition + 10000L).coerceAtMost(exoPlayer.duration))
                        }) {
                            Icon(Icons.Rounded.Forward10, contentDescription = "Forward", tint = Color.White, modifier = Modifier.size(32.dp))
                        }
                        IconButton(onClick = onToggleOrientation) {
                            Icon(Icons.Rounded.ScreenRotation, contentDescription = "Rotate", tint = Color.White)
                        }
                    }
                } else {
                    IconButton(
                        onClick = { isLocked = false },
                        modifier = Modifier.align(Alignment.Center)
                    ) {
                        Icon(
                            Icons.Rounded.Lock,
                            contentDescription = "Unlock",
                            tint = BrandAccent,
                            modifier = Modifier.size(42.dp)
                        )
                    }
                }

                // Bottom Scrubber Timeline & Quick Toolbar
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(formatTime(currentPos), color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp)
                        ZelvynScrubber(
                            currentPos = currentPos,
                            duration = duration,
                            bufferedPos = bufferedPos,
                            onSeek = { seekPos -> exoPlayer.seekTo(seekPos) },
                            modifier = Modifier
                                .weight(1f)
                                .padding(horizontal = 10.dp)
                        )
                        Text(formatTime(duration), color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp)
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 6.dp)
                            .clip(RoundedCornerShape(30.dp))
                            .background(Color.Black.copy(alpha = 0.88f))
                            .border(1.dp, Color.White.copy(alpha = 0.18f), RoundedCornerShape(30.dp))
                            .padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceAround,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            PlayerToolbarItem(
                                icon = Icons.Rounded.Subtitles,
                                label = "Subtitle",
                                isSelected = false,
                                onClick = { showSubtitleSheet = true }
                            )
                            PlayerToolbarItem(
                                icon = Icons.Rounded.Audiotrack,
                                label = "Audio",
                                isSelected = false,
                                onClick = { showAudioSheet = true }
                            )
                            PlayerToolbarItem(
                                icon = Icons.Rounded.Translate,
                                label = "Translate",
                                isSelected = isTranslationActive,
                                onClick = onToggleLiveTranslation
                            )
                            PlayerToolbarItem(
                                icon = Icons.Rounded.Speed,
                                label = "Speed",
                                isSelected = false,
                                onClick = { showSpeedSheet = true }
                            )
                            PlayerToolbarItem(
                                icon = Icons.Rounded.GraphicEq,
                                label = "EQ",
                                isSelected = false,
                                onClick = { showEqualizerSheet = true }
                            )
                        }
                    }
                }
            }
        }

        if (showSubtitleSheet) {
            SubtitleTracksSheet(
                trackManager = trackManager,
                prefsManager = prefsManager,
                onNavigateSubtitleStyle = onNavigateSubtitleStyle,
                onDismiss = { showSubtitleSheet = false }
            )
        }

        if (showAudioSheet) {
            AudioTracksSheet(
                trackManager = trackManager,
                onDismiss = { showAudioSheet = false }
            )
        }

        if (showSpeedSheet) {
            SpeedSheet(
                currentSpeed = playbackSpeed,
                onSpeedChange = { newSpeed ->
                    playbackSpeed = newSpeed
                    exoPlayer.playbackParameters = PlaybackParameters(newSpeed, 1.0f)
                },
                onDismiss = { showSpeedSheet = false }
            )
        }

        if (showPlaybackSettingsSheet) {
            PlaybackSettingsSheet(
                playbackSpeed = playbackSpeed,
                prefsManager = prefsManager,
                onSpeedChange = { newSpeed ->
                    playbackSpeed = newSpeed
                    exoPlayer.playbackParameters = PlaybackParameters(newSpeed, 1.0f)
                },
                onDismiss = { showPlaybackSettingsSheet = false }
            )
        }

        if (showEqualizerSheet) {
            EqualizerSheet(
                audioDspManager = audioDspManager,
                onDismiss = { showEqualizerSheet = false }
            )
        }

        if (showQueueSheet) {
            QueueSheet(
                queue = queue,
                currentPlayingId = video.id,
                repeatMode = repeatMode,
                isShuffleActive = isShuffleActive,
                onToggleRepeat = onToggleRepeat,
                onToggleShuffle = onToggleShuffle,
                onSelectQueueItem = {
                    onSelectQueueItem(it)
                    showQueueSheet = false
                },
                onDismiss = { showQueueSheet = false }
            )
        }
    }
}

@Composable
fun PlayerToolbarItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.clickable { onClick() }
    ) {
        Icon(
            icon,
            contentDescription = label,
            tint = if (isSelected) BrandAccent else Color.White,
            modifier = Modifier.size(18.dp)
        )
        Text(
            text = label,
            fontSize = 10.sp,
            color = if (isSelected) BrandAccent else Color.White.copy(alpha = 0.75f)
        )
    }
}
