
package com.zelvyn.player.ui.player

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.audio.DeviceHardwareController
import com.zelvyn.player.data.ExoPlayerTrackManager
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.model.*

@OptIn(UnstableApi::class)
@kotlin.OptIn(ExperimentalFoundationApi::class)
@Composable
fun PlayerScreen(
    exoPlayer: ExoPlayer,
    video: VideoItem,
    queue: List<VideoItem>,
    activeSegment: TranslationSegment?,
    translationStatus: TranslationStatus,
    translationStatusMsg: String?,
    isTranslationActive: Boolean,
    audioDspManager: AudioDspManager,
    hardwareController: DeviceHardwareController,
    trackManager: ExoPlayerTrackManager,
    prefsManager: PreferencesManager,
    isPiPMode: Boolean,
    repeatMode: QueueRepeatMode = QueueRepeatMode.OFF,
    isShuffleActive: Boolean = false,
    onToggleRepeat: () -> Unit = {},
    onToggleShuffle: () -> Unit = {},
    onToggleOrientation: () -> Unit = {},
    onEnterPiP: () -> Unit,
    onBackPress: () -> Unit,
    onToggleLiveTranslation: () -> Unit,
    onSelectQueueItem: (VideoItem) -> Unit,
    onNavigateSubtitleStyle: () -> Unit = {}
) {
    val userPrefs by prefsManager.userPreferences.collectAsState()

    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(exoPlayer.isPlaying) }
    var isBuffering by remember { mutableStateOf(exoPlayer.playbackState == Player.STATE_BUFFERING) }
    var currentPos by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }
    var bufferedPos by remember { mutableLongStateOf(0L) }
    var playbackSpeed by remember { mutableFloatStateOf(userPrefs.lastPlaybackSpeed) }

    var zoomScale by remember { mutableFloatStateOf(1f) }
    var panOffset by remember { mutableStateOf(Offset.Zero) }
    var aspectRatioMode by remember { mutableStateOf(AspectRatioMode.FIT) }

    var showAudioSheet by remember { mutableStateOf(false) }
    var showSubtitleSheet by remember { mutableStateOf(false) }
    var showSpeedSheet by remember { mutableStateOf(false) }
    var showPlaybackSettingsSheet by remember { mutableStateOf(false) }
    var showEqualizerSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }

    var gestureVisible by remember { mutableStateOf(false) }
    var gestureIcon by remember { mutableStateOf(Icons.Rounded.VolumeUp) }
    var gestureLevel by remember { mutableFloatStateOf(0f) }
    var gestureTitle by remember { mutableStateOf("Volume") }

    LaunchedEffect(exoPlayer) {
        while (true) {
            currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
            duration = exoPlayer.duration.coerceAtLeast(1L)
            bufferedPos = exoPlayer.bufferedPosition.coerceAtLeast(0L)
            isPlaying = exoPlayer.isPlaying
            isBuffering = exoPlayer.playbackState == Player.STATE_BUFFERING
            kotlinx.coroutines.delay(150)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(isPiPMode, isLocked) {
                if (!isPiPMode) {
                    detectTapGestures(
                        onTap = {
                            if (!isLocked) controlsVisible = !controlsVisible
                        },
                        onDoubleTap = { offset ->
                            if (!isLocked) {
                                if (zoomScale > 1.05f) {
                                    zoomScale = 1f
                                    panOffset = Offset.Zero
                                } else {
                                    val screenWidth = size.width
                                    if (offset.x < screenWidth / 2) {
                                        exoPlayer.seekTo((exoPlayer.currentPosition - userPrefs.skipIntervalSeconds * 1000).coerceAtLeast(0L))
                                    } else {
                                        exoPlayer.seekTo((exoPlayer.currentPosition + userPrefs.skipIntervalSeconds * 1000).coerceAtMost(exoPlayer.duration))
                                    }
                                }
                            }
                        }
                    )
                }
            }
            .pointerInput(isPiPMode, isLocked) {
                if (!isPiPMode && !isLocked) {
                    detectTransformGestures { _, pan, zoom, _ ->
                        zoomScale = (zoomScale * zoom).coerceIn(1f, 4f)
                        if (zoomScale > 1f) {
                            val maxPanX = (size.width * (zoomScale - 1f)) / 2f
                            val maxPanY = (size.height * (zoomScale - 1f)) / 2f
                            panOffset = Offset(
                                (panOffset.x + pan.x).coerceIn(-maxPanX, maxPanX),
                                (panOffset.y + pan.y).coerceIn(-maxPanY, maxPanY)
                            )
                        } else {
                            panOffset = Offset.Zero
                        }
                    }
                }
            }
            .pointerInput(isPiPMode, isLocked, zoomScale) {
                if (!isPiPMode && !isLocked && zoomScale <= 1.05f) {
                    detectDragGestures(
                        onDragStart = { gestureVisible = true },
                        onDragEnd = { gestureVisible = false },
                        onDragCancel = { gestureVisible = false },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            val screenWidth = size.width
                            val sens = userPrefs.gestureSensitivity
                            if (change.position.x > screenWidth / 2) {
                                hardwareController.adjustVolume((-dragAmount.y / (600f / sens)))
                                gestureIcon = Icons.Rounded.VolumeUp
                                gestureLevel = hardwareController.getVolumeLevel()
                                gestureTitle = "Volume ${(gestureLevel * 100).toInt()}%"
                            } else {
                                hardwareController.adjustBrightness((-dragAmount.y / (600f / sens)))
                                gestureIcon = Icons.Rounded.BrightnessHigh
                                gestureLevel = hardwareController.getBrightnessLevel()
                                gestureTitle = "Brightness ${(gestureLevel * 100).toInt()}%"
                            }
                        }
                    )
                }
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    resizeMode = when (aspectRatioMode) {
                        AspectRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                        AspectRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                        AspectRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    }
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            update = { view ->
                view.resizeMode = when (aspectRatioMode) {
                    AspectRatioMode.FIT -> AspectRatioFrameLayout.RESIZE_MODE_FIT
                    AspectRatioMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    AspectRatioMode.ZOOM -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = zoomScale
                    scaleY = zoomScale
                    translationX = panOffset.x
                    translationY = panOffset.y
                }
        )

        if (isBuffering) {
            CircularProgressIndicator(
                color = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(44.dp).align(Alignment.Center)
            )
        }

        DualSubtitleOverlay(
            segment = activeSegment,
            fontSizeSp = userPrefs.subtitleFontSizeSp,
            colorArgb = userPrefs.subtitleColorArgb,
            bgMode = userPrefs.subtitleBgMode,
            bgAlpha = userPrefs.subtitleBackgroundAlpha,
            fontFamilyType = userPrefs.subtitleFontFamily,
            isBold = userPrefs.subtitleBold,
            modifier = Modifier
                .align(if (userPrefs.subtitlePosition == "Top") Alignment.TopCenter else Alignment.BottomCenter)
                .padding(
                    bottom = if (controlsVisible && !isPiPMode) 130.dp else 24.dp,
                    top = if (controlsVisible && !isPiPMode) 80.dp else 24.dp
                )
                .padding(horizontal = 20.dp)
        )

        if (!isPiPMode) {
            GestureFeedbackIndicator(
                visible = gestureVisible,
                icon = gestureIcon,
                level = gestureLevel,
                title = gestureTitle,
                modifier = Modifier.align(Alignment.Center)
            )
        }

        // Unobtrusive Top-Left Lock Pill Container
        if (isLocked && !isPiPMode) {
            Box(
                modifier = Modifier
                    .statusBarsPadding()
                    .padding(top = 16.dp, start = 16.dp)
                    .align(Alignment.TopStart)
                    .clip(RoundedCornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.65f))
                    .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(20.dp))
                    .clickable { isLocked = false }
                    .padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Icon(
                        Icons.Rounded.Lock,
                        contentDescription = "Unlock Screen",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(16.dp)
                    )
                    Text(
                        text = "Locked",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }

        AnimatedVisibility(
            visible = controlsVisible && !isPiPMode && !isLocked,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.75f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.90f)
                            )
                        )
                    )
            ) {
                // Top Header Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackPress) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Text(
                        text = video.title,
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        modifier = Modifier.weight(1f).basicMarquee().padding(horizontal = 6.dp)
                    )

                    IconButton(onClick = { showSubtitleSheet = true }) {
                        Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = "Subtitle", tint = Color.White)
                    }
                    IconButton(onClick = onEnterPiP) {
                        Icon(Icons.Rounded.PictureInPictureAlt, contentDescription = "PiP", tint = Color.White)
                    }
                    IconButton(onClick = { prefsManager.toggleFavorite(video.uri.toString()) }) {
                        Icon(
                            if (video.isFavorite) Icons.Rounded.Star else Icons.Rounded.StarBorder,
                            contentDescription = "Favorite",
                            tint = if (video.isFavorite) MaterialTheme.colorScheme.primary else Color.White
                        )
                    }
                    IconButton(onClick = { showPlaybackSettingsSheet = true }) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = "Menu", tint = Color.White)
                    }
                }

                // Left Floating Toolbar
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterStart)
                        .padding(start = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    IconButton(onClick = { isLocked = true }) {
                        Icon(Icons.Rounded.LockOpen, contentDescription = "Lock", tint = Color.White)
                    }
                    IconButton(onClick = {
                        aspectRatioMode = when (aspectRatioMode) {
                            AspectRatioMode.FIT -> AspectRatioMode.FILL
                            AspectRatioMode.FILL -> AspectRatioMode.ZOOM
                            AspectRatioMode.ZOOM -> AspectRatioMode.FIT
                        }
                    }) {
                        Icon(Icons.Rounded.FitScreen, contentDescription = "Aspect Ratio (${aspectRatioMode.label})", tint = Color.White)
                    }
                    IconButton(onClick = { showEqualizerSheet = true }) {
                        Icon(Icons.Rounded.Tune, contentDescription = "Equalizer", tint = Color.White)
                    }
                    IconButton(onClick = { showPlaybackSettingsSheet = true }) {
                        Icon(Icons.Rounded.MoreHoriz, contentDescription = "More", tint = Color.White)
                    }
                }

                // Right Floating Toolbar
                Column(
                    modifier = Modifier
                        .align(Alignment.CenterEnd)
                        .padding(end = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "${((playbackSpeed * 10).toInt() / 10f)}x",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color.Black.copy(alpha = 0.5f))
                            .clickable { showSpeedSheet = true }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                    IconButton(onClick = {
                        zoomScale = if (zoomScale > 1.05f) 1f else 1.5f
                        panOffset = Offset.Zero
                    }) {
                        Icon(Icons.Rounded.ZoomIn, contentDescription = "Zoom", tint = Color.White)
                    }
                    IconButton(onClick = onToggleOrientation) {
                        Icon(Icons.Rounded.ScreenRotation, contentDescription = "Rotate Screen", tint = Color.White)
                    }
                }

                // Bottom Deck
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(bottom = 12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(formatTime(currentPos), color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp)
                        ZelvynScrubber(
                            currentPos = currentPos,
                            duration = duration,
                            bufferedPos = bufferedPos,
                            onSeek = { seekPos -> exoPlayer.seekTo(seekPos) },
                            modifier = Modifier.weight(1f).padding(horizontal = 10.dp)
                        )
                        Text(formatTime(duration), color = Color.White.copy(alpha = 0.75f), fontSize = 11.sp)
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = { showSubtitleSheet = true }) {
                            Icon(Icons.Rounded.ChatBubbleOutline, contentDescription = "Subtitle", tint = Color.White)
                        }
                        IconButton(onClick = {
                            exoPlayer.seekTo((exoPlayer.currentPosition - 10000L).coerceAtLeast(0L))
                        }) {
                            Icon(Icons.Rounded.Replay10, contentDescription = "Rewind 10s", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        IconButton(onClick = { exoPlayer.seekToPreviousMediaItem() }) {
                            Icon(Icons.Rounded.SkipPrevious, contentDescription = "Prev", tint = Color.White, modifier = Modifier.size(28.dp))
                        }

                        Box(
                            modifier = Modifier
                                .size(60.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.90f))
                                .clickable {
                                    if (exoPlayer.playbackState == Player.STATE_ENDED) {
                                        exoPlayer.seekTo(0L)
                                        exoPlayer.play()
                                        isPlaying = true
                                    } else if (isPlaying) {
                                        exoPlayer.pause()
                                        isPlaying = false
                                    } else {
                                        exoPlayer.play()
                                        isPlaying = true
                                    }
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow,
                                contentDescription = "Play/Pause",
                                tint = Color.Black,
                                modifier = Modifier.size(34.dp)
                            )
                        }

                        IconButton(onClick = { exoPlayer.seekToNextMediaItem() }) {
                            Icon(Icons.Rounded.SkipNext, contentDescription = "Next", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        IconButton(onClick = {
                            exoPlayer.seekTo((exoPlayer.currentPosition + 10000L).coerceAtMost(exoPlayer.duration))
                        }) {
                            Icon(Icons.Rounded.Forward10, contentDescription = "Forward 10s", tint = Color.White, modifier = Modifier.size(28.dp))
                        }
                        IconButton(onClick = onToggleOrientation) {
                            Icon(Icons.Rounded.Fullscreen, contentDescription = "Fullscreen", tint = Color.White)
                        }
                    }
                }
            }
        }

        if (showSubtitleSheet) {
            SubtitleTracksSheet(
                trackManager = trackManager,
                prefsManager = prefsManager,
                onNavigateSubtitleStyle = onNavigateSubtitleStyle,
                onDismiss = { showSubtitleSheet = false }
            )
        }

        if (showAudioSheet) {
            AudioTracksSheet(
                trackManager = trackManager,
                onDismiss = { showAudioSheet = false }
            )
        }

        if (showSpeedSheet) {
            SpeedSheet(
                currentSpeed = playbackSpeed,
                prefsManager = prefsManager,
                onSpeedChange = { newSpeed ->
                    playbackSpeed = newSpeed
                    exoPlayer.playbackParameters = PlaybackParameters(newSpeed, 1.0f)
                },
                onDismiss = { showSpeedSheet = false }
            )
        }

        if (showPlaybackSettingsSheet) {
            PlaybackSettingsSheet(
                playbackSpeed = playbackSpeed,
                prefsManager = prefsManager,
                onSpeedChange = { newSpeed ->
                    playbackSpeed = newSpeed
                    exoPlayer.playbackParameters = PlaybackParameters(newSpeed, 1.0f)
                },
                onDismiss = { showPlaybackSettingsSheet = false }
            )
        }

        if (showEqualizerSheet) {
            EqualizerSheet(
                audioDspManager = audioDspManager,
                onDismiss = { showEqualizerSheet = false }
            )
        }

        if (showQueueSheet) {
            QueueSheet(
                queue = queue,
                currentPlayingId = video.id,
                onSelectQueueItem = {
                    onSelectQueueItem(it)
                    showQueueSheet = false
                },
                onDismiss = { showQueueSheet = false }
            )
        }
    }
}

