package com.zelvyn.player.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.Virtualizer
import com.zelvyn.player.model.EqualizerBandState
import com.zelvyn.player.model.EqualizerPresetType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AudioDspManager {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var boundAudioSessionId: Int = 0

    private val _isEnabled = MutableStateFlow(true)
    val isEnabled: StateFlow<Boolean> = _isEnabled.asStateFlow()

    private val defaultBands = listOf(
        EqualizerBandState(0, "60Hz", 0f),
        EqualizerBandState(1, "230Hz", 0f),
        EqualizerBandState(2, "910Hz", 0f),
        EqualizerBandState(3, "3.6kHz", 0f),
        EqualizerBandState(4, "14kHz", 0f)
    )

    private val _bands = MutableStateFlow(defaultBands)
    val bands: StateFlow<List<EqualizerBandState>> = _bands.asStateFlow()

    private val _currentPreset = MutableStateFlow(EqualizerPresetType.FLAT)
    val currentPreset: StateFlow<EqualizerPresetType> = _currentPreset.asStateFlow()

    private val _bassBoostStrength = MutableStateFlow(0f)
    val bassBoostStrength: StateFlow<Float> = _bassBoostStrength.asStateFlow()

    private val _virtualizerStrength = MutableStateFlow(0f)
    val virtualizerStrength: StateFlow<Float> = _virtualizerStrength.asStateFlow()

    fun bindAudioSession(audioSessionId: Int) {
        if (audioSessionId <= 0) return
        this.boundAudioSessionId = audioSessionId
        try {
            release()
            equalizer = Equalizer(1000, audioSessionId).apply {
                enabled = _isEnabled.value
                val minLevel = bandLevelRange[0]
                val maxLevel = bandLevelRange[1]
                _bands.value.forEach { band ->
                    if (band.bandIndex < numberOfBands) {
                        val level = ((band.gainDb / 12f) * maxLevel).toInt().coerceIn(minLevel.toInt(), maxLevel.toInt())
                        setBandLevel(band.bandIndex.toShort(), level.toShort())
                    }
                }
            }

            bassBoost = BassBoost(1000, audioSessionId).apply {
                enabled = _isEnabled.value
                if (strengthSupported) {
                    setStrength((_bassBoostStrength.value * 10).toInt().coerceIn(0, 1000).toShort())
                }
            }

            virtualizer = Virtualizer(1000, audioSessionId).apply {
                enabled = _isEnabled.value
                if (strengthSupported) {
                    setStrength((_virtualizerStrength.value * 10).toInt().coerceIn(0, 1000).toShort())
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setEnabled(enabled: Boolean) {
        _isEnabled.value = enabled
        try {
            equalizer?.enabled = enabled
            bassBoost?.enabled = enabled
            virtualizer?.enabled = enabled
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun setBandGain(bandIndex: Int, gainDb: Float) {
        val currentList = _bands.value.toMutableList()
        if (bandIndex in currentList.indices) {
            currentList[bandIndex] = currentList[bandIndex].copy(gainDb = gainDb)
            _bands.value = currentList
            _currentPreset.value = EqualizerPresetType.CUSTOM

            equalizer?.let { eq ->
                try {
                    val minLevel = eq.bandLevelRange[0]
                    val maxLevel = eq.bandLevelRange[1]
                    val calculated = ((gainDb / 12f) * maxLevel).toInt().coerceIn(minLevel.toInt(), maxLevel.toInt())
                    eq.setBandLevel(bandIndex.toShort(), calculated.toShort())
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }

    fun applyPreset(preset: EqualizerPresetType) {
        _currentPreset.value = preset
        val gains = when (preset) {
            EqualizerPresetType.FLAT -> listOf(0f, 0f, 0f, 0f, 0f)
            EqualizerPresetType.POP -> listOf(-1f, 1f, 3f, 2f, -1f)
            EqualizerPresetType.ROCK -> listOf(5f, 3f, -1f, 3f, 5f)
            EqualizerPresetType.CLASSIC -> listOf(4f, 2f, 0f, 2f, -2f)
            EqualizerPresetType.CUSTOM -> return
        }

        val updated = _bands.value.mapIndexed { index, band ->
            band.copy(gainDb = gains.getOrElse(index) { 0f })
        }
        _bands.value = updated
        updated.forEach { setBandGain(it.bandIndex, it.gainDb) }
    }

    fun setBassBoost(strength: Float) {
        _bassBoostStrength.value = strength
        bassBoost?.let {
            if (it.strengthSupported) {
                it.setStrength((strength * 10).toInt().coerceIn(0, 1000).toShort())
            }
        }
    }

    fun setVirtualizer(strength: Float) {
        _virtualizerStrength.value = strength
        virtualizer?.let {
            if (it.strengthSupported) {
                it.setStrength((strength * 10).toInt().coerceIn(0, 1000).toShort())
            }
        }
    }

    fun resetToDefaults() {
        _isEnabled.value = true
        _bassBoostStrength.value = 0f
        _virtualizerStrength.value = 0f
        applyPreset(EqualizerPresetType.FLAT)
        bassBoost?.let { if (it.strengthSupported) it.setStrength(0) }
        virtualizer?.let { if (it.strengthSupported) it.setStrength(0) }
    }

    fun release() {
        try {
            equalizer?.release()
            bassBoost?.release()
            virtualizer?.release()
        } catch (e: Exception) {
            e.printStackTrace()
        }
        equalizer = null
        bassBoost = null
        virtualizer = null
    }
}
