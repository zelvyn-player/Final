package com.zelvyn.player.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ZelvynBrandMark(
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onBackground
) {
    Canvas(modifier = modifier.size(36.dp, 28.dp)) {
        val w = size.width
        val h = size.height

        // Top horizontal wing of Z
        val topWing = Path().apply {
            moveTo(w * 0.16f, 0f)
            lineTo(w * 0.98f, 0f)
            lineTo(w * 0.76f, h * 0.32f)
            lineTo(w * 0.38f, h * 0.32f)
            close()
        }
        drawPath(topWing, tint)

        // Diagonal sweep & base with curved notch
        val baseWing = Path().apply {
            moveTo(w * 0.22f, h * 0.38f)
            lineTo(w * 0.52f, h * 0.38f)
            cubicTo(w * 0.42f, h * 0.52f, w * 0.34f, h * 0.65f, w * 0.22f, h * 0.82f)
            lineTo(w * 0.88f, h * 0.82f)
            lineTo(w * 0.74f, h)
            lineTo(0f, h)
            cubicTo(w * 0.12f, h * 0.72f, w * 0.22f, h * 0.55f, w * 0.22f, h * 0.38f)
            close()
        }
        drawPath(baseWing, tint)

        // Integrated Play triangle inside negative space
        val playPath = Path().apply {
            moveTo(w * 0.48f, h * 0.42f)
            lineTo(w * 0.68f, h * 0.56f)
            lineTo(w * 0.48f, h * 0.70f)
            close()
        }
        drawPath(playPath, tint)
    }
}

@Composable
fun ZelvynHeaderWordmark(
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onBackground,
    showSubtitle: Boolean = true
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        ZelvynBrandMark(tint = tint)
        Column {
            Text(
                text = "Z E L V Y N",
                fontSize = 16.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 4.sp,
                fontFamily = FontFamily.SansSerif,
                color = tint
            )
            if (showSubtitle) {
                Text(
                    text = "— MEDIA PLAYER —",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.SemiBold,
                    letterSpacing = 2.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}
