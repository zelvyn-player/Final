package com.zelvyn.player.ui.common

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun ZelvynBrandMark(
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onBackground
) {
    Canvas(modifier = modifier.size(38.dp, 30.dp)) {
        val w = size.width
        val h = size.height

        // Top sweep of the Z
        val topWing = Path().apply {
            moveTo(w * 0.12f, 0f)
            lineTo(w * 0.98f, 0f)
            lineTo(w * 0.74f, h * 0.34f)
            lineTo(w * 0.36f, h * 0.34f)
            close()
        }
        drawPath(topWing, tint)

        // Bottom curved base sweep of the Z
        val baseWing = Path().apply {
            moveTo(w * 0.20f, h * 0.38f)
            lineTo(w * 0.52f, h * 0.38f)
            cubicTo(w * 0.40f, h * 0.54f, w * 0.30f, h * 0.68f, w * 0.20f, h * 0.84f)
            lineTo(w * 0.90f, h * 0.84f)
            lineTo(w * 0.76f, h)
            lineTo(0f, h)
            cubicTo(w * 0.10f, h * 0.74f, w * 0.20f, h * 0.56f, w * 0.20f, h * 0.38f)
            close()
        }
        drawPath(baseWing, tint)

        // Integrated geometric Play triangle
        val playPath = Path().apply {
            moveTo(w * 0.46f, h * 0.44f)
            lineTo(w * 0.68f, h * 0.58f)
            lineTo(w * 0.46f, h * 0.72f)
            close()
        }
        drawPath(playPath, tint)
    }
}

@Composable
fun ZelvynHeaderWordmark(
    modifier: Modifier = Modifier,
    tint: Color = MaterialTheme.colorScheme.onBackground,
    showSubtitle: Boolean = true
) {
    Row(
        modifier = modifier,
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        ZelvynBrandMark(tint = tint)
        Column {
            Text(
                text = "Z E L V Y N",
                fontSize = 17.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 4.sp,
                fontFamily = FontFamily.SansSerif,
                color = tint
            )
            if (showSubtitle) {
                Text(
                    text = "— MEDIA PLAYER —",
                    fontSize = 8.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp,
                    color = MaterialTheme.colorScheme.secondary
                )
            }
        }
    }
}