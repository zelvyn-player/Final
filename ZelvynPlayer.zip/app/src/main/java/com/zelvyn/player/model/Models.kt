
package com.zelvyn.player.model

import android.graphics.Bitmap
import android.net.Uri

object SupportedLanguages {
    val ALL_LANGUAGES = listOf(
        "Auto Detect", "English", "Japanese", "Spanish", "French", "German",
        "Hindi", "Bengali", "Urdu", "Mandarin", "Portuguese",
        "Arabic", "Russian", "Korean", "Turkish", "Italian",
        "Vietnamese", "Indonesian"
    )

    fun toIsoCode(displayName: String): String {
        return when (displayName.trim()) {
            "English" -> "en"
            "Japanese" -> "ja"
            "Spanish" -> "es"
            "French" -> "fr"
            "German" -> "de"
            "Hindi" -> "hi"
            "Bengali" -> "bn"
            "Urdu" -> "ur"
            "Mandarin" -> "zh"
            "Portuguese" -> "pt"
            "Arabic" -> "ar"
            "Russian" -> "ru"
            "Korean" -> "ko"
            "Turkish" -> "tr"
            "Italian" -> "it"
            "Vietnamese" -> "vi"
            "Indonesian" -> "id"
            else -> "en"
        }
    }
}

object SubtitleEncodings {
    val ALL_ENCODINGS = listOf(
        "UTF-8", "UTF-16", "ISO-8859-1 (Latin-1)", "Windows-1252", "Shift-JIS", "EUC-KR", "GBK"
    )
}

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val sizeBytes: Long = 0L,
    val dateAdded: Long = 0L,
    val resolution: String = "1080p",
    val width: Int = 1920,
    val height: Int = 1080,
    val folder: String = "Internal",
    val mimeType: String? = null,
    val lastPositionMs: Long = 0L,
    val lastWatchedTimeMs: Long = 0L,
    val isFavorite: Boolean = false,
    val thumbnailBitmap: Bitmap? = null
)

data class FolderItem(
    val name: String,
    val videoCount: Int,
    val latestVideo: VideoItem? = null
)

data class TranslationSegment(
    val sessionId: Long,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val originalText: String,
    val translatedText: String,
    val sourceLang: String,
    val targetLang: String
)

enum class TranslationStatus {
    IDLE, CAPTURING_AUDIO, TRANSLATING, ACTIVE, NO_SPEECH,
    ERROR_NO_INTERNET, ERROR_API_KEY, ERROR_GENERIC
}

enum class TranslationMode {
    SUBTITLES, VOICE, BOTH
}

enum class VoiceStyle {
    NATURAL, CLEAR
}

enum class SubtitleBgMode {
    NONE, SOLID, GRADIENT
}

enum class SubtitleFontFamily {
    SANS_SERIF, SERIF, MONOSPACE, CURSIVE
}

enum class EqualizerPresetType {
    FLAT, POP, ROCK, JAZZ, CLASSIC, CUSTOM
}

enum class QueueRepeatMode {
    OFF, ALL, ONE
}

enum class AspectRatioMode(val label: String) {
    FIT("Fit"),
    FILL("Fill"),
    ZOOM("Crop")
}

enum class LibraryLayoutMode {
    GRID, LIST
}

enum class LibraryTabCategory {
    VIDEOS, AUDIO, FOLDERS, FAVORITES
}

data class EqualizerBandState(
    val bandIndex: Int,
    val frequencyLabel: String,
    val gainDb: Float
)

data class MediaTrackInfo(
    val groupIndex: Int,
    val trackIndex: Int,
    val id: String,
    val label: String,
    val language: String?,
    val isSelected: Boolean
)

data class UserPreferences(
    val geminiApiKey: String = "",
    val sourceLang: String = "Auto Detect",
    val defaultTargetLang: String = "English",
    val translationMode: TranslationMode = TranslationMode.BOTH,
    val voiceStyle: VoiceStyle = VoiceStyle.NATURAL,
    val aiModelName: String = "ZELVYN AI Pro",
    val originalVolumePercent: Int = 40,
    val translatedVolumePercent: Int = 100,
    val subtitleFontSizeSp: Int = 16,
    val subtitleColorArgb: Long = 0xFFFFFFFF,
    val subtitleBgMode: SubtitleBgMode = SubtitleBgMode.SOLID,
    val subtitleBackgroundAlpha: Float = 0.75f,
    val subtitlePosition: String = "Bottom",
    val subtitleFontFamily: SubtitleFontFamily = SubtitleFontFamily.SANS_SERIF,
    val subtitleBold: Boolean = true,
    val subtitleEncoding: String = "UTF-8",
    val subtitleOffsetMs: Long = 0L,
    val skipIntervalSeconds: Int = 10,
    val rememberLastPosition: Boolean = true,
    val rememberLastSpeed: Boolean = true,
    val lastPlaybackSpeed: Float = 1.0f,
    val resumeOnAppLaunch: Boolean = true,
    val backgroundPlayback: Boolean = true,
    val pipEnabled: Boolean = true,
    val themeMode: String = "Dark",
    val accentColor: String = "Orange",
    val libraryLayoutMode: LibraryLayoutMode = LibraryLayoutMode.LIST,
    val gestureSensitivity: Float = 1.0f,
    val hasCompletedOnboarding: Boolean = true
)

