package com.zelvyn.player

import android.app.Application
import com.zelvyn.player.utils.ZelvynCrashLogger

class ZelvynApp : Application() {
    override fun onCreate() {
        super.onCreate()
        ZelvynCrashLogger.install(this)
    }
}

