package com.zelvyn.player.audio

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.view.WindowManager
import kotlin.math.roundToInt

class DeviceHardwareController(private val activity: Activity) {

private val audioManager = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
private var volumeFloatAccumulator: Float = -1f

fun getVolumeLevel(): Float {
    if (volumeFloatAccumulator >= 0f) {
        return volumeFloatAccumulator.coerceIn(0f, 1f)
    }
    val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
    val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    return if (max > 0) current.toFloat() / max.toFloat() else 0f
}

fun adjustVolume(delta: Float) {
    val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
    if (max <= 0) return

    if (volumeFloatAccumulator < 0f) {
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        volumeFloatAccumulator = current.toFloat() / max.toFloat()
    }

    volumeFloatAccumulator = (volumeFloatAccumulator + delta).coerceIn(0f, 1f)
    val targetStep = (volumeFloatAccumulator * max).roundToInt().coerceIn(0, max)
    audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetStep, 0)
}

fun getBrightnessLevel(): Float {
    val current = activity.window.attributes.screenBrightness
    return if (current < 0) 0.5f else current
}

fun adjustBrightness(delta: Float) {
    val window = activity.window
    val layoutParams: WindowManager.LayoutParams = window.attributes
    val current = if (layoutParams.screenBrightness < 0) 0.5f else layoutParams.screenBrightness
    val target = (current + delta).coerceIn(0.01f, 1.0f)
    layoutParams.screenBrightness = target
    window.attributes = layoutParams
}

}
