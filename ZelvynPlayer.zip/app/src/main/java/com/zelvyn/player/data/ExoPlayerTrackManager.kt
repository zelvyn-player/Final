package com.zelvyn.player.data

import androidx.media3.common.C
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.exoplayer.ExoPlayer
import com.zelvyn.player.model.MediaTrackInfo
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ExoPlayerTrackManager(private val player: ExoPlayer) {

private val _audioTracks = MutableStateFlow<List<MediaTrackInfo>>(emptyList())
val audioTracks: StateFlow<List<MediaTrackInfo>> = _audioTracks.asStateFlow()

private val _subtitleTracks = MutableStateFlow<List<MediaTrackInfo>>(emptyList())
val subtitleTracks: StateFlow<List<MediaTrackInfo>> = _subtitleTracks.asStateFlow()

private val _isSubtitleDisabled = MutableStateFlow(false)
val isSubtitleDisabled: StateFlow<Boolean> = _isSubtitleDisabled.asStateFlow()

fun updateTracks(tracks: Tracks) {
    val audios = mutableListOf<MediaTrackInfo>()
    val subtitles = mutableListOf<MediaTrackInfo>()

    for (groupIndex in 0 until tracks.groups.size) {
        val group = tracks.groups[groupIndex]
        val trackType = group.type

        for (trackIndex in 0 until group.length) {
            val format = group.getTrackFormat(trackIndex)
            val isSelected = group.isTrackSelected(trackIndex)
            val label = when {
                !format.label.isNullOrBlank() -> format.label!!
                !format.language.isNullOrBlank() -> format.language!!
                else -> "Track ${trackIndex + 1}"
            }

            val item = MediaTrackInfo(
                groupIndex = groupIndex,
                trackIndex = trackIndex,
                id = format.id ?: "$groupIndex-$trackIndex",
                label = label,
                language = format.language,
                isSelected = isSelected
            )

            if (trackType == C.TRACK_TYPE_AUDIO) {
                audios.add(item)
            } else if (trackType == C.TRACK_TYPE_TEXT) {
                subtitles.add(item)
            }
        }
    }
    _audioTracks.value = audios
    _subtitleTracks.value = subtitles
    _isSubtitleDisabled.value = player.trackSelectionParameters.disabledTrackTypes.contains(C.TRACK_TYPE_TEXT)
}

fun selectTrack(track: MediaTrackInfo, trackType: Int) {
    val tracks = player.currentTracks
    if (track.groupIndex in 0 until tracks.groups.size) {
        val group = tracks.groups[track.groupIndex].mediaTrackGroup
        player.trackSelectionParameters = player.trackSelectionParameters
            .buildUpon()
            .clearOverridesOfType(trackType)
            .setOverrideForType(TrackSelectionOverride(group, track.trackIndex))
            .setTrackTypeDisabled(trackType, false)
            .build()
        updateTracks(player.currentTracks)
    }
}

fun disableSubtitles() {
    player.trackSelectionParameters = player.trackSelectionParameters
        .buildUpon()
        .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
        .clearOverridesOfType(C.TRACK_TYPE_TEXT)
        .build()
    _isSubtitleDisabled.value = true
    updateTracks(player.currentTracks)
}

}
