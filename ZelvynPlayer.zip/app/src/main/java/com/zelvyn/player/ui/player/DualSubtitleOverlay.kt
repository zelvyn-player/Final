package com.zelvyn.player.ui.player

import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Translate
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.model.SubtitleBgMode
import com.zelvyn.player.model.TranslationSegment
import com.zelvyn.player.ui.theme.*

@Composable
fun DualSubtitleOverlay(
    segment: TranslationSegment?,
    fontSizeSp: Int = 16,
    colorArgb: Long = 0xFFFFFFFF,
    bgMode: SubtitleBgMode = SubtitleBgMode.SOLID,
    bgAlpha: Float = 0.75f,
    modifier: Modifier = Modifier
) {
    AnimatedContent(
        targetState = segment,
        transitionSpec = {
            (
                fadeIn(animationSpec = tween(250)) +
                    scaleIn(
                        initialScale = 0.96f,
                        animationSpec = tween(250)
                    )
                ).togetherWith(
                    fadeOut(animationSpec = tween(200)) +
                        scaleOut(
                            targetScale = 0.96f,
                            animationSpec = tween(200)
                        )
                )
        },
        label = "SubtitleTransition",
        modifier = modifier
    ) { currentSegment ->
        if (currentSegment != null) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        if (bgMode == SubtitleBgMode.NONE) {
                            Color.Transparent
                        } else {
                            CardSurfaceDark.copy(alpha = bgAlpha)
                        }
                    )
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Translate,
                            contentDescription = null,
                            tint = BrandAccent,
                            modifier = Modifier.size(12.dp)
                        )
                        Text(
                            text = "${currentSegment.sourceLang} → ${currentSegment.targetLang}",
                            color = BrandAccent,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Text(
                        text = currentSegment.originalText,
                        color = Color(colorArgb),
                        fontSize = fontSizeSp.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )

                    Text(
                        text = currentSegment.translatedText,
                        color = TextSecondaryDark,
                        fontSize = (fontSizeSp - 2).coerceAtLeast(11).sp,
                        fontWeight = FontWeight.Normal,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}
