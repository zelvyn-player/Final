package com.zelvyn.player.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.data.ExoPlayerTrackManager
import com.zelvyn.player.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class) @Composable fun AudioTracksSheet(
trackManager: ExoPlayerTrackManager, onDismiss: () -> Unit ) { val audioTracks
by trackManager.audioTracks.collectAsState() val sheetState =
rememberModalBottomSheetState(skipPartiallyExpanded = true)

ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    tonalElevation = 0.dp
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp, vertical = 8.dp)
            .navigationBarsPadding(),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "Audio Tracks", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (audioTracks.isEmpty()) {
                item {
                    Text(text = "Default audio track active.", color = MaterialTheme.colorScheme.secondary, fontSize = 13.sp)
                }
            } else {
                items(audioTracks.size) { index ->
                    val track = audioTracks[index]
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .clickable { trackManager.selectTrack(track, androidx.media3.common.C.TRACK_TYPE_AUDIO) }
                            .padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(text = track.label, color = MaterialTheme.colorScheme.onBackground, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                            Text(text = track.language ?: "Default Stream", color = MaterialTheme.colorScheme.secondary, fontSize = 11.sp)
                        }
                        if (track.isSelected) {
                            Icon(Icons.Rounded.Check, contentDescription = null, tint = BrandAccent, modifier = Modifier.size(20.dp))
                        }
                    }
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { }
                .padding(vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(Icons.Rounded.Add, contentDescription = null, tint = BrandAccent, modifier = Modifier.size(18.dp))
            Text(text = "Add External Audio Track", color = BrandAccent, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
    }
}

}
