package com.zelvyn.player.data

import com.zelvyn.player.model.TranslationSegment
import com.zelvyn.player.model.TranslationStatus
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicLong

class TranslationCoordinator( private val scope: CoroutineScope, private val
geminiService: GeminiTranslationService = GeminiTranslationService(), private
val onVoiceOutputRequested: (String, String) -> Unit = { _, _ -> } ) { private
val currentSessionId = AtomicLong(0) private var inFlightJob: Job? = null

private val _activeSegment = MutableStateFlow<TranslationSegment?>(null)
val activeSegment: StateFlow<TranslationSegment?> = _activeSegment.asStateFlow()

private val _status = MutableStateFlow(TranslationStatus.IDLE)
val status: StateFlow<TranslationStatus> = _status.asStateFlow()

private val _statusMessage = MutableStateFlow<String?>(null)
val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

private val _isTranslationActive = MutableStateFlow(false)
val isTranslationActive: StateFlow<Boolean> = _isTranslationActive.asStateFlow()

private val _sourceLanguage = MutableStateFlow("Auto Detect")
val sourceLanguage: StateFlow<String> = _sourceLanguage.asStateFlow()

private val _targetLanguage = MutableStateFlow("English")
val targetLanguage: StateFlow<String> = _targetLanguage.asStateFlow()

private val segmentHistory = mutableListOf<TranslationSegment>()

fun startSession(source: String, target: String, apiKey: String): Long {
    inFlightJob?.cancel()
    val sessionId = currentSessionId.incrementAndGet()
    _sourceLanguage.value = source
    _targetLanguage.value = target
    segmentHistory.clear()
    _activeSegment.value = null
    _isTranslationActive.value = true

    if (apiKey.isBlank()) {
        _status.value = TranslationStatus.ERROR_API_KEY
        _statusMessage.value = "Gemini API key required. Configure in Settings."
    } else {
        _status.value = TranslationStatus.CAPTURING_AUDIO
        _statusMessage.value = "Listening to audio..."
    }
    return sessionId
}

fun stopSession() {
    inFlightJob?.cancel()
    currentSessionId.incrementAndGet()
    segmentHistory.clear()
    _activeSegment.value = null
    _isTranslationActive.value = false
    _status.value = TranslationStatus.IDLE
    _statusMessage.value = null
}

fun setLanguages(source: String, target: String) {
    _sourceLanguage.value = source
    _targetLanguage.value = target
}

fun onAudioChunkCaptured(
    pcmData: ByteArray,
    sampleRate: Int,
    channels: Int,
    currentPlaybackPosMs: Long,
    apiKey: String
) {
    if (!_isTranslationActive.value) return
    val sessionAtCapture = currentSessionId.get()

    inFlightJob?.cancel()
    inFlightJob = scope.launch(Dispatchers.IO) {
        _status.value = TranslationStatus.TRANSLATING
        _statusMessage.value = "Translating speech..."

        val chunkDurationMs = ((pcmData.size.toDouble() / (sampleRate * channels * 2)) * 1000).toLong()
        val startMs = (currentPlaybackPosMs - chunkDurationMs).coerceAtLeast(0L)
        val endMs = currentPlaybackPosMs + 2800L

        val result = geminiService.translateAudioChunk(
            apiKey = apiKey,
            rawPcmBytes = pcmData,
            sampleRate = sampleRate,
            channels = channels,
            targetLanguage = _targetLanguage.value,
            sourceLanguageOverride = if (_sourceLanguage.value == "Auto Detect") null else _sourceLanguage.value
        )

        if (sessionAtCapture != currentSessionId.get()) return@launch

        when (result) {
            is GeminiResult.Success -> {
                val seg = TranslationSegment(
                    sessionId = sessionAtCapture,
                    startTimeMs = startMs,
                    endTimeMs = endMs,
                    originalText = result.originalText,
                    translatedText = result.translatedText,
                    sourceLang = result.detectedLanguage,
                    targetLang = _targetLanguage.value
                )
                synchronized(segmentHistory) {
                    segmentHistory.add(seg)
                }
                _activeSegment.value = seg
                _status.value = TranslationStatus.ACTIVE
                _statusMessage.value = null

                onVoiceOutputRequested(result.translatedText, _targetLanguage.value)
            }
            is GeminiResult.Failure -> {
                _statusMessage.value = result.message
                _status.value = when (result.errorType) {
                    GeminiResult.ErrorType.NO_INTERNET -> TranslationStatus.ERROR_NO_INTERNET
                    GeminiResult.ErrorType.API_KEY_INVALID -> TranslationStatus.ERROR_API_KEY
                    GeminiResult.ErrorType.NO_SPEECH -> TranslationStatus.NO_SPEECH
                    else -> TranslationStatus.ERROR_GENERIC
                }
            }
        }
    }
}

fun onPlaybackPositionChanged(positionMs: Long) {
    if (!_isTranslationActive.value) return
    val match = synchronized(segmentHistory) {
        segmentHistory.find { positionMs in it.startTimeMs..it.endTimeMs }
    }
    if (match != null) {
        if (_activeSegment.value != match) {
            _activeSegment.value = match
        }
    } else if (_status.value == TranslationStatus.ACTIVE) {
        _activeSegment.value = null
    }
}

fun onSeekInvalidate() {
    inFlightJob?.cancel()
    _activeSegment.value = null
    if (_isTranslationActive.value) {
        _status.value = TranslationStatus.CAPTURING_AUDIO
        _statusMessage.value = "Resuming audio analysis..."
    }
}

}
