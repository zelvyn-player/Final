
package com.zelvyn.player.data

import com.zelvyn.player.model.TranslationSegment
import com.zelvyn.player.model.TranslationStatus
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicLong

class TranslationCoordinator(
    private val scope: CoroutineScope,
    private val geminiService: GeminiTranslationService = GeminiTranslationService(),
    private val onVoiceOutputRequested: (String, String) -> Unit = { _, _ -> }
) {
    private val currentSessionId = AtomicLong(0)
    private var inFlightJob: Job? = null

    private val _activeSegment = MutableStateFlow<TranslationSegment?>(null)
    val activeSegment: StateFlow<TranslationSegment?> = _activeSegment.asStateFlow()

    private val _status = MutableStateFlow(TranslationStatus.IDLE)
    val status: StateFlow<TranslationStatus> = _status.asStateFlow()

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage.asStateFlow()

    private val _isTranslationActive = MutableStateFlow(false)
    val isTranslationActive: StateFlow<Boolean> = _isTranslationActive.asStateFlow()

    private val _sourceLanguage = MutableStateFlow("Auto Detect")
    val sourceLanguage: StateFlow<String> = _sourceLanguage.asStateFlow()

    private val _targetLanguage = MutableStateFlow("English")
    val targetLanguage: StateFlow<String> = _targetLanguage.asStateFlow()

    private val segmentHistory = mutableListOf<TranslationSegment>()
    private var lastTranscribedText: String = ""

    fun startSession(source: String, target: String, apiKey: String): Long {
        inFlightJob?.cancel()
        val sessionId = currentSessionId.incrementAndGet()
        _sourceLanguage.value = source
        _targetLanguage.value = target
        segmentHistory.clear()
        lastTranscribedText = ""
        _activeSegment.value = null
        _isTranslationActive.value = true

        if (apiKey.isBlank()) {
            _status.value = TranslationStatus.ERROR_API_KEY
            _statusMessage.value = "Gemini API key required. Configure in Settings."
        } else {
            _status.value = TranslationStatus.CAPTURING_AUDIO
            _statusMessage.value = "Listening to audio..."
        }
        return sessionId
    }

    fun stopSession() {
        inFlightJob?.cancel()
        currentSessionId.incrementAndGet()
        segmentHistory.clear()
        lastTranscribedText = ""
        _activeSegment.value = null
        _isTranslationActive.value = false
        _status.value = TranslationStatus.IDLE
        _statusMessage.value = null
    }

    fun setLanguages(source: String, target: String) {
        _sourceLanguage.value = source
        _targetLanguage.value = target
    }

    fun onAudioChunkCaptured(
        pcmData: ByteArray,
        sampleRate: Int,
        channels: Int,
        chunkStartMs: Long,
        chunkEndMs: Long,
        apiKey: String
    ) {
        if (!_isTranslationActive.value) return
        val sessionAtCapture = currentSessionId.get()

        inFlightJob?.cancel()
        inFlightJob = scope.launch(Dispatchers.IO) {
            _status.value = TranslationStatus.TRANSLATING
            _statusMessage.value = "Translating speech..."

            val result = geminiService.translateAudioChunk(
                apiKey = apiKey,
                rawPcmBytes = pcmData,
                sampleRate = sampleRate,
                channels = channels,
                targetLanguage = _targetLanguage.value,
                sourceLanguageOverride = if (_sourceLanguage.value == "Auto Detect") null else _sourceLanguage.value
            )

            if (sessionAtCapture != currentSessionId.get()) return@launch

            when (result) {
                is GeminiResult.Success -> {
                    val cleanOriginal = trimOverlap(lastTranscribedText, result.originalText)
                    val cleanTranslated = trimOverlap("", result.translatedText)
                    lastTranscribedText = result.originalText

                    // Timeline anchor strictly to dialogue's playback window
                    val seg = TranslationSegment(
                        sessionId = sessionAtCapture,
                        startTimeMs = chunkStartMs,
                        endTimeMs = (chunkEndMs + 800L).coerceAtLeast(chunkStartMs + 2000L),
                        originalText = if (cleanOriginal.isNotBlank()) cleanOriginal else result.originalText,
                        translatedText = if (cleanTranslated.isNotBlank()) cleanTranslated else result.translatedText,
                        sourceLang = result.detectedLanguage,
                        targetLang = _targetLanguage.value
                    )

                    synchronized(segmentHistory) {
                        segmentHistory.add(seg)
                    }
                    _activeSegment.value = seg
                    _status.value = TranslationStatus.ACTIVE
                    _statusMessage.value = null

                    onVoiceOutputRequested(result.translatedText, _targetLanguage.value)
                }

                is GeminiResult.Failure -> {
                    when (result.errorType) {
                        GeminiResult.ErrorType.NO_INTERNET -> {
                            _status.value = TranslationStatus.RECONNECTING
                            _statusMessage.value = "Connection dropped. Reconnecting..."
                        }
                        GeminiResult.ErrorType.RATE_LIMITED -> {
                            _status.value = TranslationStatus.RATE_LIMITED
                            _statusMessage.value = "AI Rate limit reached. Backing off..."
                        }
                        GeminiResult.ErrorType.API_KEY_INVALID -> {
                            _status.value = TranslationStatus.ERROR_API_KEY
                            _statusMessage.value = result.message
                        }
                        GeminiResult.ErrorType.NO_SPEECH -> {
                            _status.value = TranslationStatus.ACTIVE
                            _statusMessage.value = null
                        }
                        else -> {
                            _status.value = TranslationStatus.ERROR_GENERIC
                            _statusMessage.value = result.message
                        }
                    }
                }
            }
        }
    }

    private fun trimOverlap(prev: String, current: String): String {
        if (prev.isBlank() || current.isBlank()) return current
        val prevWords = prev.trim().split("\\s+".toRegex())
        val currWords = current.trim().split("\\s+".toRegex())
        val checkCount = minOf(4, prevWords.size, currWords.size)

        for (k in checkCount downTo 1) {
            val prevSuffix = prevWords.takeLast(k).joinToString(" ").lowercase()
            val currPrefix = currWords.take(k).joinToString(" ").lowercase()
            if (prevSuffix == currPrefix) {
                return currWords.drop(k).joinToString(" ")
            }
        }
        return current
    }

    fun onPlaybackPositionChanged(positionMs: Long) {
        if (!_isTranslationActive.value) return
        val currentSeg = synchronized(segmentHistory) {
            segmentHistory.lastOrNull { seg ->
                positionMs in seg.startTimeMs..seg.endTimeMs
            }
        }
        if (currentSeg != null) {
            if (_activeSegment.value != currentSeg) {
                _activeSegment.value = currentSeg
            }
        } else if (_status.value == TranslationStatus.ACTIVE) {
            _activeSegment.value = null
        }
    }

    fun onSeekInvalidate() {
        inFlightJob?.cancel()
        _activeSegment.value = null
        lastTranscribedText = ""
        if (_isTranslationActive.value) {
            _status.value = TranslationStatus.CAPTURING_AUDIO
            _statusMessage.value = "Resuming audio analysis..."
        }
    }
}

