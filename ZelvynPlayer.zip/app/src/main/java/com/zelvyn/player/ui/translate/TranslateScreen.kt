package com.zelvyn.player.ui.translate

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.data.TranslationCoordinator
import com.zelvyn.player.model.*
import com.zelvyn.player.ui.theme.*

@Composable
fun TranslateScreen(
    translationCoordinator: TranslationCoordinator,
    prefsManager: PreferencesManager,
    onNavigateSubtitleStyle: () -> Unit,
    onNavigateSettings: () -> Unit
) {
    val userPrefs by prefsManager.userPreferences.collectAsState()
    val status by translationCoordinator.status.collectAsState()
    val isTranslationActive by translationCoordinator.isTranslationActive.collectAsState()

    var showSourceDialog by remember { mutableStateOf(false) }
    var showTargetDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(text = "Translate", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
            IconButton(onClick = onNavigateSettings) {
                Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = MaterialTheme.colorScheme.secondary)
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.fillMaxSize().padding(bottom = 16.dp)
        ) {
            // Live Waveform Visualizer
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(60.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        listOf(8, 14, 26, 36, 18, 28, 42, 20, 12, 34, 22, 16, 30, 40, 18, 10).forEach { h ->
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(if (isTranslationActive) h.dp else 6.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(BrandAccent)
                            )
                        }
                    }
                }
            }

            // Source Language Selector
            item {
                TranslationSettingCard(
                    label = "Source Language",
                    value = userPrefs.sourceLang,
                    onClick = { showSourceDialog = true }
                )
            }

            // Translate to Selector
            item {
                TranslationSettingCard(
                    label = "Translate to",
                    value = userPrefs.defaultTargetLang,
                    onClick = { showTargetDialog = true }
                )
            }

            // Mode Selector: Subtitles | Voice | Both
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "Mode", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(10.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(TranslationMode.SUBTITLES to "Subtitles", TranslationMode.VOICE to "Voice", TranslationMode.BOTH to "Both").forEach { (mode, label) ->
                            val isSelected = userPrefs.translationMode == mode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) BrandAccentLight.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surface)
                                    .clickable { prefsManager.updatePreferences { it.copy(translationMode = mode) } }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) BrandAccentDark else MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }
                }
            }

            // Voice Style Selector
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Voice", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        Text(text = if (userPrefs.voiceStyle == VoiceStyle.NATURAL) "Zelvyn Natural" else "Zelvyn Clear", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    }
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .background(BrandAccentLight.copy(alpha = 0.6f))
                            .padding(horizontal = 8.dp, vertical = 3.dp)
                    ) {
                        Text(text = "Pro", fontSize = 10.sp, color = BrandAccentDark, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Volume Balance Sliders
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Original Volume", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        Text(text = "${userPrefs.originalVolumePercent}%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = userPrefs.originalVolumePercent.toFloat(),
                        onValueChange = { prefsManager.updatePreferences { p -> p.copy(originalVolumePercent = it.toInt()) } },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(thumbColor = BrandAccent, activeTrackColor = BrandAccent)
                    )

                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(text = "Translated Volume", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                        Text(text = "${userPrefs.translatedVolumePercent}%", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Slider(
                        value = userPrefs.translatedVolumePercent.toFloat(),
                        onValueChange = { prefsManager.updatePreferences { p -> p.copy(translatedVolumePercent = it.toInt()) } },
                        valueRange = 0f..100f,
                        colors = SliderDefaults.colors(thumbColor = BrandAccent, activeTrackColor = BrandAccent)
                    )
                }
            }

            // Subtitle Style Edit
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
                        .clickable { onNavigateSubtitleStyle() }
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(text = "Subtitle Style", fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
                        Text(text = "Modern Classic", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    }
                    Text(text = "Edit >", fontSize = 12.sp, color = BrandAccent, fontWeight = FontWeight.Medium)
                }
            }

            // Status Badge at Bottom
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(if (isTranslationActive) AccentSuccess else MaterialTheme.colorScheme.tertiary))
                    Text(
                        text = if (isTranslationActive) "Translation is Active" else "Translation Inactive",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
            }
        }
    }

    if (showSourceDialog) {
        LanguageDialog(
            title = "Source Language",
            options = SupportedLanguages.ALL_LANGUAGES,
            selected = userPrefs.sourceLang,
            onSelect = {
                prefsManager.updatePreferences { p -> p.copy(sourceLang = it) }
                translationCoordinator.setLanguages(it, userPrefs.defaultTargetLang)
                showSourceDialog = false
            },
            onDismiss = { showSourceDialog = false }
        )
    }

    if (showTargetDialog) {
        LanguageDialog(
            title = "Translate to",
            options = SupportedLanguages.ALL_LANGUAGES.filter { it != "Auto Detect" },
            selected = userPrefs.defaultTargetLang,
            onSelect = {
                prefsManager.updatePreferences { p -> p.copy(defaultTargetLang = it) }
                translationCoordinator.setLanguages(userPrefs.sourceLang, it)
                showTargetDialog = false
            },
            onDismiss = { showTargetDialog = false }
        )
    }
}

@Composable
fun TranslationSettingCard(label: String, value: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(text = label, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary)
            Text(text = value, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        }
        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.tertiary)
    }
}

@Composable
fun LanguageDialog(
    title: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground) },
        text = {
            LazyColumn(modifier = Modifier.height(280.dp)) {
                items(options) { lang ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(lang) }
                            .padding(vertical = 10.dp, horizontal = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = lang, color = MaterialTheme.colorScheme.onBackground, fontSize = 14.sp)
                        if (lang == selected) {
                            Icon(Icons.Rounded.Check, contentDescription = null, tint = BrandAccent, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close", color = MaterialTheme.colorScheme.secondary) }
        }
    )
}
