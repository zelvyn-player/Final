package com.zelvyn.player.ui.translate

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.data.TranslationCoordinator
import com.zelvyn.player.model.*

@Composable
fun TranslateScreen(
    translationCoordinator: TranslationCoordinator,
    prefsManager: PreferencesManager,
    onNavigateSubtitleStyle: () -> Unit,
    onNavigateSettings: () -> Unit
) {
    val userPrefs by prefsManager.userPreferences.collectAsState()
    val status by translationCoordinator.status.collectAsState()
    val isTranslationActive by translationCoordinator.isTranslationActive.collectAsState()

    var showSourceDialog by remember { mutableStateOf(false) }
    var showTargetDialog by remember { mutableStateOf(false) }
    var showModelDialog by remember { mutableStateOf(false) }
    var showStyleDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .padding(horizontal = 18.dp)
    ) {
        // Blueprint Header: "← AI Subtitle & Translate"
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
                Text(
                    text = "AI Subtitle & Translate",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
            IconButton(onClick = onNavigateSettings) {
                Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = MaterialTheme.colorScheme.secondary)
            }
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize().padding(bottom = 20.dp)
        ) {
            // Enable AI Subtitle Toggle Row matching Blueprint
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Enable AI Subtitle",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Switch(
                        checked = isTranslationActive,
                        onCheckedChange = { active ->
                            if (active) {
                                translationCoordinator.startSession(
                                    source = userPrefs.sourceLang,
                                    target = userPrefs.defaultTargetLang,
                                    apiKey = userPrefs.geminiApiKey
                                )
                            } else {
                                translationCoordinator.stopSession()
                            }
                        },
                        colors = SwitchDefaults.colors(checkedTrackColor = MaterialTheme.colorScheme.primary)
                    )
                }
            }

            // Blueprint Dropdowns
            item {
                BlueprintDropdownCard(
                    label = "Translate From",
                    value = userPrefs.sourceLang,
                    onClick = { showSourceDialog = true }
                )
            }

            item {
                BlueprintDropdownCard(
                    label = "Translate To",
                    value = userPrefs.defaultTargetLang,
                    onClick = { showTargetDialog = true }
                )
            }

            item {
                BlueprintDropdownCard(
                    label = "AI Model",
                    value = userPrefs.aiModelName,
                    onClick = { showModelDialog = true }
                )
            }

            item {
                BlueprintDropdownCard(
                    label = "Style",
                    value = if (userPrefs.voiceStyle == VoiceStyle.NATURAL) "Natural" else "Clear",
                    onClick = { showStyleDialog = true }
                )
            }

            // Blueprint "Apply To": [Subtitles] [Voice] [Both]
            item {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text = "Apply To", fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surface)
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(10.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(TranslationMode.SUBTITLES to "Subtitles", TranslationMode.VOICE to "Voice", TranslationMode.BOTH to "Both").forEach { (mode, label) ->
                            val isSelected = userPrefs.translationMode == mode
                            Box(
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent)
                                    .clickable { prefsManager.updatePreferences { it.copy(translationMode = mode) } }
                                    .padding(vertical = 8.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = label,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.secondary
                                )
                            }
                        }
                    }
                }
            }

            // Blueprint Live Waveform & Status Box
            item {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(14.dp))
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Audio Waveform
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(3.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.height(40.dp)
                    ) {
                        listOf(8, 16, 28, 36, 18, 24, 40, 18, 12, 32, 22, 14, 28, 38, 16, 8).forEach { h ->
                            Box(
                                modifier = Modifier
                                    .width(3.dp)
                                    .height(if (isTranslationActive) h.dp else 6.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(MaterialTheme.colorScheme.primary)
                            )
                        }
                    }

                    Text(
                        text = if (isTranslationActive) "Translation ready" else "Translation paused",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = if (isTranslationActive) "Live dialogue is translated in sync with playback." else "Tap apply to start real-time speech translation.",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.secondary
                    )

                    Button(
                        onClick = {
                            if (isTranslationActive) {
                                translationCoordinator.stopSession()
                            } else {
                                translationCoordinator.startSession(
                                    source = userPrefs.sourceLang,
                                    target = userPrefs.defaultTargetLang,
                                    apiKey = userPrefs.geminiApiKey
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.fillMaxWidth().height(46.dp)
                    ) {
                        Text(
                            text = if (isTranslationActive) "Pause Translation" else "Apply Translation",
                            color = MaterialTheme.colorScheme.onBackground,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }

    if (showSourceDialog) {
        BlueprintSelectionDialog(
            title = "Translate From",
            options = SupportedLanguages.ALL_LANGUAGES,
            selected = userPrefs.sourceLang,
            onSelect = {
                prefsManager.updatePreferences { p -> p.copy(sourceLang = it) }
                translationCoordinator.setLanguages(it, userPrefs.defaultTargetLang)
                showSourceDialog = false
            },
            onDismiss = { showSourceDialog = false }
        )
    }

    if (showTargetDialog) {
        BlueprintSelectionDialog(
            title = "Translate To",
            options = SupportedLanguages.ALL_LANGUAGES.filter { it != "Auto Detect" },
            selected = userPrefs.defaultTargetLang,
            onSelect = {
                prefsManager.updatePreferences { p -> p.copy(defaultTargetLang = it) }
                translationCoordinator.setLanguages(userPrefs.sourceLang, it)
                showTargetDialog = false
            },
            onDismiss = { showTargetDialog = false }
        )
    }

    if (showModelDialog) {
        BlueprintSelectionDialog(
            title = "AI Model",
            options = listOf("ZELVYN AI Pro", "Gemini 2.0 Flash", "Zelvyn Low-Latency"),
            selected = userPrefs.aiModelName,
            onSelect = {
                prefsManager.updatePreferences { p -> p.copy(aiModelName = it) }
                showModelDialog = false
            },
            onDismiss = { showModelDialog = false }
        )
    }

    if (showStyleDialog) {
        BlueprintSelectionDialog(
            title = "Voice Dubbing Style",
            options = listOf("Natural", "Clear"),
            selected = if (userPrefs.voiceStyle == VoiceStyle.NATURAL) "Natural" else "Clear",
            onSelect = {
                val style = if (it == "Natural") VoiceStyle.NATURAL else VoiceStyle.CLEAR
                prefsManager.updatePreferences { p -> p.copy(voiceStyle = style) }
                showStyleDialog = false
            },
            onDismiss = { showStyleDialog = false }
        )
    }
}

@Composable
fun BlueprintDropdownCard(label: String, value: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text = label, fontSize = 13.sp, color = MaterialTheme.colorScheme.secondary)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = value, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onBackground)
            Icon(Icons.Rounded.KeyboardArrowDown, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
fun BlueprintSelectionDialog(
    title: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = { Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground) },
        text = {
            LazyColumn(modifier = Modifier.height(260.dp)) {
                items(options) { item ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(item) }
                            .padding(vertical = 10.dp, horizontal = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = item, color = MaterialTheme.colorScheme.onBackground, fontSize = 14.sp)
                        if (item == selected) {
                            Icon(Icons.Rounded.Check, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close", color = MaterialTheme.colorScheme.secondary) }
        }
    )
}