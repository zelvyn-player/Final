
package com.zelvyn.player.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.util.UnstableApi
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

@UnstableApi
class ZelvynAudioCaptureProcessor(
    private val onChunkReady: (ByteArray, Int, Int, Long, Long) -> Unit
) : AudioProcessor {

    private var inputAudioFormat: AudioFormat = AudioFormat.NOT_SET
    private var outputAudioFormat: AudioFormat = AudioFormat.NOT_SET

    private var buffer: ByteBuffer = AudioProcessor.EMPTY_BUFFER
    private var outputBuffer: ByteBuffer = AudioProcessor.EMPTY_BUFFER
    private var inputEnded: Boolean = false

    private val pcmAccumulator = ByteArrayOutputStream()
    private val overlapBuffer = ByteArrayOutputStream()
    private var dynamicChunkThresholdBytes: Int = 16000 * 2 * 4
    private var overlapBytesLength: Int = 16000 * 2 * 1 / 2 // 0.5s overlap

    var isCapturing: Boolean = false
    var currentMediaPositionSupplier: () -> Long = { 0L }
    private var chunkStartMediaTimeMs: Long = 0L

    override fun configure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            this.inputAudioFormat = AudioFormat.NOT_SET
            this.outputAudioFormat = AudioFormat.NOT_SET
            return AudioFormat.NOT_SET
        }
        this.inputAudioFormat = inputAudioFormat
        this.outputAudioFormat = inputAudioFormat

        val bytesPerSecond = inputAudioFormat.sampleRate * inputAudioFormat.channelCount * 2
        this.dynamicChunkThresholdBytes = bytesPerSecond * 4 // 4s total chunk
        this.overlapBytesLength = (bytesPerSecond * 0.5).toInt() // 0.5s overlap

        return outputAudioFormat
    }

    override fun isActive(): Boolean = outputAudioFormat != AudioFormat.NOT_SET

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        if (isCapturing && inputAudioFormat.sampleRate > 0) {
            val dup = inputBuffer.duplicate()
            val tempBytes = ByteArray(dup.remaining())
            dup.get(tempBytes)

            synchronized(pcmAccumulator) {
                if (pcmAccumulator.size() == 0) {
                    chunkStartMediaTimeMs = currentMediaPositionSupplier()
                    // Prepend 0.5s overlap audio from previous chunk if available
                    val prevOverlap = overlapBuffer.toByteArray()
                    if (prevOverlap.isNotEmpty()) {
                        pcmAccumulator.write(prevOverlap)
                    }
                }

                pcmAccumulator.write(tempBytes)

                if (pcmAccumulator.size() >= dynamicChunkThresholdBytes) {
                    val rawPcm = pcmAccumulator.toByteArray()
                    val endMediaTimeMs = currentMediaPositionSupplier()

                    // Save last 0.5s to overlap buffer for the next chunk
                    overlapBuffer.reset()
                    if (rawPcm.size > overlapBytesLength) {
                        overlapBuffer.write(rawPcm, rawPcm.size - overlapBytesLength, overlapBytesLength)
                    }

                    pcmAccumulator.reset()

                    // Lightweight RMS Voice Activity Energy check
                    val rms = calculatePcmRms(rawPcm)
                    if (rms >= 180.0) { // Discard silence/ambient noise floor
                        onChunkReady(
                            rawPcm,
                            inputAudioFormat.sampleRate,
                            inputAudioFormat.channelCount,
                            chunkStartMediaTimeMs,
                            endMediaTimeMs
                        )
                    }
                }
            }
        }

        if (buffer.capacity() < remaining) {
            buffer = ByteBuffer.allocateDirect(remaining).order(ByteOrder.nativeOrder())
        } else {
            buffer.clear()
        }
        buffer.put(inputBuffer)
        buffer.flip()
        outputBuffer = buffer
    }

    private fun calculatePcmRms(pcmData: ByteArray): Double {
        var sum = 0.0
        val numSamples = pcmData.size / 2
        if (numSamples == 0) return 0.0
        var i = 0
        while (i < pcmData.size - 1) {
            val sample = (pcmData[i].toInt() and 0xFF) or (pcmData[i + 1].toInt() shl 8)
            val sampleShort = sample.toShort()
            sum += (sampleShort * sampleShort).toDouble()
            i += 2
        }
        return Math.sqrt(sum / numSamples)
    }

    override fun queueEndOfStream() {
        inputEnded = true
    }

    override fun getOutput(): ByteBuffer {
        val out = outputBuffer
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        return out
    }

    override fun isEnded(): Boolean = inputEnded && outputBuffer === AudioProcessor.EMPTY_BUFFER

    override fun flush() {
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        inputEnded = false
        synchronized(pcmAccumulator) {
            pcmAccumulator.reset()
            overlapBuffer.reset()
        }
    }

    override fun reset() {
        flush()
        buffer = AudioProcessor.EMPTY_BUFFER
        inputAudioFormat = AudioFormat.NOT_SET
        outputAudioFormat = AudioFormat.NOT_SET
    }
}

