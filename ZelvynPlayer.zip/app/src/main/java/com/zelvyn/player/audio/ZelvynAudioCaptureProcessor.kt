package com.zelvyn.player.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.util.UnstableApi
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

@UnstableApi
class ZelvynAudioCaptureProcessor(
    private val onChunkReady: (ByteArray, Int, Int) -> Unit
) : AudioProcessor {

    private var inputAudioFormat: AudioFormat = AudioFormat.NOT_SET
    private var outputAudioFormat: AudioFormat = AudioFormat.NOT_SET

    private var buffer: ByteBuffer = AudioProcessor.EMPTY_BUFFER
    private var outputBuffer: ByteBuffer = AudioProcessor.EMPTY_BUFFER
    private var inputEnded: Boolean = false

    private val pcmAccumulator = ByteArrayOutputStream()
    private var dynamicChunkThresholdBytes: Int = 16000 * 2 * 4

    var isCapturing: Boolean = false

    override fun configure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            this.inputAudioFormat = AudioFormat.NOT_SET
            this.outputAudioFormat = AudioFormat.NOT_SET
            return AudioFormat.NOT_SET
        }
        this.inputAudioFormat = inputAudioFormat
        this.outputAudioFormat = inputAudioFormat

        val bytesPerSecond = inputAudioFormat.sampleRate * inputAudioFormat.channelCount * 2
        this.dynamicChunkThresholdBytes = bytesPerSecond * 4

        return outputAudioFormat
    }

    override fun isActive(): Boolean = outputAudioFormat != AudioFormat.NOT_SET

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        if (isCapturing && inputAudioFormat.sampleRate > 0) {
            val dup = inputBuffer.duplicate()
            val tempBytes = ByteArray(dup.remaining())
            dup.get(tempBytes)

            synchronized(pcmAccumulator) {
                pcmAccumulator.write(tempBytes)
                if (pcmAccumulator.size() >= dynamicChunkThresholdBytes) {
                    val rawPcm = pcmAccumulator.toByteArray()
                    pcmAccumulator.reset()
                    onChunkReady(rawPcm, inputAudioFormat.sampleRate, inputAudioFormat.channelCount)
                }
            }
        }

        if (buffer.capacity() < remaining) {
            buffer = ByteBuffer.allocateDirect(remaining).order(ByteOrder.nativeOrder())
        } else {
            buffer.clear()
        }
        buffer.put(inputBuffer)
        buffer.flip()
        outputBuffer = buffer
    }

    override fun queueEndOfStream() {
        inputEnded = true
    }

    override fun getOutput(): ByteBuffer {
        val out = outputBuffer
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        return out
    }

    override fun isEnded(): Boolean = inputEnded && outputBuffer === AudioProcessor.EMPTY_BUFFER

    override fun flush() {
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        inputEnded = false
        synchronized(pcmAccumulator) {
            pcmAccumulator.reset()
        }
    }

    override fun reset() {
        flush()
        buffer = AudioProcessor.EMPTY_BUFFER
        inputAudioFormat = AudioFormat.NOT_SET
        outputAudioFormat = AudioFormat.NOT_SET
    }
}