
package com.zelvyn.player.data

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import com.zelvyn.player.model.FolderItem
import com.zelvyn.player.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MediaStoreRepository(private val context: Context) {

    private data class RawMediaMeta(
        val id: Long,
        val uri: Uri,
        val rawTitle: String,
        val duration: Long,
        val size: Long,
        val dateAdded: Long,
        val width: Int,
        val height: Int,
        val mime: String,
        val folder: String,
        val isAudio: Boolean
    )

    suspend fun getLocalVideos(
        progressMap: Map<String, VideoProgressRecord> = emptyMap(),
        favoriteUris: Set<String> = emptySet()
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val rawList = mutableListOf<RawMediaMeta>()

        // 1. Video Discovery with Safe Projections
        val videoProjection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )
        val videoCollection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(videoCollection, videoProjection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndex(MediaStore.Video.Media.TITLE)
                val displayCol = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndex(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndex(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Video.Media.DATE_ADDED)
                val widthCol = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)
                val mimeCol = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
                val folderCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    try {
                        val id = if (idCol != -1) cursor.getLong(idCol) else continue
                        val rawTitle = if (titleCol != -1) cursor.getString(titleCol) else null
                        val displayName = if (displayCol != -1) cursor.getString(displayCol) else null
                        val name = displayName ?: rawTitle ?: "Video $id"
                        val duration = if (durCol != -1) cursor.getLong(durCol) else 0L
                        val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                        val dateAdded = if (dateCol != -1) cursor.getLong(dateCol) else 0L
                        val width = if (widthCol != -1) cursor.getInt(widthCol) else 1920
                        val height = if (heightCol != -1) cursor.getInt(heightCol) else 1080
                        val mime = if (mimeCol != -1) cursor.getString(mimeCol) ?: "video/mp4" else "video/mp4"
                        val folder = if (folderCol != -1) cursor.getString(folderCol) ?: "Internal" else "Internal"
                        val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)

                        rawList.add(
                            RawMediaMeta(
                                id = id,
                                uri = uri,
                                rawTitle = name,
                                duration = duration,
                                size = size,
                                dateAdded = dateAdded,
                                width = width,
                                height = height,
                                mime = mime,
                                folder = folder,
                                isAudio = false
                            )
                        )
                    } catch (t: Throwable) {
                        // Skip corrupted row safely
                    }
                }
            }
        } catch (t: Throwable) {
            t.printStackTrace()
        }

        // 2. Audio Discovery (API Level Safe Projections)
        val audioProjection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATE_ADDED,
                MediaStore.Audio.Media.MIME_TYPE,
                MediaStore.Audio.Media.BUCKET_DISPLAY_NAME
            )
        } else {
            arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATE_ADDED,
                MediaStore.Audio.Media.MIME_TYPE
            )
        }
        val audioCollection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        try {
            context.contentResolver.query(audioCollection, audioProjection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
                val displayCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                val folderCol = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    cursor.getColumnIndex(MediaStore.Audio.Media.BUCKET_DISPLAY_NAME)
                } else {
                    -1
                }

                while (cursor.moveToNext()) {
                    try {
                        val id = if (idCol != -1) cursor.getLong(idCol) else continue
                        val rawTitle = if (titleCol != -1) cursor.getString(titleCol) else null
                        val displayName = if (displayCol != -1) cursor.getString(displayCol) else null
                        val name = displayName ?: rawTitle ?: "Audio $id"
                        val duration = if (durCol != -1) cursor.getLong(durCol) else 0L
                        val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                        val dateAdded = if (dateCol != -1) cursor.getLong(dateCol) else 0L
                        val mime = if (mimeCol != -1) cursor.getString(mimeCol) ?: "audio/mp3" else "audio/mp3"
                        val folder = if (folderCol != -1) cursor.getString(folderCol) ?: "Music" else "Music"
                        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

                        rawList.add(
                            RawMediaMeta(
                                id = id,
                                uri = uri,
                                rawTitle = name,
                                duration = duration,
                                size = size,
                                dateAdded = dateAdded,
                                width = 0,
                                height = 0,
                                mime = mime,
                                folder = folder,
                                isAudio = true
                            )
                        )
                    } catch (t: Throwable) {
                        // Skip corrupted audio row
                    }
                }
            }
        } catch (t: Throwable) {
            t.printStackTrace()
        }

        // 3. Parallelized Thumbnail Generation with LinkageError & OOM Protection
        val semaphore = Semaphore(4)
        val finalMediaList = coroutineScope {
            rawList.map { meta ->
                async(Dispatchers.IO) {
                    val uriString = meta.uri.toString()
                    val progressRecord = progressMap[uriString]
                    val savedPos = progressRecord?.positionMs ?: 0L
                    val lastWatchedTime = progressRecord?.lastWatchedTimeMs ?: 0L
                    val isFav = favoriteUris.contains(uriString)

                    val cleanTitle = cleanDisplayTitle(meta.rawTitle)
                    val resolution = if (meta.isAudio) {
                        "HQ Audio"
                    } else {
                        when {
                            meta.width >= 3840 || meta.height >= 2160 -> "4K HDR"
                            meta.width >= 1920 || meta.height >= 1080 -> "1080p"
                            meta.width >= 1280 || meta.height >= 720 -> "720p"
                            else -> "SD"
                        }
                    }

                    var thumbnail: Bitmap? = null
                    if (!meta.isAudio) {
                        thumbnail = semaphore.withPermit {
                            loadOrGenerateThumbnail(meta.id, meta.uri, meta.dateAdded)
                        }
                    }

                    VideoItem(
                        id = meta.id,
                        uri = meta.uri,
                        title = cleanTitle,
                        rawFileName = meta.rawTitle,
                        durationMs = meta.duration,
                        sizeBytes = meta.size,
                        dateAdded = meta.dateAdded,
                        resolution = resolution,
                        width = meta.width,
                        height = meta.height,
                        folder = meta.folder,
                        mimeType = meta.mime,
                        lastPositionMs = savedPos,
                        lastWatchedTimeMs = lastWatchedTime,
                        isFavorite = isFav,
                        thumbnailBitmap = thumbnail
                    )
                }
            }.awaitAll()
        }

        finalMediaList.sortedByDescending { it.dateAdded }
    }

    private fun loadOrGenerateThumbnail(id: Long, uri: Uri, dateAdded: Long): Bitmap? {
        val cached = getDiskCachedThumbnail(id, dateAdded)
        if (cached != null) return cached

        var generated: Bitmap? = null
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                generated = context.contentResolver.loadThumbnail(uri, Size(240, 160), null)
            } else {
                @Suppress("DEPRECATION")
                generated = MediaStore.Video.Thumbnails.getThumbnail(
                    context.contentResolver,
                    id,
                    MediaStore.Video.Thumbnails.MINI_KIND,
                    null
                )
            }
            if (generated != null) {
                saveThumbnailToDisk(id, dateAdded, generated)
            }
        } catch (t: Throwable) {
            // Guard against OutOfMemoryError and OS decoding bugs
        }
        return generated
    }

    private fun getDiskCachedThumbnail(id: Long, dateAdded: Long): Bitmap? {
        return try {
            val file = File(context.cacheDir, "thumbs/${id}_${dateAdded}.jpg")
            if (file.exists() && file.length() > 0) {
                val options = BitmapFactory.Options().apply {
                    inPreferredConfig = Bitmap.Config.RGB_565 // 50% RAM reduction
                }
                BitmapFactory.decodeFile(file.absolutePath, options)
            } else null
        } catch (t: Throwable) {
            null
        }
    }

    private fun saveThumbnailToDisk(id: Long, dateAdded: Long, bitmap: Bitmap) {
        try {
            val dir = File(context.cacheDir, "thumbs").apply { mkdirs() }
            val file = File(dir, "${id}_${dateAdded}.jpg")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out) // Safe on all Android versions
            }
        } catch (t: Throwable) {
            // Ignore disk cache write errors
        }
    }

    private fun cleanDisplayTitle(raw: String): String {
        var name = raw.substringBeforeLast('.')
        name = name.replace(Regex("[._]"), " ")

        val noiseWords = listOf(
            "\\b(1080p|720p|480p|2160p|4k|8k|uhd|fhd|hdrip|bluray|brrip|web-dl|webrip|hdtv|dvdrip)\\b",
            "\\b(x264|x265|hevc|h264|h265|aac|ac3|dts|mp3|dd5\\.1|atmos|10bit|hdr|remux)\\b",
            "\\b(rarbg|yify|yts|eztv|sparks|galaxyrg|cine|amzn|nf|dsnp|hmax)\\b"
        )
        for (pattern in noiseWords) {
            name = name.replace(Regex(pattern, RegexOption.IGNORE_CASE), "")
        }
        name = name.replace(Regex("[-–—()\\[\\]{}]"), " ")
        name = name.replace(Regex("\\s+"), " ").trim()
        return if (name.isNotBlank()) name else raw
    }

    suspend fun getFolders(videos: List<VideoItem>): List<FolderItem> = withContext(Dispatchers.Default) {
        videos.groupBy { it.folder }.map { (folderName, list) ->
            FolderItem(
                name = folderName,
                videoCount = list.size,
                latestVideo = list.firstOrNull()
            )
        }.sortedByDescending { it.videoCount }
    }
}

