package com.zelvyn.player.data

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import com.zelvyn.player.model.PlaylistItem
import com.zelvyn.player.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaStoreRepository(private val context: Context) {

    suspend fun getLocalVideos(): List<VideoItem> = withContext(Dispatchers.IO) {
        val videoList = mutableListOf<VideoItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )

        val collection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(collection, projection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val folderCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val title = cursor.getString(titleCol) ?: "Untitled Video"
                    val duration = cursor.getLong(durCol)
                    val folder = if (folderCol != -1) cursor.getString(folderCol) ?: "Movies" else "Movies"
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)

                    videoList.add(
                        VideoItem(
                            id = id,
                            uri = uri,
                            title = title,
                            durationMs = duration,
                            resolution = "4K HDR",
                            hdrType = "HDR10+",
                            folder = folder
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        if (videoList.isEmpty()) {
            videoList.addAll(getCuratedDemoCatalog())
        }
        videoList
    }

    fun getPlaylists(): List<PlaylistItem> = listOf(
        PlaylistItem("1", "Favorites", 128),
        PlaylistItem("2", "Watch Later", 32),
        PlaylistItem("3", "Movies Marathon", 48),
        PlaylistItem("4", "Travel Videos", 15),
        PlaylistItem("5", "Anime Collection", 64)
    )

    private fun getCuratedDemoCatalog(): List<VideoItem> = listOf(
        VideoItem(
            id = 1,
            uri = Uri.parse("https://storage.googleapis.com/exoplayer-test-media-1/mp4/dizzy-short.mp4"),
            title = "Interstellar (2014)",
            durationMs = 10144000L,
            resolution = "8K",
            hdrType = "Dolby Vision",
            year = "2014",
            folder = "Movies"
        ),
        VideoItem(
            id = 2,
            uri = Uri.parse("https://storage.googleapis.com/exoplayer-test-media-1/mp4/dizzy-short.mp4"),
            title = "Dune: Part Two (2024)",
            durationMs = 9960000L,
            resolution = "4K",
            hdrType = "HDR10+",
            year = "2024",
            folder = "Movies"
        ),
        VideoItem(
            id = 3,
            uri = Uri.parse("https://storage.googleapis.com/exoplayer-test-media-1/mp4/dizzy-short.mp4"),
            title = "The Batman (2022)",
            durationMs = 10560000L,
            resolution = "4K",
            hdrType = "HDR10+",
            year = "2022",
            folder = "Movies"
        ),
        VideoItem(
            id = 4,
            uri = Uri.parse("https://storage.googleapis.com/exoplayer-test-media-1/mp4/dizzy-short.mp4"),
            title = "Oppenheimer (2023)",
            durationMs = 10800000L,
            resolution = "8K",
            hdrType = "Dolby Vision",
            year = "2023",
            folder = "Movies"
        ),
        VideoItem(
            id = 5,
            uri = Uri.parse("https://storage.googleapis.com/exoplayer-test-media-1/mp4/dizzy-short.mp4"),
            title = "Inception (2010)",
            durationMs = 8880000L,
            resolution = "4K",
            hdrType = "Dolby Vision",
            year = "2010",
            folder = "Movies"
        ),
        VideoItem(
            id = 6,
            uri = Uri.parse("https://storage.googleapis.com/exoplayer-test-media-1/mp4/dizzy-short.mp4"),
            title = "Tenet (2020)",
            durationMs = 9000000L,
            resolution = "4K",
            hdrType = "HDR10+",
            year = "2020",
            folder = "Movies"
        )
    )
}