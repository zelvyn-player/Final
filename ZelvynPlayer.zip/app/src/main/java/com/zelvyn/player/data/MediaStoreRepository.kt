
package com.zelvyn.player.data

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import com.zelvyn.player.model.FolderItem
import com.zelvyn.player.model.VideoItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MediaStoreRepository(private val context: Context) {

    suspend fun getLocalVideos(
        progressMap: Map<String, VideoProgressRecord> = emptyMap(),
        favoriteUris: Set<String> = emptySet()
    ): List<VideoItem> = withContext(Dispatchers.IO) {
        val mediaList = mutableListOf<VideoItem>()

        val videoProjection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED,
            MediaStore.Video.Media.WIDTH,
            MediaStore.Video.Media.HEIGHT,
            MediaStore.Video.Media.MIME_TYPE,
            MediaStore.Video.Media.BUCKET_DISPLAY_NAME
        )

        val videoCollection = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            context.contentResolver.query(videoCollection, videoProjection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.TITLE)
                val displayCol = cursor.getColumnIndex(MediaStore.Video.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)
                val widthCol = cursor.getColumnIndex(MediaStore.Video.Media.WIDTH)
                val heightCol = cursor.getColumnIndex(MediaStore.Video.Media.HEIGHT)
                val mimeCol = cursor.getColumnIndex(MediaStore.Video.Media.MIME_TYPE)
                val folderCol = cursor.getColumnIndex(MediaStore.Video.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val rawTitle = cursor.getString(titleCol)
                    val displayName = if (displayCol != -1) cursor.getString(displayCol) else null
                    val title = rawTitle ?: displayName ?: "Video $id"
                    val duration = cursor.getLong(durCol)
                    val size = cursor.getLong(sizeCol)
                    val dateAdded = cursor.getLong(dateCol)
                    val width = if (widthCol != -1) cursor.getInt(widthCol) else 1920
                    val height = if (heightCol != -1) cursor.getInt(heightCol) else 1080
                    val mime = if (mimeCol != -1) cursor.getString(mimeCol) else "video/mp4"
                    val folder = if (folderCol != -1) cursor.getString(folderCol) ?: "Internal" else "Internal"

                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)
                    val uriString = uri.toString()

                    val resolution = when {
                        width >= 3840 || height >= 2160 -> "4K HDR"
                        width >= 1920 || height >= 1080 -> "1080p"
                        width >= 1280 || height >= 720 -> "720p"
                        else -> "SD"
                    }

                    var thumb: Bitmap? = null
                    try {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                            thumb = context.contentResolver.loadThumbnail(uri, Size(320, 200), null)
                        }
                    } catch (e: Exception) {
                        // Fallback
                    }

                    val progressRecord = progressMap[uriString]
                    val savedPos = progressRecord?.positionMs ?: 0L
                    val lastWatchedTime = progressRecord?.lastWatchedTimeMs ?: 0L
                    val isFav = favoriteUris.contains(uriString)

                    mediaList.add(
                        VideoItem(
                            id = id,
                            uri = uri,
                            title = title,
                            durationMs = duration,
                            sizeBytes = size,
                            dateAdded = dateAdded,
                            resolution = resolution,
                            width = width,
                            height = height,
                            folder = folder,
                            mimeType = mime,
                            lastPositionMs = savedPos,
                            lastWatchedTimeMs = lastWatchedTime,
                            isFavorite = isFav,
                            thumbnailBitmap = thumb
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        val audioProjection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.MIME_TYPE,
            MediaStore.Audio.Media.BUCKET_DISPLAY_NAME
        )
        val audioCollection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        try {
            context.contentResolver.query(audioCollection, audioProjection, null, null, sortOrder)?.use { cursor ->
                val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val displayCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                val durCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
                val mimeCol = cursor.getColumnIndex(MediaStore.Audio.Media.MIME_TYPE)
                val folderCol = cursor.getColumnIndex(MediaStore.Audio.Media.BUCKET_DISPLAY_NAME)

                while (cursor.moveToNext()) {
                    val id = cursor.getLong(idCol)
                    val rawTitle = cursor.getString(titleCol)
                    val displayName = if (displayCol != -1) cursor.getString(displayCol) else null
                    val title = rawTitle ?: displayName ?: "Audio $id"
                    val duration = cursor.getLong(durCol)
                    val size = cursor.getLong(sizeCol)
                    val dateAdded = cursor.getLong(dateCol)
                    val mime = if (mimeCol != -1) cursor.getString(mimeCol) else "audio/mp3"
                    val folder = if (folderCol != -1) cursor.getString(folderCol) ?: "Music" else "Music"

                    val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
                    val uriString = uri.toString()

                    val progressRecord = progressMap[uriString]
                    val savedPos = progressRecord?.positionMs ?: 0L
                    val lastWatchedTime = progressRecord?.lastWatchedTimeMs ?: 0L
                    val isFav = favoriteUris.contains(uriString)

                    mediaList.add(
                        VideoItem(
                            id = id,
                            uri = uri,
                            title = title,
                            durationMs = duration,
                            sizeBytes = size,
                            dateAdded = dateAdded,
                            resolution = "HQ Audio",
                            width = 0,
                            height = 0,
                            folder = folder,
                            mimeType = mime,
                            lastPositionMs = savedPos,
                            lastWatchedTimeMs = lastWatchedTime,
                            isFavorite = isFav,
                            thumbnailBitmap = null
                        )
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        mediaList.sortedByDescending { it.dateAdded }
    }

    suspend fun getFolders(videos: List<VideoItem>): List<FolderItem> = withContext(Dispatchers.Default) {
        videos.groupBy { it.folder }.map { (folderName, list) ->
            FolderItem(
                name = folderName,
                videoCount = list.size,
                latestVideo = list.firstOrNull()
            )
        }.sortedByDescending { it.videoCount }
    }
}

