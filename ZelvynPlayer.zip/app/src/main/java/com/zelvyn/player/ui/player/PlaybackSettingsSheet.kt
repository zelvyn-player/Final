package com.zelvyn.player.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlaybackSettingsSheet(
    playbackSpeed: Float,
    prefsManager: PreferencesManager,
    onSpeedChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val userPrefs by prefsManager.userPreferences.collectAsState()

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 0.dp
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(text = "Playback Settings", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)

            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Playback Speed
                item {
                    SettingsRow(
                        icon = Icons.Rounded.Speed,
                        title = "Playback Speed",
                        value = "${playbackSpeed}x >",
                        onClick = {
                            val nextSpeed = when (playbackSpeed) {
                                1.0f -> 1.25f
                                1.25f -> 1.5f
                                1.5f -> 2.0f
                                2.0f -> 0.75f
                                else -> 1.0f
                            }
                            onSpeedChange(nextSpeed)
                        }
                    )
                }

                // Skip Interval
                item {
                    SettingsRow(
                        icon = Icons.Rounded.Replay,
                        title = "Skip Interval",
                        value = "${userPrefs.skipIntervalSeconds} seconds >",
                        onClick = {
                            val next = if (userPrefs.skipIntervalSeconds == 10) 15 else 10
                            prefsManager.updatePreferences { p -> p.copy(skipIntervalSeconds = next) }
                        }
                    )
                }

                // Switches
                item {
                    SettingsToggleRow(
                        icon = Icons.Rounded.History,
                        title = "Remember Last Position",
                        checked = userPrefs.rememberLastPosition,
                        onCheckedChange = { prefsManager.updatePreferences { p -> p.copy(rememberLastPosition = it) } }
                    )
                }

                item {
                    SettingsToggleRow(
                        icon = Icons.Rounded.PlayCircle,
                        title = "Resume on App Launch",
                        checked = userPrefs.resumeOnAppLaunch,
                        onCheckedChange = { prefsManager.updatePreferences { p -> p.copy(resumeOnAppLaunch = it) } }
                    )
                }

                item {
                    SettingsToggleRow(
                        icon = Icons.Rounded.Headphones,
                        title = "Background Playback",
                        checked = userPrefs.backgroundPlayback,
                        onCheckedChange = { prefsManager.updatePreferences { p -> p.copy(backgroundPlayback = it) } }
                    )
                }

                item {
                    SettingsToggleRow(
                        icon = Icons.Rounded.PictureInPicture,
                        title = "PiP (Picture-in-Picture)",
                        checked = userPrefs.pipEnabled,
                        onCheckedChange = { prefsManager.updatePreferences { p -> p.copy(pipEnabled = it) } }
                    )
                }
            }
        }
    }
}

@Composable
fun SettingsRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, value: String, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable { onClick() }
            .padding(14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, contentDescription = null, tint = BrandAccent, modifier = Modifier.size(20.dp))
            Text(text = title, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
        }
        Text(text = value, fontSize = 12.sp, color = MaterialTheme.colorScheme.secondary)
    }
}

@Composable
fun SettingsToggleRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, checked: Boolean, onCheckedChange: (Boolean) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Icon(icon, contentDescription = null, tint = BrandAccent, modifier = Modifier.size(20.dp))
            Text(text = title, fontSize = 13.sp, color = MaterialTheme.colorScheme.onBackground)
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(checkedThumbColor = CardSurfaceLight, checkedTrackColor = BrandAccent)
        )
    }
}
