package com.zelvyn.player

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.audio.DeviceHardwareController
import com.zelvyn.player.audio.ZelvynAudioCaptureProcessor
import com.zelvyn.player.data.ExoPlayerTrackManager
import com.zelvyn.player.data.MediaStoreRepository
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.data.TranslationCoordinator
import com.zelvyn.player.model.VideoItem
import com.zelvyn.player.ui.library.LibraryScreen
import com.zelvyn.player.ui.navigation.AppTab
import com.zelvyn.player.ui.navigation.ZelvynBottomNavBar
import com.zelvyn.player.ui.onboarding.OnboardingScreen
import com.zelvyn.player.ui.player.PlayerScreen
import com.zelvyn.player.ui.privacy.PrivacyPolicyScreen
import com.zelvyn.player.ui.settings.SettingsScreen
import com.zelvyn.player.ui.theme.ZelvynTheme
import com.zelvyn.player.ui.translate.TranslateScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var exoPlayer: ExoPlayer
    private var mediaSession: MediaSession? = null
    private lateinit var mediaStoreRepository: MediaStoreRepository
    private lateinit var hardwareController: DeviceHardwareController
    private lateinit var prefsManager: PreferencesManager
    private lateinit var trackManager: ExoPlayerTrackManager
    private val audioDspManager = AudioDspManager()
    private val translationCoordinator = TranslationCoordinator(lifecycleScope)

    private lateinit var audioCaptureProcessor: ZelvynAudioCaptureProcessor
    private var activeVideoItem: VideoItem? = null
    private var isPipActive = mutableStateOf(false)

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefsManager = PreferencesManager(this, lifecycleScope)
        mediaStoreRepository = MediaStoreRepository(this)
        hardwareController = DeviceHardwareController(this)

        audioCaptureProcessor = ZelvynAudioCaptureProcessor { pcmData, sampleRate, channels ->
            val userPrefs = prefsManager.userPreferences.value
            translationCoordinator.onAudioChunkCaptured(
                pcmData = pcmData,
                sampleRate = sampleRate,
                channels = channels,
                currentPlaybackPosMs = if (::exoPlayer.isInitialized) exoPlayer.currentPosition else 0L,
                apiKey = userPrefs.geminiApiKey
            )
        }

        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: android.content.Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(audioCaptureProcessor))
                    .build()
            }
        }

        exoPlayer = ExoPlayer.Builder(this, renderersFactory).build()
        trackManager = ExoPlayerTrackManager(exoPlayer)

        mediaSession = MediaSession.Builder(this, exoPlayer).build()

        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                audioDspManager.bindAudioSession(audioSessionId)
            }

            override fun onTracksChanged(tracks: Tracks) {
                trackManager.updateTracks(tracks)
            }

            override fun onPositionDiscontinuity(
                oldPosition: androidx.media3.common.Player.PositionInfo,
                newPosition: androidx.media3.common.Player.PositionInfo,
                reason: Int
            ) {
                if (reason == androidx.media3.common.Player.DISCONTINUITY_REASON_SEEK) {
                    translationCoordinator.onSeekInvalidate()
                    audioCaptureProcessor.flush()
                }
            }
        })

        lifecycleScope.launch {
            while (true) {
                if (::exoPlayer.isInitialized && exoPlayer.isPlaying) {
                    val pos = exoPlayer.currentPosition
                    translationCoordinator.onPlaybackPositionChanged(pos)
                    activeVideoItem?.let { video ->
                        prefsManager.saveVideoProgress(video.id, pos)
                    }
                }
                delay(150)
            }
        }

        checkAndRequestMediaPermissions()

        setContent {
            ZelvynTheme {
                val userPrefs by prefsManager.userPreferences.collectAsState()
                var selectedTab by remember { mutableStateOf(AppTab.LIBRARY) }
                var activeVideo by remember { mutableStateOf<VideoItem?>(null) }
                var videoList by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var isViewingPrivacySubscreen by remember { mutableStateOf(false) }

                val activeSegment by translationCoordinator.activeSegment.collectAsState()
                val translationStatus by translationCoordinator.status.collectAsState()
                val translationStatusMsg by translationCoordinator.statusMessage.collectAsState()
                val isTranslationActive by translationCoordinator.isTranslationActive.collectAsState()

                val hasPermission = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        android.Manifest.permission.READ_MEDIA_VIDEO
                    } else {
                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                ) == PackageManager.PERMISSION_GRANTED

                LaunchedEffect(Unit) {
                    videoList = mediaStoreRepository.getLocalVideos().map { item ->
                        val savedPos = prefsManager.getVideoProgress(item.id)
                        item.copy(lastPositionMs = savedPos)
                    }
                }

                if (!userPrefs.hasCompletedOnboarding) {
                    OnboardingScreen(
                        onFinished = { prefsManager.setOnboardingCompleted(true) }
                    )
                } else if (activeVideo != null) {
                    PlayerScreen(
                        exoPlayer = exoPlayer,
                        video = activeVideo!!,
                        activeSegment = activeSegment,
                        translationStatus = translationStatus,
                        translationStatusMsg = translationStatusMsg,
                        isTranslationActive = isTranslationActive,
                        audioDspManager = audioDspManager,
                        hardwareController = hardwareController,
                        trackManager = trackManager,
                        subtitleFontSizeSp = userPrefs.subtitleFontSizeSp,
                        subtitleBgAlpha = userPrefs.subtitleBackgroundAlpha,
                        isPiPMode = isPipActive.value,
                        onEnterPiP = { enterPiP() },
                        onBackPress = {
                            exitPlayerMode()
                            activeVideo = null
                        },
                        onToggleLiveTranslation = {
                            if (isTranslationActive) {
                                audioCaptureProcessor.isCapturing = false
                                translationCoordinator.stopSession()
                            } else {
                                audioCaptureProcessor.isCapturing = true
                                translationCoordinator.startSession(
                                    source = "Auto Detect",
                                    target = userPrefs.defaultTargetLang,
                                    apiKey = userPrefs.geminiApiKey
                                )
                            }
                        }
                    )
                } else {
                    Scaffold(
                        bottomBar = {
                            ZelvynBottomNavBar(
                                selectedTab = selectedTab,
                                onTabSelected = {
                                    isViewingPrivacySubscreen = false
                                    selectedTab = it
                                }
                            )
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when {
                                isViewingPrivacySubscreen || selectedTab == AppTab.PRIVACY -> {
                                    PrivacyPolicyScreen(
                                        onBack = { isViewingPrivacySubscreen = false }
                                    )
                                }
                                selectedTab == AppTab.LIBRARY -> {
                                    LibraryScreen(
                                        videos = videoList,
                                        hasStoragePermission = hasPermission,
                                        onVideoSelected = { video ->
                                            activeVideo = video
                                            activeVideoItem = video
                                            enterPlayerMode(video)
                                        }
                                    )
                                }
                                selectedTab == AppTab.TRANSLATE -> {
                                    TranslateScreen(
                                        translationCoordinator = translationCoordinator,
                                        apiKey = userPrefs.geminiApiKey,
                                        onNavigateSettings = { selectedTab = AppTab.SETTINGS }
                                    )
                                }
                                selectedTab == AppTab.SETTINGS -> {
                                    SettingsScreen(
                                        prefsManager = prefsManager,
                                        onNavigatePrivacy = { isViewingPrivacySubscreen = true }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun enterPlayerMode(video: VideoItem) {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        hideSystemBars()
        exoPlayer.setMediaItem(MediaItem.fromUri(video.uri))
        exoPlayer.prepare()
        if (video.lastPositionMs > 2000L && video.lastPositionMs < video.durationMs - 5000L) {
            exoPlayer.seekTo(video.lastPositionMs)
        }
        exoPlayer.play()
    }

    private fun exitPlayerMode() {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        showSystemBars()
        exoPlayer.stop()
        audioCaptureProcessor.isCapturing = false
        translationCoordinator.stopSession()
        activeVideoItem = null
    }

    private fun enterPiP() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onPictureInPictureModeChanged(
        isInPictureInPictureMode: Boolean,
        newConfig: Configuration
    ) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isPipActive.value = isInPictureInPictureMode
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (activeVideoItem != null && exoPlayer.isPlaying) {
            enterPiP()
        }
    }

    private fun checkAndRequestMediaPermissions() {
        val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            android.Manifest.permission.READ_MEDIA_VIDEO
        } else {
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(perm), 101)
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onResume() {
        super.onResume()
        if (::exoPlayer.isInitialized && !isPipActive.value) exoPlayer.play()
    }

    override fun onPause() {
        super.onPause()
        if (::exoPlayer.isInitialized && !isPipActive.value) exoPlayer.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        audioDspManager.release()
        mediaSession?.release()
        if (::exoPlayer.isInitialized) {
            exoPlayer.release()
        }
    }
}