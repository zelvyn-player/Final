
package com.zelvyn.player

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Rational
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.audio.DeviceHardwareController
import com.zelvyn.player.audio.ZelvynAudioCaptureProcessor
import com.zelvyn.player.data.ExoPlayerTrackManager
import com.zelvyn.player.data.MediaStoreRepository
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.data.TranslationCoordinator
import com.zelvyn.player.model.*
import com.zelvyn.player.ui.common.MiniPlayerBar
import com.zelvyn.player.ui.home.HomeScreen
import com.zelvyn.player.ui.library.LibraryScreen
import com.zelvyn.player.ui.navigation.AppTab
import com.zelvyn.player.ui.navigation.ZelvynBottomNavBar
import com.zelvyn.player.ui.onboarding.OnboardingScreen
import com.zelvyn.player.ui.player.EqualizerSheet
import com.zelvyn.player.ui.player.PlayerScreen
import com.zelvyn.player.ui.player.QueueSheet
import com.zelvyn.player.ui.player.SpeedSheet
import com.zelvyn.player.ui.player.SubtitleStyleScreen
import com.zelvyn.player.ui.privacy.PrivacyPolicyScreen
import com.zelvyn.player.ui.settings.AboutScreen
import com.zelvyn.player.ui.settings.SettingsScreen
import com.zelvyn.player.ui.theme.ZelvynTheme
import com.zelvyn.player.ui.translate.TranslateScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.*

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var exoPlayer: ExoPlayer
    private var mediaSession: MediaSession? = null
    private lateinit var mediaStoreRepository: MediaStoreRepository
    private lateinit var hardwareController: DeviceHardwareController
    private lateinit var prefsManager: PreferencesManager
    private lateinit var trackManager: ExoPlayerTrackManager
    private val audioDspManager = AudioDspManager()

    private var textToSpeech: TextToSpeech? = null
    private lateinit var translationCoordinator: TranslationCoordinator
    private lateinit var audioCaptureProcessor: ZelvynAudioCaptureProcessor

    private var activeVideoItem = mutableStateOf<VideoItem?>(null)
    private var isPlayerExpanded = mutableStateOf(false)
    private var isPipActive = mutableStateOf(false)

    private var queueRepeatMode = mutableStateOf(QueueRepeatMode.OFF)
    private var isQueueShuffleActive = mutableStateOf(false)
    private var activeQueueList = mutableStateListOf<VideoItem>()

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefsManager = PreferencesManager(this, lifecycleScope)
        mediaStoreRepository = MediaStoreRepository(this)
        hardwareController = DeviceHardwareController(this)
        textToSpeech = TextToSpeech(this, this)

        translationCoordinator = TranslationCoordinator(
            scope = lifecycleScope,
            onVoiceOutputRequested = { text, targetLang ->
                val prefs = prefsManager.userPreferences.value
                if (prefs.translationMode == TranslationMode.VOICE || prefs.translationMode == TranslationMode.BOTH) {
                    textToSpeech?.let { tts ->
                        val iso = SupportedLanguages.toIsoCode(targetLang)
                        val loc = Locale.forLanguageTag(iso)
                        tts.language = loc
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ZelvynTTS")
                    }
                }
            }
        )

        audioCaptureProcessor = ZelvynAudioCaptureProcessor { pcmData, sampleRate, channels ->
            val userPrefs = prefsManager.userPreferences.value
            translationCoordinator.onAudioChunkCaptured(
                pcmData = pcmData,
                sampleRate = sampleRate,
                channels = channels,
                currentPlaybackPosMs = if (::exoPlayer.isInitialized) exoPlayer.currentPosition else 0L,
                apiKey = userPrefs.geminiApiKey
            )
        }

        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: android.content.Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(audioCaptureProcessor))
                    .setEnableAudioTrackPlaybackParams(true)
                    .build()
            }
        }

        exoPlayer = ExoPlayer.Builder(this, renderersFactory).build().apply {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build()
            setAudioAttributes(audioAttributes, true)
        }

        trackManager = ExoPlayerTrackManager(exoPlayer)
        mediaSession = MediaSession.Builder(this, exoPlayer).build()

        exoPlayer.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId > 0) {
                    audioDspManager.bindAudioSession(audioSessionId)
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                trackManager.updateTracks(tracks)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    handleAutoPlayNext()
                }
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (mediaItem == null) return
                val found = activeQueueList.find { it.id.toString() == mediaItem.mediaId }
                if (found != null) {
                    val favs = prefsManager.favoriteUris.value
                    val rec = prefsManager.getProgressRecord(found.uri.toString())
                    activeVideoItem.value = found.copy(
                        isFavorite = favs.contains(found.uri.toString()),
                        lastPositionMs = rec?.positionMs ?: 0L,
                        lastWatchedTimeMs = rec?.lastWatchedTimeMs ?: 0L
                    )
                }
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (reason == Player.DISCONTINUITY_REASON_SEEK) {
                    translationCoordinator.onSeekInvalidate()
                    audioCaptureProcessor.flush()
                }
            }
        })

        lifecycleScope.launch(Dispatchers.Main) {
            var loopCounter = 0
            while (true) {
                if (::exoPlayer.isInitialized && exoPlayer.isPlaying) {
                    val pos = exoPlayer.currentPosition
                    val offset = prefsManager.userPreferences.value.subtitleOffsetMs
                    translationCoordinator.onPlaybackPositionChanged(pos + offset)
                    loopCounter++
                    if (loopCounter >= 10) {
                        loopCounter = 0
                        activeVideoItem.value?.let { video ->
                            prefsManager.saveVideoProgress(video.uri.toString(), pos)
                        }
                    }
                }
                delay(250)
            }
        }

        checkAndRequestMediaPermissions()

        setContent {
            val userPrefs by prefsManager.userPreferences.collectAsState()
            val favoriteUris by prefsManager.favoriteUris.collectAsState()

            ZelvynTheme(themeMode = userPrefs.themeMode, accentColorHex = userPrefs.accentColor) {
                if (!userPrefs.hasCompletedOnboarding) {
                    OnboardingScreen(
                        onFinished = {
                            prefsManager.updatePreferences { it.copy(hasCompletedOnboarding = true) }
                        }
                    )
                    return@ZelvynTheme
                }

                var selectedTab by remember { mutableStateOf(AppTab.HOME) }
                var videoList by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var folderList by remember { mutableStateOf<List<FolderItem>>(emptyList()) }
                var isLoadingVideos by remember { mutableStateOf(true) }

                var isViewingPrivacySubscreen by remember { mutableStateOf(false) }
                var isViewingAboutSubscreen by remember { mutableStateOf(false) }
                var isViewingSubtitleStyleSubscreen by remember { mutableStateOf(false) }
                var showGlobalEqualizer by remember { mutableStateOf(false) }
                var showGlobalSpeed by remember { mutableStateOf(false) }

                val activeSegment by translationCoordinator.activeSegment.collectAsState()
                val translationStatus by translationCoordinator.status.collectAsState()
                val translationStatusMsg by translationCoordinator.statusMessage.collectAsState()
                val isTranslationActive by translationCoordinator.isTranslationActive.collectAsState()

                val hasPermission = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        android.Manifest.permission.READ_MEDIA_VIDEO
                    } else {
                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                ) == PackageManager.PERMISSION_GRANTED

                fun loadLibrary() {
                    lifecycleScope.launch {
                        if (hasPermission) {
                            isLoadingVideos = true
                            val batchProgress = prefsManager.getAllProgressRecords()
                            val realVideos = mediaStoreRepository.getLocalVideos(batchProgress, favoriteUris)
                            videoList = realVideos
                            folderList = mediaStoreRepository.getFolders(realVideos)
                            activeQueueList.clear()
                            activeQueueList.addAll(realVideos)
                            isLoadingVideos = false
                        } else {
                            isLoadingVideos = false
                        }
                    }
                }

                LaunchedEffect(hasPermission, favoriteUris) {
                    loadLibrary()
                }

                if (isPlayerExpanded.value && activeVideoItem.value != null) {
                    val currentVideo = activeVideoItem.value!!
                    val isFav = favoriteUris.contains(currentVideo.uri.toString())

                    PlayerScreen(
                        exoPlayer = exoPlayer,
                        video = currentVideo.copy(isFavorite = isFav),
                        queue = activeQueueList,
                        activeSegment = activeSegment,
                        translationStatus = translationStatus,
                        translationStatusMsg = translationStatusMsg,
                        isTranslationActive = isTranslationActive,
                        audioDspManager = audioDspManager,
                        hardwareController = hardwareController,
                        trackManager = trackManager,
                        prefsManager = prefsManager,
                        isPiPMode = isPipActive.value,
                        repeatMode = queueRepeatMode.value,
                        isShuffleActive = isQueueShuffleActive.value,
                        onToggleRepeat = {
                            queueRepeatMode.value = when (queueRepeatMode.value) {
                                QueueRepeatMode.OFF -> QueueRepeatMode.ALL
                                QueueRepeatMode.ALL -> QueueRepeatMode.ONE
                                QueueRepeatMode.ONE -> QueueRepeatMode.OFF
                            }
                        },
                        onToggleShuffle = {
                            isQueueShuffleActive.value = !isQueueShuffleActive.value
                        },
                        onToggleOrientation = { toggleOrientation() },
                        onEnterPiP = { enterPiP() },
                        onBackPress = {
                            isPlayerExpanded.value = false
                            showSystemBars()
                            requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
                            if (!userPrefs.backgroundPlayback) {
                                exoPlayer.pause()
                            }
                        },
                        onToggleLiveTranslation = {
                            if (isTranslationActive) {
                                audioCaptureProcessor.isCapturing = false
                                translationCoordinator.stopSession()
                            } else {
                                audioCaptureProcessor.isCapturing = true
                                translationCoordinator.startSession(
                                    source = userPrefs.sourceLang,
                                    target = userPrefs.defaultTargetLang,
                                    apiKey = userPrefs.geminiApiKey
                                )
                            }
                        },
                        onSelectQueueItem = { nextVideo -> enterPlayerMode(nextVideo, activeQueueList) },
                        onNavigateSubtitleStyle = { isViewingSubtitleStyleSubscreen = true }
                    )
                } else {
                    Scaffold(
                        bottomBar = {
                            Column {
                                if (activeVideoItem.value != null) {
                                    MiniPlayerBar(
                                        exoPlayer = exoPlayer,
                                        video = activeVideoItem.value!!,
                                        onExpand = {
                                            isPlayerExpanded.value = true
                                            hideSystemBars()
                                        },
                                        onOpenQueue = { selectedTab = AppTab.QUEUE }
                                    )
                                }

                                ZelvynBottomNavBar(
                                    selectedTab = selectedTab,
                                    onTabSelected = {
                                        isViewingPrivacySubscreen = false
                                        isViewingAboutSubscreen = false
                                        isViewingSubtitleStyleSubscreen = false
                                        selectedTab = it
                                    }
                                )
                            }
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when {
                                isViewingAboutSubscreen -> {
                                    AboutScreen(onBack = { isViewingAboutSubscreen = false })
                                }
                                isViewingPrivacySubscreen -> {
                                    PrivacyPolicyScreen(onBack = { isViewingPrivacySubscreen = false })
                                }
                                isViewingSubtitleStyleSubscreen -> {
                                    SubtitleStyleScreen(prefsManager = prefsManager, onBack = { isViewingSubtitleStyleSubscreen = false })
                                }
                                selectedTab == AppTab.HOME -> {
                                    HomeScreen(
                                        videos = videoList,
                                        folders = folderList,
                                        isLoading = isLoadingVideos,
                                        onVideoSelected = { video -> enterPlayerMode(video, videoList) },
                                        onSeeAllVideos = { selectedTab = AppTab.LIBRARY },
                                        onOpenContinueWatching = { selectedTab = AppTab.LIBRARY },
                                        onFolderSelected = { selectedTab = AppTab.LIBRARY },
                                        onOpenSearch = { selectedTab = AppTab.LIBRARY },
                                        onOpenAITools = { selectedTab = AppTab.AI_TOOLS },
                                        onOpenEqualizer = { showGlobalEqualizer = true },
                                        onOpenSpeed = { showGlobalSpeed = true },
                                        onOpenSettings = { selectedTab = AppTab.MORE }
                                    )
                                }
                                selectedTab == AppTab.LIBRARY -> {
                                    LibraryScreen(
                                        videos = videoList,
                                        folders = folderList,
                                        hasStoragePermission = hasPermission,
                                        isLoading = isLoadingVideos,
                                        favoriteUris = favoriteUris,
                                        layoutMode = userPrefs.libraryLayoutMode,
                                        onVideoSelected = { video -> enterPlayerMode(video, videoList) },
                                        onFolderSelected = { }
                                    )
                                }
                                selectedTab == AppTab.AI_TOOLS -> {
                                    TranslateScreen(
                                        translationCoordinator = translationCoordinator,
                                        prefsManager = prefsManager,
                                        onNavigateSubtitleStyle = { isViewingSubtitleStyleSubscreen = true },
                                        onNavigateSettings = { selectedTab = AppTab.MORE }
                                    )
                                }
                                selectedTab == AppTab.QUEUE -> {
                                    QueueSheet(
                                        queue = activeQueueList,
                                        currentPlayingId = activeVideoItem.value?.id ?: -1L,
                                        onSelectQueueItem = { video -> enterPlayerMode(video, activeQueueList) },
                                        onRemoveItem = { activeQueueList.remove(it) },
                                        onClearQueue = { activeQueueList.clear() },
                                        onDismiss = { selectedTab = AppTab.HOME }
                                    )
                                }
                                selectedTab == AppTab.MORE -> {
                                    SettingsScreen(
                                        prefsManager = prefsManager,
                                        onForceRescan = {
                                            loadLibrary()
                                            Toast.makeText(this@MainActivity, "Media library re-scanned.", Toast.LENGTH_SHORT).show()
                                        },
                                        onNavigateAbout = { isViewingAboutSubscreen = true },
                                        onNavigatePrivacy = { isViewingPrivacySubscreen = true },
                                        onNavigateSubtitleStyle = { isViewingSubtitleStyleSubscreen = true }
                                    )
                                }
                            }
                        }
                    }
                }

                if (showGlobalEqualizer) {
                    EqualizerSheet(
                        audioDspManager = audioDspManager,
                        onDismiss = { showGlobalEqualizer = false }
                    )
                }

                if (showGlobalSpeed) {
                    SpeedSheet(
                        currentSpeed = exoPlayer.playbackParameters.speed,
                        prefsManager = prefsManager,
                        onSpeedChange = { speed ->
                            exoPlayer.playbackParameters = androidx.media3.common.PlaybackParameters(speed, 1.0f)
                        },
                        onDismiss = { showGlobalSpeed = false }
                    )
                }
            }
        }
    }

    private fun handleAutoPlayNext() {
        if (queueRepeatMode.value == QueueRepeatMode.ONE) {
            exoPlayer.seekTo(0L)
            exoPlayer.play()
            return
        }

        val current = activeVideoItem.value ?: return
        val queue = activeQueueList
        val currentIndex = queue.indexOfFirst { it.id == current.id }
        if (currentIndex != -1) {
            val nextIndex = if (isQueueShuffleActive.value) {
                queue.indices.random()
            } else {
                currentIndex + 1
            }

            if (nextIndex in queue.indices) {
                enterPlayerMode(queue[nextIndex], queue)
            } else if (queueRepeatMode.value == QueueRepeatMode.ALL && queue.isNotEmpty()) {
                enterPlayerMode(queue[0], queue)
            }
        }
    }

    private fun enterPlayerMode(video: VideoItem, playlist: List<VideoItem> = activeQueueList) {
        activeVideoItem.value = video
        isPlayerExpanded.value = true
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER
        hideSystemBars()

        activeQueueList.clear()
        activeQueueList.addAll(if (playlist.isNotEmpty()) playlist else listOf(video))

        val startIndex = activeQueueList.indexOfFirst { it.id == video.id }.coerceAtLeast(0)
        val mediaItems = activeQueueList.map { item ->
            MediaItem.Builder()
                .setUri(item.uri)
                .setMediaId(item.id.toString())
                .setTag(item)
                .build()
        }

        exoPlayer.setMediaItems(
            mediaItems,
            startIndex,
            if (video.lastPositionMs > 2000L && video.lastPositionMs < video.durationMs - 5000L) video.lastPositionMs else 0L
        )
        exoPlayer.prepare()
        exoPlayer.play()

        prefsManager.saveVideoProgress(video.uri.toString(), video.lastPositionMs, System.currentTimeMillis())
    }

    private fun toggleOrientation() {
        requestedOrientation = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    private fun enterPiP() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isPipActive.value = isInPictureInPictureMode
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        val userPrefs = prefsManager.userPreferences.value
        if (activeVideoItem.value != null && exoPlayer.isPlaying && userPrefs.pipEnabled) {
            enterPiP()
        }
    }

    private fun checkAndRequestMediaPermissions() {
        val perms = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            arrayOf(
                android.Manifest.permission.READ_MEDIA_VIDEO,
                android.Manifest.permission.READ_MEDIA_AUDIO
            )
        } else {
            arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        val missing = perms.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            ActivityCompat.requestPermissions(this, missing.toTypedArray(), 101)
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.language = Locale.ENGLISH
        }
    }

    override fun onResume() {
        super.onResume()
        if (::exoPlayer.isInitialized && !isPipActive.value && activeVideoItem.value != null) {
            exoPlayer.play()
        }
    }

    override fun onPause() {
        super.onPause()
        if (::exoPlayer.isInitialized) {
            activeVideoItem.value?.let { video ->
                prefsManager.saveVideoProgress(video.uri.toString(), exoPlayer.currentPosition, System.currentTimeMillis())
            }
            if (!isPipActive.value && !prefsManager.userPreferences.value.backgroundPlayback) {
                exoPlayer.pause()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::exoPlayer.isInitialized) {
            activeVideoItem.value?.let { video ->
                prefsManager.saveVideoProgress(video.uri.toString(), exoPlayer.currentPosition, System.currentTimeMillis())
            }
            exoPlayer.release()
        }
        audioDspManager.release()
        textToSpeech?.shutdown()
        mediaSession?.release()
    }
}

