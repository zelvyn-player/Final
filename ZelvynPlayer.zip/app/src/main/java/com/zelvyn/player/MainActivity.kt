package com.zelvyn.player

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.audio.DeviceHardwareController
import com.zelvyn.player.audio.ZelvynAudioCaptureProcessor
import com.zelvyn.player.data.ExoPlayerTrackManager
import com.zelvyn.player.data.MediaStoreRepository
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.data.TranslationCoordinator
import com.zelvyn.player.model.*
import com.zelvyn.player.ui.home.HomeScreen
import com.zelvyn.player.ui.library.LibraryScreen
import com.zelvyn.player.ui.navigation.AppTab
import com.zelvyn.player.ui.navigation.ZelvynBottomNavBar
import com.zelvyn.player.ui.onboarding.OnboardingScreen
import com.zelvyn.player.ui.player.PlayerScreen
import com.zelvyn.player.ui.player.QueueSheet
import com.zelvyn.player.ui.player.SubtitleStyleScreen
import com.zelvyn.player.ui.privacy.PrivacyPolicyScreen
import com.zelvyn.player.ui.settings.SettingsScreen
import com.zelvyn.player.ui.theme.ZelvynTheme
import com.zelvyn.player.ui.translate.TranslateScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.*

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var exoPlayer: ExoPlayer
    private var mediaSession: MediaSession? = null
    private lateinit var mediaStoreRepository: MediaStoreRepository
    private lateinit var hardwareController: DeviceHardwareController
    private lateinit var prefsManager: PreferencesManager
    private lateinit var trackManager: ExoPlayerTrackManager
    private val audioDspManager = AudioDspManager()

    private var textToSpeech: TextToSpeech? = null
    private lateinit var translationCoordinator: TranslationCoordinator
    private lateinit var audioCaptureProcessor: ZelvynAudioCaptureProcessor

    private var activeVideoItem: VideoItem? = null
    private var isPipActive = mutableStateOf(false)

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefsManager = PreferencesManager(this, lifecycleScope)
        mediaStoreRepository = MediaStoreRepository(this)
        hardwareController = DeviceHardwareController(this)
        textToSpeech = TextToSpeech(this, this)

        translationCoordinator = TranslationCoordinator(
            scope = lifecycleScope,
            onVoiceOutputRequested = { text, targetLang ->
                val prefs = prefsManager.userPreferences.value
                if (prefs.translationMode == TranslationMode.VOICE || prefs.translationMode == TranslationMode.BOTH) {
                    textToSpeech?.let { tts ->
                        val loc = Locale.forLanguageTag(targetLang)
                        tts.language = loc
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ZelvynTTS")
                    }
                }
            }
        )

        audioCaptureProcessor = ZelvynAudioCaptureProcessor { pcmData, sampleRate, channels ->
            val userPrefs = prefsManager.userPreferences.value
            translationCoordinator.onAudioChunkCaptured(
                pcmData = pcmData,
                sampleRate = sampleRate,
                channels = channels,
                currentPlaybackPosMs = if (::exoPlayer.isInitialized) exoPlayer.currentPosition else 0L,
                apiKey = userPrefs.geminiApiKey
            )
        }

        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: android.content.Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(audioCaptureProcessor))
                    .build()
            }
        }

        exoPlayer = ExoPlayer.Builder(this, renderersFactory).build()
        trackManager = ExoPlayerTrackManager(exoPlayer)
        mediaSession = MediaSession.Builder(this, exoPlayer).build()

        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                audioDspManager.bindAudioSession(audioSessionId)
            }

            override fun onTracksChanged(tracks: Tracks) {
                trackManager.updateTracks(tracks)
            }

            override fun onPositionDiscontinuity(
                oldPosition: androidx.media3.common.Player.PositionInfo,
                newPosition: androidx.media3.common.Player.PositionInfo,
                reason: Int
            ) {
                if (reason == androidx.media3.common.Player.DISCONTINUITY_REASON_SEEK) {
                    translationCoordinator.onSeekInvalidate()
                    audioCaptureProcessor.flush()
                }
            }
        })

        lifecycleScope.launch {
            while (true) {
                if (::exoPlayer.isInitialized && exoPlayer.isPlaying) {
                    val pos = exoPlayer.currentPosition
                    translationCoordinator.onPlaybackPositionChanged(pos)
                    activeVideoItem?.let { video ->
                        prefsManager.saveVideoProgress(video.uri.toString(), pos)
                    }
                }
                delay(150)
            }
        }

        checkAndRequestMediaPermissions()

        setContent {
            ZelvynTheme {
                val userPrefs by prefsManager.userPreferences.collectAsState()
                var selectedTab by remember { mutableStateOf(AppTab.HOME) }
                var activeVideo by remember { mutableStateOf<VideoItem?>(null) }
                var videoList by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var folderList by remember { mutableStateOf<List<FolderItem>>(emptyList()) }
                var isViewingPrivacySubscreen by remember { mutableStateOf(false) }
                var isViewingSubtitleStyleSubscreen by remember { mutableStateOf(false) }

                val activeSegment by translationCoordinator.activeSegment.collectAsState()
                val translationStatus by translationCoordinator.status.collectAsState()
                val translationStatusMsg by translationCoordinator.statusMessage.collectAsState()
                val isTranslationActive by translationCoordinator.isTranslationActive.collectAsState()

                val hasPermission = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        android.Manifest.permission.READ_MEDIA_VIDEO
                    } else {
                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                ) == PackageManager.PERMISSION_GRANTED

                LaunchedEffect(hasPermission) {
                    if (hasPermission) {
                        val realVideos = mediaStoreRepository.getLocalVideos().map { item ->
                            val savedPos = prefsManager.getVideoProgress(item.uri.toString())
                            item.copy(lastPositionMs = savedPos)
                        }
                        videoList = realVideos
                        folderList = mediaStoreRepository.getFolders(realVideos)
                    }
                }

                if (!userPrefs.hasCompletedOnboarding) {
                    OnboardingScreen(onFinished = { prefsManager.updatePreferences { it.copy(hasCompletedOnboarding = true) } })
                } else if (activeVideo != null) {
                    PlayerScreen(
                        exoPlayer = exoPlayer,
                        video = activeVideo!!,
                        queue = videoList,
                        activeSegment = activeSegment,
                        translationStatus = translationStatus,
                        translationStatusMsg = translationStatusMsg,
                        isTranslationActive = isTranslationActive,
                        audioDspManager = audioDspManager,
                        hardwareController = hardwareController,
                        trackManager = trackManager,
                        prefsManager = prefsManager,
                        isPiPMode = isPipActive.value,
                        onEnterPiP = { enterPiP() },
                        onBackPress = {
                            exitPlayerMode()
                            activeVideo = null
                        },
                        onToggleLiveTranslation = {
                            if (isTranslationActive) {
                                audioCaptureProcessor.isCapturing = false
                                translationCoordinator.stopSession()
                            } else {
                                audioCaptureProcessor.isCapturing = true
                                translationCoordinator.startSession(
                                    source = userPrefs.sourceLang,
                                    target = userPrefs.defaultTargetLang,
                                    apiKey = userPrefs.geminiApiKey
                                )
                            }
                        },
                        onSelectQueueItem = { nextVideo ->
                            activeVideo = nextVideo
                            enterPlayerMode(nextVideo)
                        }
                    )
                } else {
                    Scaffold(
                        bottomBar = {
                            ZelvynBottomNavBar(
                                selectedTab = selectedTab,
                                onTabSelected = {
                                    isViewingPrivacySubscreen = false
                                    isViewingSubtitleStyleSubscreen = false
                                    selectedTab = it
                                }
                            )
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when {
                                isViewingPrivacySubscreen -> {
                                    PrivacyPolicyScreen(onBack = { isViewingPrivacySubscreen = false })
                                }
                                isViewingSubtitleStyleSubscreen -> {
                                    SubtitleStyleScreen(prefsManager = prefsManager, onBack = { isViewingSubtitleStyleSubscreen = false })
                                }
                                selectedTab == AppTab.HOME -> {
                                    HomeScreen(
                                        videos = videoList,
                                        folders = folderList,
                                        onVideoSelected = { video ->
                                            activeVideo = video
                                            activeVideoItem = video
                                            enterPlayerMode(video)
                                        },
                                        onSeeAllVideos = { selectedTab = AppTab.LIBRARY },
                                        onFolderSelected = { selectedTab = AppTab.LIBRARY },
                                        onOpenSearch = { selectedTab = AppTab.LIBRARY },
                                        onOpenSettings = { selectedTab = AppTab.MORE }
                                    )
                                }
                                selectedTab == AppTab.LIBRARY -> {
                                    LibraryScreen(
                                        videos = videoList,
                                        folders = folderList,
                                        hasStoragePermission = hasPermission,
                                        onVideoSelected = { video ->
                                            activeVideo = video
                                            activeVideoItem = video
                                            enterPlayerMode(video)
                                        },
                                        onFolderSelected = { }
                                    )
                                }
                                selectedTab == AppTab.TRANSLATE -> {
                                    TranslateScreen(
                                        translationCoordinator = translationCoordinator,
                                        prefsManager = prefsManager,
                                        onNavigateSubtitleStyle = { isViewingSubtitleStyleSubscreen = true },
                                        onNavigateSettings = { selectedTab = AppTab.MORE }
                                    )
                                }
                                selectedTab == AppTab.QUEUE -> {
                                    QueueSheet(
                                        queue = videoList,
                                        currentPlayingId = -1,
                                        onSelectQueueItem = { video ->
                                            activeVideo = video
                                            activeVideoItem = video
                                            enterPlayerMode(video)
                                        },
                                        onDismiss = { selectedTab = AppTab.HOME }
                                    )
                                }
                                selectedTab == AppTab.MORE -> {
                                    SettingsScreen(
                                        prefsManager = prefsManager,
                                        onNavigatePrivacy = { isViewingPrivacySubscreen = true },
                                        onNavigateSubtitleStyle = { isViewingSubtitleStyleSubscreen = true }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun enterPlayerMode(video: VideoItem) {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        hideSystemBars()
        exoPlayer.setMediaItem(MediaItem.fromUri(video.uri))
        exoPlayer.prepare()
        if (video.lastPositionMs > 2000L && video.lastPositionMs < video.durationMs - 5000L) {
            exoPlayer.seekTo(video.lastPositionMs)
        }
        exoPlayer.play()
    }

    private fun exitPlayerMode() {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        showSystemBars()
        exoPlayer.stop()
        audioCaptureProcessor.isCapturing = false
        translationCoordinator.stopSession()
        activeVideoItem = null
    }

    private fun enterPiP() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isPipActive.value = isInPictureInPictureMode
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (activeVideoItem != null && exoPlayer.isPlaying) enterPiP()
    }

    private fun checkAndRequestMediaPermissions() {
        val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            android.Manifest.permission.READ_MEDIA_VIDEO
        } else {
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(perm), 101)
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.language = Locale.ENGLISH
        }
    }

    override fun onResume() {
        super.onResume()
        if (::exoPlayer.isInitialized && !isPipActive.value) exoPlayer.play()
    }

    override fun onPause() {
        super.onPause()
        if (::exoPlayer.isInitialized && !isPipActive.value) exoPlayer.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        audioDspManager.release()
        textToSpeech?.shutdown()
        mediaSession?.release()
        if (::exoPlayer.isInitialized) exoPlayer.release()
    }
}
