package com.zelvyn.player

import android.app.PictureInPictureParams
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.util.Rational
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.session.MediaSession
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.audio.DeviceHardwareController
import com.zelvyn.player.audio.ZelvynAudioCaptureProcessor
import com.zelvyn.player.data.ExoPlayerTrackManager
import com.zelvyn.player.data.MediaStoreRepository
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.data.TranslationCoordinator
import com.zelvyn.player.model.*
import com.zelvyn.player.ui.home.HomeScreen
import com.zelvyn.player.ui.library.LibraryScreen
import com.zelvyn.player.ui.navigation.AppTab
import com.zelvyn.player.ui.navigation.ZelvynBottomNavBar
import com.zelvyn.player.ui.player.PlayerScreen
import com.zelvyn.player.ui.player.QueueSheet
import com.zelvyn.player.ui.player.SubtitleStyleScreen
import com.zelvyn.player.ui.privacy.PrivacyPolicyScreen
import com.zelvyn.player.ui.settings.AboutScreen
import com.zelvyn.player.ui.settings.SettingsScreen
import com.zelvyn.player.ui.theme.ZelvynTheme
import com.zelvyn.player.ui.translate.TranslateScreen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.*

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {

    private lateinit var exoPlayer: ExoPlayer
    private var mediaSession: MediaSession? = null
    private lateinit var mediaStoreRepository: MediaStoreRepository
    private lateinit var hardwareController: DeviceHardwareController
    private lateinit var prefsManager: PreferencesManager
    private lateinit var trackManager: ExoPlayerTrackManager
    private val audioDspManager = AudioDspManager()

    private var textToSpeech: TextToSpeech? = null
    private lateinit var translationCoordinator: TranslationCoordinator
    private lateinit var audioCaptureProcessor: ZelvynAudioCaptureProcessor

    private var activeVideoItem = mutableStateOf<VideoItem?>(null)
    private var isPipActive = mutableStateOf(false)

    private var queueRepeatMode = mutableStateOf(QueueRepeatMode.OFF)
    private var isQueueShuffleActive = mutableStateOf(false)
    private var activeQueueList = mutableStateListOf<VideoItem>()

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefsManager = PreferencesManager(this, lifecycleScope)
        mediaStoreRepository = MediaStoreRepository(this)
        hardwareController = DeviceHardwareController(this)
        textToSpeech = TextToSpeech(this, this)

        translationCoordinator = TranslationCoordinator(
            scope = lifecycleScope,
            onVoiceOutputRequested = { text, targetLang ->
                val prefs = prefsManager.userPreferences.value
                if (prefs.translationMode == TranslationMode.VOICE || prefs.translationMode == TranslationMode.BOTH) {
                    textToSpeech?.let { tts ->
                        val loc = Locale.forLanguageTag(targetLang)
                        tts.language = loc
                        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ZelvynTTS")
                    }
                }
            }
        )

        audioCaptureProcessor = ZelvynAudioCaptureProcessor { pcmData, sampleRate, channels ->
            val userPrefs = prefsManager.userPreferences.value
            translationCoordinator.onAudioChunkCaptured(
                pcmData = pcmData,
                sampleRate = sampleRate,
                channels = channels,
                currentPlaybackPosMs = if (::exoPlayer.isInitialized) exoPlayer.currentPosition else 0L,
                apiKey = userPrefs.geminiApiKey
            )
        }

        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: android.content.Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(audioCaptureProcessor))
                    .setEnableAudioTrackPlaybackParams(true)
                    .build()
            }
        }

        exoPlayer = ExoPlayer.Builder(this, renderersFactory).build().apply {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build()
            setAudioAttributes(audioAttributes, true)
        }

        trackManager = ExoPlayerTrackManager(exoPlayer)
        mediaSession = MediaSession.Builder(this, exoPlayer).build()

        exoPlayer.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                if (audioSessionId > 0) {
                    audioDspManager.bindAudioSession(audioSessionId)
                }
            }

            override fun onTracksChanged(tracks: Tracks) {
                trackManager.updateTracks(tracks)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    handleAutoPlayNext()
                }
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (reason == Player.DISCONTINUITY_REASON_SEEK) {
                    translationCoordinator.onSeekInvalidate()
                    audioCaptureProcessor.flush()
                }
            }
        })

        // Periodic light playback tracking (no disk thrashing)
        lifecycleScope.launch(Dispatchers.Main) {
            var loopCounter = 0
            while (true) {
                if (::exoPlayer.isInitialized && exoPlayer.isPlaying) {
                    val pos = exoPlayer.currentPosition
                    val offset = prefsManager.userPreferences.value.subtitleOffsetMs
                    translationCoordinator.onPlaybackPositionChanged(pos + offset)
                    loopCounter++
                    if (loopCounter >= 15) {
                        loopCounter = 0
                        activeVideoItem.value?.let { video ->
                            prefsManager.saveVideoProgress(video.uri.toString(), pos)
                        }
                    }
                }
                delay(200)
            }
        }

        checkAndRequestMediaPermissions()

        setContent {
            val userPrefs by prefsManager.userPreferences.collectAsState()

            ZelvynTheme(themeMode = userPrefs.themeMode) {
                var selectedTab by remember { mutableStateOf(AppTab.HOME) }
                var libraryCategory by remember { mutableStateOf("All") }
                var videoList by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var folderList by remember { mutableStateOf<List<FolderItem>>(emptyList()) }
                var isViewingPrivacySubscreen by remember { mutableStateOf(false) }
                var isViewingAboutSubscreen by remember { mutableStateOf(false) }
                var isViewingSubtitleStyleSubscreen by remember { mutableStateOf(false) }

                val activeSegment by translationCoordinator.activeSegment.collectAsState()
                val translationStatus by translationCoordinator.status.collectAsState()
                val translationStatusMsg by translationCoordinator.statusMessage.collectAsState()
                val isTranslationActive by translationCoordinator.isTranslationActive.collectAsState()

                val hasPermission = ContextCompat.checkSelfPermission(
                    this@MainActivity,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        android.Manifest.permission.READ_MEDIA_VIDEO
                    } else {
                        android.Manifest.permission.READ_EXTERNAL_STORAGE
                    }
                ) == PackageManager.PERMISSION_GRANTED

                fun loadLibrary() {
                    lifecycleScope.launch {
                        if (hasPermission) {
                            val realVideos = mediaStoreRepository.getLocalVideos().map { item ->
                                val savedPos = prefsManager.getVideoProgress(item.uri.toString())
                                item.copy(lastPositionMs = savedPos)
                            }
                            videoList = realVideos
                            folderList = mediaStoreRepository.getFolders(realVideos)
                            activeQueueList.clear()
                            activeQueueList.addAll(realVideos)
                        }
                    }
                }

                LaunchedEffect(hasPermission, activeVideoItem.value) {
                    loadLibrary()
                }

                if (activeVideoItem.value != null) {
                    PlayerScreen(
                        exoPlayer = exoPlayer,
                        video = activeVideoItem.value!!,
                        queue = activeQueueList,
                        activeSegment = activeSegment,
                        translationStatus = translationStatus,
                        translationStatusMsg = translationStatusMsg,
                        isTranslationActive = isTranslationActive,
                        audioDspManager = audioDspManager,
                        hardwareController = hardwareController,
                        trackManager = trackManager,
                        prefsManager = prefsManager,
                        isPiPMode = isPipActive.value,
                        repeatMode = queueRepeatMode.value,
                        isShuffleActive = isQueueShuffleActive.value,
                        onToggleRepeat = {
                            queueRepeatMode.value = when (queueRepeatMode.value) {
                                QueueRepeatMode.OFF -> QueueRepeatMode.ALL
                                QueueRepeatMode.ALL -> QueueRepeatMode.ONE
                                QueueRepeatMode.ONE -> QueueRepeatMode.OFF
                            }
                        },
                        onToggleShuffle = {
                            isQueueShuffleActive.value = !isQueueShuffleActive.value
                        },
                        onToggleOrientation = { toggleOrientation() },
                        onEnterPiP = { enterPiP() },
                        onBackPress = { exitPlayerMode() },
                        onToggleLiveTranslation = {
                            if (isTranslationActive) {
                                audioCaptureProcessor.isCapturing = false
                                translationCoordinator.stopSession()
                            } else {
                                audioCaptureProcessor.isCapturing = true
                                translationCoordinator.startSession(
                                    source = userPrefs.sourceLang,
                                    target = userPrefs.defaultTargetLang,
                                    apiKey = userPrefs.geminiApiKey
                                )
                            }
                        },
                        onSelectQueueItem = { nextVideo -> enterPlayerMode(nextVideo) },
                        onNavigateSubtitleStyle = { isViewingSubtitleStyleSubscreen = true }
                    )
                } else {
                    Scaffold(
                        bottomBar = {
                            ZelvynBottomNavBar(
                                selectedTab = selectedTab,
                                onTabSelected = {
                                    isViewingPrivacySubscreen = false
                                    isViewingAboutSubscreen = false
                                    isViewingSubtitleStyleSubscreen = false
                                    selectedTab = it
                                }
                            )
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when {
                                isViewingAboutSubscreen -> {
                                    AboutScreen(onBack = { isViewingAboutSubscreen = false })
                                }
                                isViewingPrivacySubscreen -> {
                                    PrivacyPolicyScreen(onBack = { isViewingPrivacySubscreen = false })
                                }
                                isViewingSubtitleStyleSubscreen -> {
                                    SubtitleStyleScreen(prefsManager = prefsManager, onBack = { isViewingSubtitleStyleSubscreen = false })
                                }
                                selectedTab == AppTab.HOME -> {
                                    HomeScreen(
                                        videos = videoList,
                                        folders = folderList,
                                        onVideoSelected = { video -> enterPlayerMode(video) },
                                        onSeeAllVideos = {
                                            libraryCategory = "All"
                                            selectedTab = AppTab.LIBRARY
                                        },
                                        onOpenContinueWatching = {
                                            libraryCategory = "Continue Watching"
                                            selectedTab = AppTab.LIBRARY
                                        },
                                        onFolderSelected = {
                                            libraryCategory = "Folders"
                                            selectedTab = AppTab.LIBRARY
                                        },
                                        onOpenSearch = { selectedTab = AppTab.LIBRARY },
                                        onOpenSettings = { selectedTab = AppTab.MORE }
                                    )
                                }
                                selectedTab == AppTab.LIBRARY -> {
                                    LibraryScreen(
                                        videos = videoList,
                                        folders = folderList,
                                        hasStoragePermission = hasPermission,
                                        initialCategory = libraryCategory,
                                        layoutMode = userPrefs.libraryLayoutMode,
                                        onToggleLayoutMode = {
                                            val next = if (userPrefs.libraryLayoutMode == LibraryLayoutMode.GRID) LibraryLayoutMode.LIST else LibraryLayoutMode.GRID
                                            prefsManager.updatePreferences { it.copy(libraryLayoutMode = next) }
                                        },
                                        onVideoSelected = { video -> enterPlayerMode(video) },
                                        onFolderSelected = { }
                                    )
                                }
                                selectedTab == AppTab.TRANSLATE -> {
                                    TranslateScreen(
                                        translationCoordinator = translationCoordinator,
                                        prefsManager = prefsManager,
                                        onNavigateSubtitleStyle = { isViewingSubtitleStyleSubscreen = true },
                                        onNavigateSettings = { selectedTab = AppTab.MORE }
                                    )
                                }
                                selectedTab == AppTab.QUEUE -> {
                                    QueueSheet(
                                        queue = activeQueueList,
                                        currentPlayingId = activeVideoItem.value?.id ?: -1L,
                                        repeatMode = queueRepeatMode.value,
                                        isShuffleActive = isQueueShuffleActive.value,
                                        onToggleRepeat = {
                                            queueRepeatMode.value = when (queueRepeatMode.value) {
                                                QueueRepeatMode.OFF -> QueueRepeatMode.ALL
                                                QueueRepeatMode.ALL -> QueueRepeatMode.ONE
                                                QueueRepeatMode.ONE -> QueueRepeatMode.OFF
                                            }
                                        },
                                        onToggleShuffle = {
                                            isQueueShuffleActive.value = !isQueueShuffleActive.value
                                        },
                                        onSelectQueueItem = { video -> enterPlayerMode(video) },
                                        onDismiss = { selectedTab = AppTab.HOME }
                                    )
                                }
                                selectedTab == AppTab.MORE -> {
                                    SettingsScreen(
                                        prefsManager = prefsManager,
                                        onForceRescan = {
                                            loadLibrary()
                                            Toast.makeText(this@MainActivity, "Media library re-scanned.", Toast.LENGTH_SHORT).show()
                                        },
                                        onNavigateAbout = { isViewingAboutSubscreen = true },
                                        onNavigatePrivacy = { isViewingPrivacySubscreen = true },
                                        onNavigateSubtitleStyle = { isViewingSubtitleStyleSubscreen = true }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun handleAutoPlayNext() {
        if (queueRepeatMode.value == QueueRepeatMode.ONE) {
            exoPlayer.seekTo(0L)
            exoPlayer.play()
            return
        }

        val current = activeVideoItem.value ?: return
        val queue = activeQueueList
        val currentIndex = queue.indexOfFirst { it.id == current.id }
        if (currentIndex != -1) {
            val nextIndex = if (isQueueShuffleActive.value) {
                queue.indices.random()
            } else {
                currentIndex + 1
            }

            if (nextIndex in queue.indices) {
                enterPlayerMode(queue[nextIndex])
            } else if (queueRepeatMode.value == QueueRepeatMode.ALL && queue.isNotEmpty()) {
                enterPlayerMode(queue[0])
            }
        }
    }

    private fun enterPlayerMode(video: VideoItem) {
        activeVideoItem.value = video
        // Open in device's current orientation (portrait if held vertically, landscape if held horizontally)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER
        hideSystemBars()
        exoPlayer.setMediaItem(MediaItem.fromUri(video.uri))
        exoPlayer.prepare()
        if (video.lastPositionMs > 2000L && video.lastPositionMs < video.durationMs - 5000L) {
            exoPlayer.seekTo(video.lastPositionMs)
        }
        exoPlayer.play()
    }

    private fun exitPlayerMode() {
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_USER
        showSystemBars()
        if (::exoPlayer.isInitialized) {
            activeVideoItem.value?.let { video ->
                prefsManager.saveVideoProgress(video.uri.toString(), exoPlayer.currentPosition)
            }
            exoPlayer.stop()
        }
        audioCaptureProcessor.isCapturing = false
        translationCoordinator.stopSession()
        activeVideoItem.value = null
    }

    private fun toggleOrientation() {
        requestedOrientation = if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
        } else {
            ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        }
    }

    private fun enterPiP() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
        isPipActive.value = isInPictureInPictureMode
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (activeVideoItem.value != null && exoPlayer.isPlaying) enterPiP()
    }

    private fun checkAndRequestMediaPermissions() {
        val perm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            android.Manifest.permission.READ_MEDIA_VIDEO
        } else {
            android.Manifest.permission.READ_EXTERNAL_STORAGE
        }
        if (ContextCompat.checkSelfPermission(this, perm) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(perm), 101)
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            textToSpeech?.language = Locale.ENGLISH
        }
    }

    override fun onResume() {
        super.onResume()
        if (::exoPlayer.isInitialized && !isPipActive.value && activeVideoItem.value != null) {
            exoPlayer.play()
        }
    }

    override fun onPause() {
        super.onPause()
        if (::exoPlayer.isInitialized) {
            activeVideoItem.value?.let { video ->
                prefsManager.saveVideoProgress(video.uri.toString(), exoPlayer.currentPosition)
            }
            if (!isPipActive.value) {
                exoPlayer.pause()
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::exoPlayer.isInitialized) {
            activeVideoItem.value?.let { video ->
                prefsManager.saveVideoProgress(video.uri.toString(), exoPlayer.currentPosition)
            }
            exoPlayer.release()
        }
        audioDspManager.release()
        textToSpeech?.shutdown()
        mediaSession?.release()
    }
}
