package com.zelvyn.player.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

val ZelvynLightColorScheme = lightColorScheme(
    primary = BrandAccent,
    secondary = TextSecondaryLight,
    tertiary = TextTertiaryLight,
    background = CanvasLight,
    surface = CardSurfaceLight,
    surfaceVariant = SurfaceElevatedLight,
    onPrimary = CardSurfaceLight,
    onSecondary = TextPrimaryLight,
    onBackground = TextPrimaryLight,
    onSurface = TextPrimaryLight
)

val ZelvynDarkColorScheme = darkColorScheme(
    primary = BrandAccent,
    secondary = TextSecondaryDark,
    tertiary = TextTertiaryDark,
    background = CanvasDark,
    surface = CardSurfaceDark,
    surfaceVariant = SurfaceElevatedDark,
    onPrimary = CardSurfaceLight,
    onSecondary = TextPrimaryDark,
    onBackground = TextPrimaryDark,
    onSurface = TextPrimaryDark
)

@Composable
fun ZelvynTheme(
    themeMode: String = "System", // "System", "Light", "Dark"
    content: @Composable () -> Unit
) {
    val isDark = when (themeMode) {
        "Light" -> false
        "Dark" -> true
        else -> isSystemInDarkTheme()
    }

    MaterialTheme(
        colorScheme = if (isDark) ZelvynDarkColorScheme else ZelvynLightColorScheme,
        content = content
    )
}
