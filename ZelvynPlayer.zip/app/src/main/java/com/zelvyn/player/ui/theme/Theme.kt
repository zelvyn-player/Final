package com.zelvyn.player.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun ZelvynTheme(
    themeMode: String = "Dark",
    accentColorHex: String = "Orange",
    content: @Composable () -> Unit
) {
    val brandAccent = when (accentColorHex) {
        "Blue" -> AccentBlue
        "Purple" -> AccentPurple
        "Green" -> AccentGreen
        "Red" -> AccentRed
        else -> AccentOrangeCopper
    }

    val isDark = when (themeMode) {
        "Light" -> false
        "Dark", "Deep Black" -> true
        else -> isSystemInDarkTheme()
    }

    val canvasColor = if (themeMode == "Deep Black") Color(0xFF000000) else if (isDark) ZelvynCanvasDark else ZelvynCanvasLight
    val cardColor = if (themeMode == "Deep Black") Color(0xFF0D0D10) else if (isDark) ZelvynCardSurfaceDark else ZelvynCardSurfaceLight
    val surfaceVarColor = if (themeMode == "Deep Black") Color(0xFF141318) else if (isDark) ZelvynSurfaceElevatedDark else ZelvynSurfaceElevatedLight

    val colorScheme = if (isDark) {
        darkColorScheme(
            primary = brandAccent,
            secondary = TextSecondaryDark,
            tertiary = TextTertiaryDark,
            background = canvasColor,
            surface = cardColor,
            surfaceVariant = surfaceVarColor,
            outline = ZelvynBorderDark,
            onPrimary = Color.White,
            onSecondary = TextPrimaryDark,
            onBackground = TextPrimaryDark,
            onSurface = TextPrimaryDark
        )
    } else {
        lightColorScheme(
            primary = brandAccent,
            secondary = TextSecondaryLight,
            tertiary = TextTertiaryLight,
            background = canvasColor,
            surface = cardColor,
            surfaceVariant = surfaceVarColor,
            outline = ZelvynBorderLight,
            onPrimary = Color.White,
            onSecondary = TextPrimaryLight,
            onBackground = TextPrimaryLight,
            onSurface = TextPrimaryLight
        )
    }

    MaterialTheme(
        colorScheme = colorScheme,
        content = content
    )
}