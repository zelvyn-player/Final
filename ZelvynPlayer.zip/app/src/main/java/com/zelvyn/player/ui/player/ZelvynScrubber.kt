package com.zelvyn.player.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.ui.theme.*

@Composable fun ZelvynScrubber( currentPos: Long, duration: Long, bufferedPos:
Long, onSeek: (Long) -> Unit, modifier: Modifier = Modifier ) { var isDragging
by remember { mutableStateOf(false) } var dragProgress by remember {
mutableFloatStateOf(0f) } var componentSize by remember {
mutableStateOf(IntSize.Zero) }

val safeDuration = duration.coerceAtLeast(1L)
val currentFrac = if (isDragging) dragProgress else (currentPos.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
val bufferedFrac = (bufferedPos.toFloat() / safeDuration.toFloat()).coerceIn(0f, 1f)
val previewTimeMs = (currentFrac * safeDuration).toLong()

Box(
    modifier = modifier
        .fillMaxWidth()
        .height(48.dp)
        .onSizeChanged { componentSize = it }
        .pointerInput(safeDuration) {
            detectTapGestures { offset ->
                val width = componentSize.width
                if (width > 0) {
                    val frac = (offset.x / width).coerceIn(0f, 1f)
                    onSeek((frac * safeDuration).toLong())
                }
            }
        }
        .pointerInput(safeDuration) {
            detectHorizontalDragGestures(
                onDragStart = { offset ->
                    isDragging = true
                    val width = componentSize.width
                    if (width > 0) {
                        dragProgress = (offset.x / width).coerceIn(0f, 1f)
                    }
                },
                onDragEnd = {
                    isDragging = false
                    onSeek((dragProgress * safeDuration).toLong())
                },
                onDragCancel = {
                    isDragging = false
                },
                onHorizontalDrag = { change, _ ->
                    change.consume()
                    val width = componentSize.width
                    if (width > 0) {
                        dragProgress = (change.position.x / width).coerceIn(0f, 1f)
                    }
                }
            )
        },
    contentAlignment = Alignment.CenterStart
) {
    if (isDragging) {
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .offset(x = ((currentFrac * (componentSize.width - 160)).coerceAtLeast(0f) / 2.7f).dp, y = (-12).dp)
                .clip(RoundedCornerShape(8.dp))
                .background(CardSurfaceDark)
                .border(1.dp, BrandAccent, RoundedCornerShape(8.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            Text(
                text = formatTime(previewTimeMs),
                color = BrandAccent,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .height(if (isDragging) 6.dp else 4.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(BorderSubtleDark)
    )

    Box(
        modifier = Modifier
            .fillMaxWidth(bufferedFrac)
            .height(if (isDragging) 6.dp else 4.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(Color.White.copy(alpha = 0.28f))
    )

    Box(
        modifier = Modifier
            .fillMaxWidth(currentFrac)
            .height(if (isDragging) 6.dp else 4.dp)
            .clip(RoundedCornerShape(3.dp))
            .background(BrandAccent)
    )

    val thumbOffset = if (componentSize.width > 0) (currentFrac * (componentSize.width - 32)) else 0f
    Box(
        modifier = Modifier
            .offset(x = (thumbOffset / 2.7f).dp)
            .size(if (isDragging) 18.dp else 14.dp)
            .shadow(elevation = 6.dp, shape = CircleShape)
            .clip(CircleShape)
            .background(CardSurfaceLight)
            .border(2.5.dp, BrandAccent, CircleShape)
    )
}

}
