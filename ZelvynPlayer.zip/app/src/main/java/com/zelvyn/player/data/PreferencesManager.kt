package com.zelvyn.player.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.zelvyn.player.model.UserPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.dataStore by preferencesDataStore(name = "zelvyn_secure_prefs")

class PreferencesManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val KEY_ENCRYPTED_API = stringPreferencesKey("enc_gemini_api_key")
    private val KEY_DEFAULT_TARGET_LANG = stringPreferencesKey("default_target_lang")
    private val KEY_SUBTITLE_FONT_SIZE = intPreferencesKey("subtitle_font_size")
    private val KEY_SUBTITLE_BG_ALPHA = floatPreferencesKey("subtitle_bg_alpha")
    private val KEY_ONBOARDING_COMPLETED = booleanPreferencesKey("has_completed_onboarding")

    private val _userPreferences = MutableStateFlow(UserPreferences())
    val userPreferences: StateFlow<UserPreferences> = _userPreferences.asStateFlow()

    private val KEY_ALIAS = "zelvyn_gemini_master_key"
    private val ANDROID_KEYSTORE = "AndroidKeyStore"
    private val TRANSFORMATION = "AES/GCM/NoPadding"

    init {
        scope.launch(Dispatchers.IO) {
            context.dataStore.data.collectLatest { prefs ->
                val encryptedKey = prefs[KEY_ENCRYPTED_API] ?: ""
                val decryptedKey = decrypt(encryptedKey)

                _userPreferences.value = UserPreferences(
                    geminiApiKey = decryptedKey,
                    defaultTargetLang = prefs[KEY_DEFAULT_TARGET_LANG] ?: "Spanish",
                    subtitleFontSizeSp = prefs[KEY_SUBTITLE_FONT_SIZE] ?: 15,
                    subtitleBackgroundAlpha = prefs[KEY_SUBTITLE_BG_ALPHA] ?: 0.88f,
                    hasCompletedOnboarding = prefs[KEY_ONBOARDING_COMPLETED] ?: false
                )
            }
        }
    }

    fun setGeminiApiKey(key: String) {
        scope.launch(Dispatchers.IO) {
            val encrypted = encrypt(key.trim())
            context.dataStore.edit { it[KEY_ENCRYPTED_API] = encrypted }
        }
    }

    fun setDefaultTargetLang(lang: String) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { it[KEY_DEFAULT_TARGET_LANG] = lang }
        }
    }

    fun setSubtitleFontSize(sizeSp: Int) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { it[KEY_SUBTITLE_FONT_SIZE] = sizeSp }
        }
    }

    fun setSubtitleBackgroundAlpha(alpha: Float) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { it[KEY_SUBTITLE_BG_ALPHA] = alpha }
        }
    }

    fun setOnboardingCompleted(completed: Boolean) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { it[KEY_ONBOARDING_COMPLETED] = completed }
        }
    }

    fun saveVideoProgress(videoId: Long, positionMs: Long) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { it[longPreferencesKey("pos_$videoId")] = positionMs }
        }
    }

    suspend fun getVideoProgress(videoId: Long): Long {
        var pos = 0L
        context.dataStore.edit { prefs ->
            pos = prefs[longPreferencesKey("pos_$videoId")] ?: 0L
        }
        return pos
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (keyStore.containsAlias(KEY_ALIAS)) {
            val entry = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
            if (entry != null) return entry.secretKey
        }

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    private fun encrypt(plainText: String): String {
        if (plainText.isBlank()) return ""
        return try {
            val secretKey = getOrCreateSecretKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val iv = cipher.iv
            val cipherBytes = cipher.doFinal(plainText.toByteArray(StandardCharsets.UTF_8))
            val combined = ByteArray(iv.size + cipherBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(cipherBytes, 0, combined, iv.size, cipherBytes.size)
            Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    private fun decrypt(cipherText: String): String {
        if (cipherText.isBlank()) return ""
        return try {
            val combined = Base64.decode(cipherText, Base64.NO_WRAP)
            if (combined.size < 12) return ""
            val secretKey = getOrCreateSecretKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val gcmSpec = GCMParameterSpec(128, combined, 0, 12)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)
            val decryptedBytes = cipher.doFinal(combined, 12, combined.size - 12)
            String(decryptedBytes, StandardCharsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}
