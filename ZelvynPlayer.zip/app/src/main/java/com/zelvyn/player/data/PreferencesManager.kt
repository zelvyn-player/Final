
package com.zelvyn.player.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import com.zelvyn.player.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.nio.charset.StandardCharsets
import java.security.KeyStore
import java.util.concurrent.ConcurrentHashMap
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.dataStore by preferencesDataStore(name = "zelvyn_secure_prefs")

data class VideoProgressRecord(
    val positionMs: Long,
    val lastWatchedTimeMs: Long
)

class PreferencesManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val KEY_ENCRYPTED_API = stringPreferencesKey("enc_gemini_api_key")
    private val KEY_SOURCE_LANG = stringPreferencesKey("source_lang")
    private val KEY_TARGET_LANG = stringPreferencesKey("default_target_lang")
    private val KEY_TRANSLATION_MODE = stringPreferencesKey("translation_mode")
    private val KEY_VOICE_STYLE = stringPreferencesKey("voice_style")
    private val KEY_AI_MODEL_NAME = stringPreferencesKey("ai_model_name")
    private val KEY_ORIG_VOLUME = intPreferencesKey("orig_volume")
    private val KEY_TRANS_VOLUME = intPreferencesKey("trans_volume")
    private val KEY_SUBTITLE_FONT_SIZE = intPreferencesKey("subtitle_font_size")
    private val KEY_SUBTITLE_COLOR = longPreferencesKey("subtitle_color")
    private val KEY_SUBTITLE_BG_MODE = stringPreferencesKey("subtitle_bg_mode")
    private val KEY_SUBTITLE_BG_ALPHA = floatPreferencesKey("subtitle_bg_alpha")
    private val KEY_SUBTITLE_POSITION = stringPreferencesKey("subtitle_position")
    private val KEY_SUBTITLE_FONT_FAMILY = stringPreferencesKey("subtitle_font_family")
    private val KEY_SUBTITLE_BOLD = booleanPreferencesKey("subtitle_bold")
    private val KEY_SUBTITLE_ENCODING = stringPreferencesKey("subtitle_encoding")
    private val KEY_SUBTITLE_OFFSET = longPreferencesKey("subtitle_offset_ms")
    private val KEY_SKIP_INTERVAL = intPreferencesKey("skip_interval")
    private val KEY_REMEMBER_POS = booleanPreferencesKey("remember_pos")
    private val KEY_REMEMBER_SPEED = booleanPreferencesKey("remember_speed")
    private val KEY_LAST_SPEED = floatPreferencesKey("last_playback_speed")
    private val KEY_RESUME_LAUNCH = booleanPreferencesKey("resume_launch")
    private val KEY_BG_PLAYBACK = booleanPreferencesKey("bg_playback")
    private val KEY_PIP = booleanPreferencesKey("pip_enabled")
    private val KEY_THEME_MODE = stringPreferencesKey("theme_mode")
    private val KEY_ACCENT_COLOR = stringPreferencesKey("accent_color")
    private val KEY_LIBRARY_LAYOUT = stringPreferencesKey("library_layout_mode")
    private val KEY_GESTURE_SENSITIVITY = floatPreferencesKey("gesture_sensitivity")
    private val KEY_ONBOARDING_COMPLETED = booleanPreferencesKey("has_completed_onboarding")
    private val KEY_FAVORITES = stringSetPreferencesKey("favorite_video_uris")
    private val KEY_WATCH_PROGRESS_MAP = stringPreferencesKey("watch_progress_json_map")

    private val _userPreferences = MutableStateFlow(UserPreferences())
    val userPreferences: StateFlow<UserPreferences> = _userPreferences.asStateFlow()

    private val _favoriteUris = MutableStateFlow<Set<String>>(emptySet())
    val favoriteUris: StateFlow<Set<String>> = _favoriteUris.asStateFlow()

    private val progressCache = ConcurrentHashMap<String, VideoProgressRecord>()

    private val KEY_ALIAS = "zelvyn_gemini_master_key"
    private val ANDROID_KEYSTORE = "AndroidKeyStore"
    private val TRANSFORMATION = "AES/GCM/NoPadding"

    init {
        scope.launch(Dispatchers.IO) {
            context.dataStore.data.collectLatest { prefs ->
                val encryptedKey = prefs[KEY_ENCRYPTED_API] ?: ""
                val decryptedKey = decrypt(encryptedKey)

                val progressJsonStr = prefs[KEY_WATCH_PROGRESS_MAP] ?: "{}"
                parseProgressJson(progressJsonStr)

                _userPreferences.value = UserPreferences(
                    geminiApiKey = decryptedKey,
                    sourceLang = prefs[KEY_SOURCE_LANG] ?: "Auto Detect",
                    defaultTargetLang = prefs[KEY_TARGET_LANG] ?: "English",
                    translationMode = TranslationMode.valueOf(
                        prefs[KEY_TRANSLATION_MODE] ?: TranslationMode.BOTH.name
                    ),
                    voiceStyle = VoiceStyle.valueOf(
                        prefs[KEY_VOICE_STYLE] ?: VoiceStyle.NATURAL.name
                    ),
                    aiModelName = prefs[KEY_AI_MODEL_NAME] ?: "ZELVYN AI Pro",
                    originalVolumePercent = prefs[KEY_ORIG_VOLUME] ?: 40,
                    translatedVolumePercent = prefs[KEY_TRANS_VOLUME] ?: 100,
                    subtitleFontSizeSp = prefs[KEY_SUBTITLE_FONT_SIZE] ?: 16,
                    subtitleColorArgb = prefs[KEY_SUBTITLE_COLOR] ?: 0xFFFFFFFF,
                    subtitleBgMode = SubtitleBgMode.valueOf(
                        prefs[KEY_SUBTITLE_BG_MODE] ?: SubtitleBgMode.SOLID.name
                    ),
                    subtitleBackgroundAlpha = prefs[KEY_SUBTITLE_BG_ALPHA] ?: 0.75f,
                    subtitlePosition = prefs[KEY_SUBTITLE_POSITION] ?: "Bottom",
                    subtitleFontFamily = SubtitleFontFamily.valueOf(
                        prefs[KEY_SUBTITLE_FONT_FAMILY] ?: SubtitleFontFamily.SANS_SERIF.name
                    ),
                    subtitleBold = prefs[KEY_SUBTITLE_BOLD] ?: true,
                    subtitleEncoding = prefs[KEY_SUBTITLE_ENCODING] ?: "UTF-8",
                    subtitleOffsetMs = prefs[KEY_SUBTITLE_OFFSET] ?: 0L,
                    skipIntervalSeconds = prefs[KEY_SKIP_INTERVAL] ?: 10,
                    rememberLastPosition = prefs[KEY_REMEMBER_POS] ?: true,
                    rememberLastSpeed = prefs[KEY_REMEMBER_SPEED] ?: true,
                    lastPlaybackSpeed = prefs[KEY_LAST_SPEED] ?: 1.0f,
                    resumeOnAppLaunch = prefs[KEY_RESUME_LAUNCH] ?: true,
                    backgroundPlayback = prefs[KEY_BG_PLAYBACK] ?: true,
                    pipEnabled = prefs[KEY_PIP] ?: true,
                    themeMode = prefs[KEY_THEME_MODE] ?: "Dark",
                    accentColor = prefs[KEY_ACCENT_COLOR] ?: "Orange",
                    libraryLayoutMode = LibraryLayoutMode.valueOf(
                        prefs[KEY_LIBRARY_LAYOUT] ?: LibraryLayoutMode.LIST.name
                    ),
                    gestureSensitivity = prefs[KEY_GESTURE_SENSITIVITY] ?: 1.0f,
                    hasCompletedOnboarding = prefs[KEY_ONBOARDING_COMPLETED] ?: true
                )
                _favoriteUris.value = prefs[KEY_FAVORITES] ?: emptySet()
            }
        }
    }

    private fun parseProgressJson(jsonStr: String) {
        try {
            val root = JSONObject(jsonStr)
            val keys = root.keys()
            while (keys.hasNext()) {
                val uri = keys.next()
                val obj = root.optJSONObject(uri)
                if (obj != null) {
                    val pos = obj.optLong("pos", 0L)
                    val time = obj.optLong("time", 0L)
                    progressCache[uri] = VideoProgressRecord(pos, time)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun updatePreferences(transform: (UserPreferences) -> UserPreferences) {
        val updated = transform(_userPreferences.value)
        _userPreferences.value = updated
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { prefs ->
                if (updated.geminiApiKey.isNotBlank()) {
                    prefs[KEY_ENCRYPTED_API] = encrypt(updated.geminiApiKey.trim())
                }
                prefs[KEY_SOURCE_LANG] = updated.sourceLang
                prefs[KEY_TARGET_LANG] = updated.defaultTargetLang
                prefs[KEY_TRANSLATION_MODE] = updated.translationMode.name
                prefs[KEY_VOICE_STYLE] = updated.voiceStyle.name
                prefs[KEY_AI_MODEL_NAME] = updated.aiModelName
                prefs[KEY_ORIG_VOLUME] = updated.originalVolumePercent
                prefs[KEY_TRANS_VOLUME] = updated.translatedVolumePercent
                prefs[KEY_SUBTITLE_FONT_SIZE] = updated.subtitleFontSizeSp
                prefs[KEY_SUBTITLE_COLOR] = updated.subtitleColorArgb
                prefs[KEY_SUBTITLE_BG_MODE] = updated.subtitleBgMode.name
                prefs[KEY_SUBTITLE_BG_ALPHA] = updated.subtitleBackgroundAlpha
                prefs[KEY_SUBTITLE_POSITION] = updated.subtitlePosition
                prefs[KEY_SUBTITLE_FONT_FAMILY] = updated.subtitleFontFamily.name
                prefs[KEY_SUBTITLE_BOLD] = updated.subtitleBold
                prefs[KEY_SUBTITLE_ENCODING] = updated.subtitleEncoding
                prefs[KEY_SUBTITLE_OFFSET] = updated.subtitleOffsetMs
                prefs[KEY_SKIP_INTERVAL] = updated.skipIntervalSeconds
                prefs[KEY_REMEMBER_POS] = updated.rememberLastPosition
                prefs[KEY_REMEMBER_SPEED] = updated.rememberLastSpeed
                prefs[KEY_LAST_SPEED] = updated.lastPlaybackSpeed
                prefs[KEY_RESUME_LAUNCH] = updated.resumeOnAppLaunch
                prefs[KEY_BG_PLAYBACK] = updated.backgroundPlayback
                prefs[KEY_PIP] = updated.pipEnabled
                prefs[KEY_THEME_MODE] = updated.themeMode
                prefs[KEY_ACCENT_COLOR] = updated.accentColor
                prefs[KEY_LIBRARY_LAYOUT] = updated.libraryLayoutMode.name
                prefs[KEY_GESTURE_SENSITIVITY] = updated.gestureSensitivity
                prefs[KEY_ONBOARDING_COMPLETED] = updated.hasCompletedOnboarding
            }
        }
    }

    fun resetPlaybackDefaults() {
        updatePreferences { current ->
            current.copy(
                skipIntervalSeconds = 10,
                rememberLastPosition = true,
                rememberLastSpeed = true,
                lastPlaybackSpeed = 1.0f,
                resumeOnAppLaunch = true,
                backgroundPlayback = true,
                pipEnabled = true,
                originalVolumePercent = 40,
                translatedVolumePercent = 100,
                subtitleFontSizeSp = 16,
                subtitleColorArgb = 0xFFFFFFFF,
                subtitleBgMode = SubtitleBgMode.SOLID,
                subtitleBackgroundAlpha = 0.75f,
                subtitlePosition = "Bottom",
                subtitleFontFamily = SubtitleFontFamily.SANS_SERIF,
                subtitleBold = true,
                subtitleEncoding = "UTF-8",
                subtitleOffsetMs = 0L,
                gestureSensitivity = 1.0f
            )
        }
    }

    fun toggleFavorite(videoUri: String) {
        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { prefs ->
                val current = (prefs[KEY_FAVORITES] ?: emptySet()).toMutableSet()
                if (current.contains(videoUri)) {
                    current.remove(videoUri)
                } else {
                    current.add(videoUri)
                }
                prefs[KEY_FAVORITES] = current
                _favoriteUris.value = current
            }
        }
    }

    fun saveVideoProgress(uriString: String, positionMs: Long, timestampMs: Long = System.currentTimeMillis()) {
        val existing = progressCache[uriString]
        if (existing != null && Math.abs(positionMs - existing.positionMs) < 2000L && positionMs > 0) return

        val record = VideoProgressRecord(positionMs, timestampMs)
        progressCache[uriString] = record

        scope.launch(Dispatchers.IO) {
            context.dataStore.edit { prefs ->
                val root = JSONObject(prefs[KEY_WATCH_PROGRESS_MAP] ?: "{}")
                val itemObj = JSONObject()
                itemObj.put("pos", positionMs)
                itemObj.put("time", timestampMs)
                root.put(uriString, itemObj)
                prefs[KEY_WATCH_PROGRESS_MAP] = root.toString()
            }
        }
    }

    suspend fun getAllProgressRecords(): Map<String, VideoProgressRecord> {
        if (progressCache.isNotEmpty()) {
            return progressCache.toMap()
        }
        val prefs = context.dataStore.data.first()
        val jsonStr = prefs[KEY_WATCH_PROGRESS_MAP] ?: "{}"
        parseProgressJson(jsonStr)
        return progressCache.toMap()
    }

    fun getProgressRecord(uriString: String): VideoProgressRecord? {
        return progressCache[uriString]
    }

    private fun getOrCreateSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (keyStore.containsAlias(KEY_ALIAS)) {
            val entry = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
            if (entry != null) return entry.secretKey
        }

        val keyGenerator = KeyGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_AES,
            ANDROID_KEYSTORE
        )
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    private fun encrypt(plainText: String): String {
        if (plainText.isBlank()) return ""
        return try {
            val secretKey = getOrCreateSecretKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val iv = cipher.iv
            val cipherBytes = cipher.doFinal(
                plainText.toByteArray(StandardCharsets.UTF_8)
            )
            val combined = ByteArray(iv.size + cipherBytes.size)
            System.arraycopy(iv, 0, combined, 0, iv.size)
            System.arraycopy(cipherBytes, 0, combined, iv.size, cipherBytes.size)
            Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (e: Exception) {
            ""
        }
    }

    private fun decrypt(cipherText: String): String {
        if (cipherText.isBlank()) return ""
        return try {
            val combined = Base64.decode(cipherText, Base64.NO_WRAP)
            if (combined.size < 12) return ""
            val secretKey = getOrCreateSecretKey()
            val cipher = Cipher.getInstance(TRANSFORMATION)
            val gcmSpec = GCMParameterSpec(128, combined, 0, 12)
            cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec)
            val decryptedBytes = cipher.doFinal(
                combined,
                12,
                combined.size - 12
            )
            String(decryptedBytes, StandardCharsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}

