package com.zelvyn.player.ui.player

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.annotation.OptIn
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.audio.DeviceHardwareController
import com.zelvyn.player.model.PlaylistItem
import com.zelvyn.player.model.TranslationSegment
import com.zelvyn.player.model.VideoItem
import com.zelvyn.player.ui.components.FloatingQuickMenu
import com.zelvyn.player.ui.components.GlowingPlayButton
import com.zelvyn.player.ui.components.NeonScrubberBar
import com.zelvyn.player.ui.theme.*

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    exoPlayer: ExoPlayer,
    video: VideoItem,
    queue: List<VideoItem>,
    playlists: List<PlaylistItem>,
    activeSegment: TranslationSegment?,
    audioDspManager: AudioDspManager,
    hardwareController: DeviceHardwareController,
    onBackPress: () -> Unit,
    onToggleLiveTranslation: () -> Unit,
    onSelectQueueItem: (VideoItem) -> Unit
) {
    var controlsVisible by remember { mutableStateOf(true) }
    var isLocked by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(exoPlayer.isPlaying) }
    var currentPos by remember { mutableLongStateOf(0L) }
    var duration by remember { mutableLongStateOf(1L) }

    var showAdvancedSheet by remember { mutableStateOf(false) }
    var showQueueSheet by remember { mutableStateOf(false) }
    var showQuickMenu by remember { mutableStateOf(false) }
    var playbackSpeed by remember { mutableFloatStateOf(1.0f) }

    var gestureVisible by remember { mutableStateOf(false) }
    var gestureIcon by remember { mutableStateOf(Icons.Rounded.VolumeUp) }
    var gestureLevel by remember { mutableFloatStateOf(0f) }
    var gestureTitle by remember { mutableStateOf("Volume") }

    LaunchedEffect(exoPlayer) {
        while (true) {
            currentPos = exoPlayer.currentPosition.coerceAtLeast(0L)
            duration = exoPlayer.duration.coerceAtLeast(1L)
            isPlaying = exoPlayer.isPlaying
            kotlinx.coroutines.delay(200)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .pointerInput(Unit) {
                detectTapGestures(
                    onTap = {
                        if (!isLocked) {
                            controlsVisible = !controlsVisible
                            showQuickMenu = false
                        }
                    },
                    onDoubleTap = { offset ->
                        if (!isLocked) {
                            val screenWidth = size.width
                            if (offset.x < screenWidth / 2) {
                                exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0))
                            } else {
                                exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(exoPlayer.duration))
                            }
                        }
                    }
                )
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { gestureVisible = true },
                    onDragEnd = { gestureVisible = false },
                    onDragCancel = { gestureVisible = false },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        if (!isLocked) {
                            val screenWidth = size.width
                            val startX = change.position.x
                            if (startX > screenWidth / 2) {
                                val delta = -dragAmount.y / 800f
                                hardwareController.adjustVolume(delta)
                                gestureIcon = Icons.Rounded.VolumeUp
                                gestureLevel = hardwareController.getVolumeLevel()
                                gestureTitle = "Volume ${(gestureLevel * 100).toInt()}%"
                            } else {
                                val delta = -dragAmount.y / 800f
                                hardwareController.adjustBrightness(delta)
                                gestureIcon = Icons.Rounded.BrightnessHigh
                                gestureLevel = hardwareController.getBrightnessLevel()
                                gestureTitle = "Brightness ${(gestureLevel * 100).toInt()}%"
                            }
                        }
                    }
                )
            }
    ) {
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = false
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
            },
            modifier = Modifier.fillMaxSize()
        )

        DualSubtitleOverlay(
            segment = activeSegment,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(bottom = if (controlsVisible) 115.dp else 40.dp)
                .padding(horizontal = 20.dp)
        )

        GestureFeedbackIndicator(
            visible = gestureVisible,
            icon = gestureIcon,
            level = gestureLevel,
            title = gestureTitle,
            modifier = Modifier.align(Alignment.Center)
        )

        FloatingQuickMenu(
            playbackSpeed = playbackSpeed,
            onOpenMore = {
                showQuickMenu = false
                showAdvancedSheet = true
            },
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 16.dp)
        )

        AnimatedVisibility(
            visible = controlsVisible,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color.Black.copy(alpha = 0.8f),
                                Color.Transparent,
                                Color.Black.copy(alpha = 0.85f)
                            )
                        )
                    )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .statusBarsPadding()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBackPress) {
                        Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }

                    Column(modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        Text(
                            text = video.title,
                            color = Color.White,
                            fontSize = 16.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            BadgeItem(video.resolution)
                            video.hdrType?.let { BadgeItem(it) }
                            BadgeItem("Dolby Vision")
                        }
                    }

                    IconButton(onClick = { showQueueSheet = true }) {
                        Icon(Icons.Rounded.QueueMusic, contentDescription = "Queue", tint = Color.White)
                    }
                    IconButton(onClick = onToggleLiveTranslation) {
                        Icon(Icons.Rounded.Translate, contentDescription = "Translate", tint = AccentCyan)
                    }
                    IconButton(onClick = { showQuickMenu = !showQuickMenu }) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = "Menu", tint = Color.White)
                    }
                }

                if (!isLocked) {
                    Row(
                        modifier = Modifier.align(Alignment.Center),
                        horizontalArrangement = Arrangement.spacedBy(28.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = { exoPlayer.seekTo((exoPlayer.currentPosition - 10000).coerceAtLeast(0)) },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Rounded.Replay10, contentDescription = "Rewind", tint = Color.White, modifier = Modifier.size(36.dp))
                        }

                        GlowingPlayButton(
                            isPlaying = isPlaying,
                            onClick = {
                                if (isPlaying) exoPlayer.pause() else exoPlayer.play()
                                isPlaying = !isPlaying
                            }
                        )

                        IconButton(
                            onClick = { exoPlayer.seekTo((exoPlayer.currentPosition + 10000).coerceAtMost(exoPlayer.duration)) },
                            modifier = Modifier.size(48.dp)
                        ) {
                            Icon(Icons.Rounded.Forward10, contentDescription = "Forward", tint = Color.White, modifier = Modifier.size(36.dp))
                        }
                    }
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                        .navigationBarsPadding()
                        .padding(horizontal = 20.dp, vertical = 12.dp)
                ) {
                    if (!isLocked) {
                        NeonScrubberBar(
                            currentPosMs = currentPos,
                            durationMs = duration,
                            onSeek = { exoPlayer.seekTo(it) }
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(formatTime(currentPos), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                            Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                IconButton(onClick = { isLocked = !isLocked }, modifier = Modifier.size(24.dp)) {
                                    Icon(
                                        imageVector = if (isLocked) Icons.Rounded.Lock else Icons.Rounded.LockOpen,
                                        contentDescription = "Lock",
                                        tint = Color.White
                                    )
                                }
                                IconButton(onClick = { showAdvancedSheet = true }, modifier = Modifier.size(24.dp)) {
                                    Icon(Icons.Rounded.Tune, contentDescription = "Settings", tint = Color.White)
                                }
                            }
                            Text(formatTime(duration), color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp)
                        }
                    } else {
                        IconButton(
                            onClick = { isLocked = false },
                            modifier = Modifier.align(Alignment.CenterHorizontally)
                        ) {
                            Icon(Icons.Rounded.Lock, contentDescription = "Unlock", tint = AccentVioletLight, modifier = Modifier.size(32.dp))
                        }
                    }
                }
            }
        }

        if (showAdvancedSheet) {
            AdvancedControlsSheet(
                playbackSpeed = playbackSpeed,
                audioDspManager = audioDspManager,
                onSpeedChange = { newSpeed ->
                    playbackSpeed = newSpeed
                    exoPlayer.playbackParameters = exoPlayer.playbackParameters.withSpeed(newSpeed)
                },
                onDismiss = { showAdvancedSheet = false }
            )
        }

        if (showQueueSheet) {
            PlaylistsAndQueueSheet(
                queue = queue,
                playlists = playlists,
                onSelectQueueItem = {
                    onSelectQueueItem(it)
                    showQueueSheet = false
                },
                onDismiss = { showQueueSheet = false }
            )
        }
    }
}

@Composable
fun BadgeItem(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(Color(0xFF262C3D))
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(text = text, color = Color(0xFFF59E0B), fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}

fun formatTime(ms: Long): String {
    val totalSeconds = ms / 1000
    val hours = totalSeconds / 3600
    val minutes = (totalSeconds % 3600) / 60
    val seconds = totalSeconds % 60
    return if (hours > 0) {
        String.format("%d:%02d:%02d", hours, minutes, seconds)
    } else {
        String.format("%02d:%02d", minutes, seconds)
    }
}