package com.zelvyn.player.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp

@Composable
fun NeonScrubberBar(
    currentPosMs: Long,
    durationMs: Long,
    bufferedPosMs: Long = (currentPosMs + 30000).coerceAtMost(durationMs),
    onSeek: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val progress = if (durationMs > 0) (currentPosMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f
    val bufferProgress = if (durationMs > 0) (bufferedPosMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(28.dp)
            .pointerInput(durationMs) {
                detectTapGestures { offset ->
                    val newProgress = (offset.x / size.width).coerceIn(0f, 1f)
                    onSeek((newProgress * durationMs).toLong())
                }
            }
            .pointerInput(durationMs) {
                detectDragGestures { change, _ ->
                    change.consume()
                    val newProgress = (change.position.x / size.width).coerceIn(0f, 1f)
                    onSeek((newProgress * durationMs).toLong())
                }
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Canvas(modifier = Modifier.fillMaxWidth().height(6.dp)) {
            val trackHeight = 4.dp.toPx()
            val corner = CornerRadius(trackHeight / 2, trackHeight / 2)

            drawRoundRect(
                color = Color(0xFF1E2536),
                size = Size(size.width, trackHeight),
                cornerRadius = corner
            )

            drawRoundRect(
                color = Color(0xFF334155),
                size = Size(size.width * bufferProgress, trackHeight),
                cornerRadius = corner
            )

            drawRoundRect(
                brush = Brush.horizontalGradient(
                    colors = listOf(Color(0xFF7C3AED), Color(0xFF00E5FF))
                ),
                size = Size(size.width * progress, trackHeight),
                cornerRadius = corner
            )

            val thumbX = size.width * progress
            drawCircle(
                color = Color(0xFF00E5FF).copy(alpha = 0.35f),
                radius = 8.dp.toPx(),
                center = Offset(thumbX, trackHeight / 2)
            )
            drawCircle(
                color = Color.White,
                radius = 4.5.dp.toPx(),
                center = Offset(thumbX, trackHeight / 2)
            )
        }
    }
}