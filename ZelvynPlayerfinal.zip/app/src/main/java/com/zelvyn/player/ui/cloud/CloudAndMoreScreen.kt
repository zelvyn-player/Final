package com.zelvyn.player.ui.cloud

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.ui.theme.*

@Composable
fun CloudAndMoreScreen(title: String) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .statusBarsPadding()
            .padding(16.dp)
    ) {
        Text(
            text = title,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = TextPrimary,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                FeatureBadgeCard(
                    icon = Icons.Rounded.CloudSync,
                    title = "Cloud Sync",
                    desc = "Watch anywhere, sync progress & playback across all devices seamlessly."
                )
            }
            item {
                FeatureBadgeCard(
                    icon = Icons.Rounded.Security,
                    title = "Private & Secure",
                    desc = "On-device processing keeps your media, transcripts, and data on your phone."
                )
            }
            item {
                FeatureBadgeCard(
                    icon = Icons.Rounded.HighQuality,
                    title = "8K Ultra HD & HDR10+",
                    desc = "Hardware accelerated rendering with Dolby Vision and HLG support."
                )
            }
            item {
                FeatureBadgeCard(
                    icon = Icons.Rounded.AllInclusive,
                    title = "All Format Support",
                    desc = "MKV, MP4, AVI, MOV, FLAC, TS, WebM and multi-track audio playback."
                )
            }
        }
    }
}

@Composable
fun FeatureBadgeCard(
    icon: ImageVector,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(SurfaceElevated)
            .border(1.dp, SurfaceBorder, RoundedCornerShape(14.dp))
            .padding(16.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(10.dp))
                .background(AccentViolet.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(icon, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(24.dp))
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = desc, color = TextSecondary, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}