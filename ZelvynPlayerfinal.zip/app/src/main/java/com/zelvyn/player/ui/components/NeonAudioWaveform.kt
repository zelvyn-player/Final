package com.zelvyn.player.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

@Composable
fun NeonAudioWaveform(
    isListening: Boolean = true,
    barCount: Int = 18,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "waveform")

    Row(
        modifier = modifier.height(36.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val baseHeights = listOf(8, 14, 24, 32, 18, 28, 36, 20, 12, 30, 22, 16, 26, 34, 18, 10, 22, 14)

        for (i in 0 until barCount) {
            val animDuration = 600 + (i * 70)
            val animatedFraction by infiniteTransition.animateFloat(
                initialValue = 0.25f,
                targetValue = if (isListening) 1.0f else 0.25f,
                animationSpec = infiniteRepeatable(
                    animation = tween(animDuration, easing = EaseInOutQuad),
                    repeatMode = RepeatMode.Reverse
                ),
                label = "bar_$i"
            )

            val currentHeight = (baseHeights[i % baseHeights.size] * animatedFraction).dp.coerceAtLeast(4.dp)

            Box(
                modifier = Modifier
                    .width(3.dp)
                    .height(currentHeight)
                    .clip(RoundedCornerShape(2.dp))
                    .background(
                        Brush.verticalGradient(
                            colors = listOf(
                                Color(0xFF00E5FF),
                                Color(0xFF7C3AED)
                            )
                        )
                    )
            )
        }
    }
}