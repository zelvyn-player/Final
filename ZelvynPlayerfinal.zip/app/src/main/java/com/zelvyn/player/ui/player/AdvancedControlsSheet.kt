package com.zelvyn.player.ui.player

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.model.EqualizerPresetType
import com.zelvyn.player.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdvancedControlsSheet(
    playbackSpeed: Float,
    audioDspManager: AudioDspManager,
    onSpeedChange: (Float) -> Unit,
    onDismiss: () -> Unit
) {
    val bands by audioDspManager.bands.collectAsState()
    val activePreset by audioDspManager.currentPreset.collectAsState()

    var selectedAudioTrack by remember { mutableStateOf("English 7.1") }
    var subtitlesEnabled by remember { mutableStateOf(true) }
    var selectedSubtitle by remember { mutableStateOf("English") }
    var subtitleSize by remember { mutableIntStateOf(100) }
    var sleepTimer by remember { mutableStateOf("Off") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = SurfaceDark,
        tonalElevation = 12.dp
    ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .navigationBarsPadding(),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            item {
                Text(
                    text = "Advanced Controls",
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            }

            item {
                Text(text = "Playback Speed (${playbackSpeed}x)", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(0.25f, 0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f).forEach { speed ->
                        val isSelected = speed == playbackSpeed
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) AccentViolet else SurfaceElevated)
                                .clickable { onSpeedChange(speed) }
                                .padding(horizontal = 8.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = "${speed}x",
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSelected) Color.White else TextSecondary
                            )
                        }
                    }
                }
            }

            item {
                Text(text = "Audio Track", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("English 7.1", "Hindi 5.1", "Spanish 5.1", "French 5.1", "Japanese 5.1", "Korean 5.1").forEach { track ->
                        val isSelected = track == selectedAudioTrack
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) AccentViolet.copy(alpha = 0.2f) else SurfaceElevated)
                                .clickable { selectedAudioTrack = track }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = track, color = TextPrimary, fontSize = 13.sp)
                            if (isSelected) {
                                Icon(Icons.Rounded.Check, contentDescription = null, tint = AccentCyan, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }

            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "Subtitles", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                    Switch(
                        checked = subtitlesEnabled,
                        onCheckedChange = { subtitlesEnabled = it },
                        colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = AccentViolet)
                    )
                }

                if (subtitlesEnabled) {
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("English", "Spanish", "French", "German", "Arabic").forEach { sub ->
                            val isSelected = sub == selectedSubtitle
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(if (isSelected) AccentViolet else SurfaceElevated)
                                    .clickable { selectedSubtitle = sub }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(text = sub, fontSize = 11.sp, color = if (isSelected) Color.White else TextSecondary)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(text = "Size", fontSize = 12.sp, color = TextMuted)
                        Button(
                            onClick = { subtitleSize = (subtitleSize - 10).coerceAtLeast(50) },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                        ) { Text("-", color = Color.White) }
                        Text(text = "$subtitleSize%", fontSize = 12.sp, color = TextPrimary)
                        Button(
                            onClick = { subtitleSize = (subtitleSize + 10).coerceAtMost(200) },
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceElevated),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 2.dp)
                        ) { Text("+", color = Color.White) }
                    }
                }
            }

            item {
                Text(text = "Equalizer", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    listOf(
                        EqualizerPresetType.FLAT to "Flat",
                        EqualizerPresetType.POP to "Pop",
                        EqualizerPresetType.ROCK to "Rock",
                        EqualizerPresetType.BASS to "Bass"
                    ).forEach { (preset, label) ->
                        val isSelected = activePreset == preset
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) AccentViolet else SurfaceElevated)
                                .clickable { audioDspManager.applyPreset(preset) }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Text(text = label, fontSize = 11.sp, color = if (isSelected) Color.White else TextSecondary)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    bands.forEach { band ->
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Slider(
                                value = band.gainDb,
                                onValueChange = { audioDspManager.setBandGain(band.bandIndex, it) },
                                valueRange = -10f..10f,
                                modifier = Modifier
                                    .height(110.dp)
                                    .width(40.dp),
                                colors = SliderDefaults.colors(thumbColor = AccentCyan, activeTrackColor = AccentViolet)
                            )
                            Text(text = band.frequencyLabel, fontSize = 9.sp, color = TextMuted)
                        }
                    }
                }
            }

            item {
                Text(text = "Sleep Timer", fontSize = 13.sp, color = TextSecondary, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf("Off", "10m", "20m", "30m", "45m", "60m", "90m").forEach { timer ->
                        val isSelected = timer == sleepTimer
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(8.dp))
                                .background(if (isSelected) AccentViolet else SurfaceElevated)
                                .clickable { sleepTimer = timer }
                                .padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = timer, fontSize = 10.sp, color = Color.White)
                        }
                    }
                }
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}