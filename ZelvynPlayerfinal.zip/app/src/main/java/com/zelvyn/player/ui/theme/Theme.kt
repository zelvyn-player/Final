package com.zelvyn.player.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val ZelvynColorScheme = darkColorScheme(
    primary = AccentViolet,
    secondary = AccentCyan,
    tertiary = AccentGold,
    background = DarkBackground,
    surface = SurfaceDark,
    surfaceVariant = SurfaceElevated,
    onPrimary = Color.White,
    onSecondary = Color.Black,
    onBackground = TextPrimary,
    onSurface = TextPrimary
)

@Composable
fun ZelvynTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ZelvynColorScheme,
        content = content
    )
}