package com.zelvyn.player.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun FloatingQuickMenu(
    playbackSpeed: Float,
    onOpenMore: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .width(170.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF131826).copy(alpha = 0.90f),
                        Color(0xFF0B0E17).copy(alpha = 0.95f)
                    )
                )
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color.White.copy(alpha = 0.18f),
                        Color(0xFF263248).copy(alpha = 0.40f)
                    )
                ),
                shape = RoundedCornerShape(18.dp)
            )
            .padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        QuickMenuRow(icon = Icons.Rounded.HighQuality, title = "Quality", subtitle = "8K HDR10+") {}
        QuickMenuRow(icon = Icons.Rounded.Audiotrack, title = "Audio Track", subtitle = "English 7.1") { onOpenMore() }
        QuickMenuRow(icon = Icons.Rounded.Subtitles, title = "Subtitles", subtitle = "English") { onOpenMore() }
        QuickMenuRow(icon = Icons.Rounded.Speed, title = "Speed", subtitle = "${playbackSpeed}x") { onOpenMore() }
        QuickMenuRow(icon = Icons.Rounded.Timer, title = "Timer", subtitle = "Off") { onOpenMore() }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable { onOpenMore() }
                .padding(vertical = 4.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = "••• More",
                color = Color(0xFF94A3B8),
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun QuickMenuRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .clickable { onClick() }
            .padding(horizontal = 6.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(icon, contentDescription = null, tint = Color(0xFF94A3B8), modifier = Modifier.size(15.dp))
            Column {
                Text(text = title, fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Medium)
                Text(text = subtitle, fontSize = 9.sp, color = Color(0xFF64748B))
            }
        }
        Icon(Icons.Rounded.ChevronRight, contentDescription = null, tint = Color(0xFF475569), modifier = Modifier.size(14.dp))
    }
}