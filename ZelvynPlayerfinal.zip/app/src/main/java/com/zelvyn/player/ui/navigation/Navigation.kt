package com.zelvyn.player.ui.navigation

import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.ui.theme.AccentViolet
import com.zelvyn.player.ui.theme.SurfaceDark
import com.zelvyn.player.ui.theme.TextMuted

enum class AppTab(val title: String, val icon: ImageVector) {
    HOME("Home", Icons.Rounded.Home),
    LIBRARY("Library", Icons.Rounded.VideoLibrary),
    TRANSLATE("Translate", Icons.Rounded.Translate),
    CLOUD("Cloud", Icons.Rounded.Cloud),
    MORE("More", Icons.Rounded.MoreHoriz)
}

@Composable
fun ZelvynBottomNavBar(
    selectedTab: AppTab,
    onTabSelected: (AppTab) -> Unit
) {
    NavigationBar(
        containerColor = SurfaceDark,
        tonalElevation = 8.dp,
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
    ) {
        AppTab.entries.forEach { tab ->
            val isSelected = tab == selectedTab
            NavigationBarItem(
                selected = isSelected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = tab.icon,
                        contentDescription = tab.title,
                        tint = if (isSelected) AccentViolet else TextMuted
                    )
                },
                label = {
                    Text(
                        text = tab.title,
                        fontSize = 11.sp,
                        color = if (isSelected) Color.White else TextMuted
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    indicatorColor = AccentViolet.copy(alpha = 0.15f)
                )
            )
        }
    }
}