package com.zelvyn.player.model

import android.net.Uri

data class VideoItem(
    val id: Long,
    val uri: Uri,
    val title: String,
    val durationMs: Long,
    val resolution: String = "4K HDR",
    val hdrType: String? = "HDR10+",
    val year: String = "2024",
    val folder: String = "Movies",
    val lastPositionMs: Long = 0L
)

data class TranslationSegment(
    val sessionId: Long,
    val startTimeMs: Long,
    val endTimeMs: Long,
    val originalText: String,
    val translatedText: String,
    val sourceLang: String,
    val targetLang: String
)

enum class TranslationMode {
    VOICE, SUBTITLE, VOICE_AND_SUBTITLE
}

enum class SpeechStyle {
    NATURAL, CLEAR
}

enum class EqualizerPresetType {
    FLAT, POP, ROCK, BASS, CUSTOM
}

data class EqualizerBandState(
    val bandIndex: Int,
    val frequencyLabel: String,
    val gainDb: Float
)

data class PlaylistItem(
    val id: String,
    val name: String,
    val videoCount: Int
)