package com.zelvyn.player.data

import com.zelvyn.player.model.TranslationSegment
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicLong

class TranslationCoordinator(private val scope: CoroutineScope) {

    private val currentSessionId = AtomicLong(0)

    private val _activeSegment = MutableStateFlow<TranslationSegment?>(null)
    val activeSegment: StateFlow<TranslationSegment?> = _activeSegment.asStateFlow()

    private val _isTranslationActive = MutableStateFlow(false)
    val isTranslationActive: StateFlow<Boolean> = _isTranslationActive.asStateFlow()

    private val _sourceLanguage = MutableStateFlow("English")
    val sourceLanguage: StateFlow<String> = _sourceLanguage.asStateFlow()

    private val _targetLanguage = MutableStateFlow("Spanish")
    val targetLanguage: StateFlow<String> = _targetLanguage.asStateFlow()

    private val segmentCache = mutableListOf<TranslationSegment>()

    fun startSession(source: String, target: String): Long {
        val sessionId = currentSessionId.incrementAndGet()
        _sourceLanguage.value = source
        _targetLanguage.value = target
        segmentCache.clear()
        _activeSegment.value = null
        _isTranslationActive.value = true

        segmentCache.addAll(
            listOf(
                TranslationSegment(
                    sessionId = sessionId,
                    startTimeMs = 0L,
                    endTimeMs = 12000L,
                    originalText = "Mankind was born on Earth. It was never meant to die here.",
                    translatedText = "La humanidad nació en la Tierra. Nunca fue meant para morir aquí.",
                    sourceLang = source,
                    targetLang = target
                ),
                TranslationSegment(
                    sessionId = sessionId,
                    startTimeMs = 12000L,
                    endTimeMs = 26000L,
                    originalText = "We're not meant to save the world. We're meant to leave it.",
                    translatedText = "No estamos destinados a salvar el mundo. Estamos destinados a dejarlo.",
                    sourceLang = source,
                    targetLang = target
                ),
                TranslationSegment(
                    sessionId = sessionId,
                    startTimeMs = 26000L,
                    endTimeMs = 45000L,
                    originalText = "Survival is now our priority. Don't trust too much anyone in this world.",
                    translatedText = "La supervivencia es ahora nuestra prioridad. No confíes demasiado en nadie en este mundo.",
                    sourceLang = source,
                    targetLang = target
                )
            )
        )
        return sessionId
    }

    fun stopSession() {
        currentSessionId.incrementAndGet()
        segmentCache.clear()
        _activeSegment.value = null
        _isTranslationActive.value = false
    }

    fun onPlaybackPositionChanged(positionMs: Long) {
        if (!_isTranslationActive.value) return
        val match = segmentCache.find { positionMs in it.startTimeMs..it.endTimeMs }
        _activeSegment.value = match
    }

    fun onSeekInvalidate() {
        _activeSegment.value = null
    }
}