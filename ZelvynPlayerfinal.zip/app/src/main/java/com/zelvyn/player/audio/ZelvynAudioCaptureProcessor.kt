package com.zelvyn.player.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.AudioProcessor.AudioFormat
import androidx.media3.common.util.UnstableApi
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Custom Media3 AudioProcessor that intercepts decoded 16-bit PCM audio samples directly
 * from ExoPlayer playback without modifying or disrupting audio output.
 */
@UnstableApi
class ZelvynAudioCaptureProcessor(
    private val onChunkReady: (ByteArray, Int, Int) -> Unit
) : AudioProcessor {

    private var inputAudioFormat: AudioFormat = AudioFormat.NOT_SET
    private var outputAudioFormat: AudioFormat = AudioFormat.NOT_SET

    private var buffer: ByteBuffer = AudioProcessor.EMPTY_BUFFER
    private var outputBuffer: ByteBuffer = AudioProcessor.EMPTY_BUFFER
    private var inputEnded: Boolean = false

    private val pcmAccumulator = ByteArrayOutputStream()
    private val chunkThresholdBytes = 16000 * 2 * 1 * 4 // ~4 seconds of 16kHz Mono 16-bit PCM

    var isCapturing: Boolean = false

    override fun configure(inputAudioFormat: AudioFormat): AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT) {
            this.inputAudioFormat = AudioFormat.NOT_SET
            this.outputAudioFormat = AudioFormat.NOT_SET
            return AudioFormat.NOT_SET
        }
        this.inputAudioFormat = inputAudioFormat
        this.outputAudioFormat = inputAudioFormat
        return outputAudioFormat
    }

    override fun isActive(): Boolean {
        return outputAudioFormat != AudioFormat.NOT_SET
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val remaining = inputBuffer.remaining()
        if (remaining == 0) return

        if (isCapturing && inputAudioFormat.sampleRate > 0) {
            val dup = inputBuffer.duplicate()
            val tempBytes = ByteArray(dup.remaining())
            dup.get(tempBytes)

            synchronized(pcmAccumulator) {
                pcmAccumulator.write(tempBytes)
                if (pcmAccumulator.size() >= chunkThresholdBytes) {
                    val rawPcm = pcmAccumulator.toByteArray()
                    pcmAccumulator.reset()
                    onChunkReady(rawPcm, inputAudioFormat.sampleRate, inputAudioFormat.channelCount)
                }
            }
        }

        // Pass buffer downstream untouched so playback is never interrupted
        if (buffer.capacity() < remaining) {
            buffer = ByteBuffer.allocateDirect(remaining).order(ByteOrder.nativeOrder())
        } else {
            buffer.clear()
        }
        buffer.put(inputBuffer)
        buffer.flip()
        outputBuffer = buffer
    }

    override fun queueEndOfStream() {
        inputEnded = true
    }

    override fun getOutput(): ByteBuffer {
        val out = outputBuffer
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        return out
    }

    override fun isEnded(): Boolean {
        return inputEnded && outputBuffer === AudioProcessor.EMPTY_BUFFER
    }

    override fun flush() {
        outputBuffer = AudioProcessor.EMPTY_BUFFER
        inputEnded = false
        synchronized(pcmAccumulator) {
            pcmAccumulator.reset()
        }
    }

    override fun reset() {
        flush()
        buffer = AudioProcessor.EMPTY_BUFFER
        inputAudioFormat = AudioFormat.NOT_SET
        outputAudioFormat = AudioFormat.NOT_SET
    }
}
