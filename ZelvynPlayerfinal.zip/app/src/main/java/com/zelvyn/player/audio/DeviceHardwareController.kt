package com.zelvyn.player.audio

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.view.WindowManager

class DeviceHardwareController(private val activity: Activity) {

    private val audioManager = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun getVolumeLevel(): Float {
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        return if (max > 0) current.toFloat() / max.toFloat() else 0f
    }

    fun adjustVolume(delta: Float) {
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val step = (delta * max).toInt()
        val target = (current + step).coerceIn(0, max)
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
    }

    fun getBrightnessLevel(): Float {
        val window = activity.window
        val current = window.attributes.screenBrightness
        return if (current < 0) 0.5f else current
    }

    fun adjustBrightness(delta: Float) {
        val window = activity.window
        val layoutParams: WindowManager.LayoutParams = window.attributes
        val current = if (layoutParams.screenBrightness < 0) 0.5f else layoutParams.screenBrightness
        val target = (current + delta).coerceIn(0.01f, 1.0f)
        layoutParams.screenBrightness = target
        window.attributes = layoutParams
    }
}
