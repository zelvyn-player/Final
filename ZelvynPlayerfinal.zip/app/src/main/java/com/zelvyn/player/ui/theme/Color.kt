package com.zelvyn.player.ui.theme

import androidx.compose.ui.graphics.Color

val DarkBackground = Color(0xFF07090E)
val SurfaceDark = Color(0xFF0E131F)
val SurfaceElevated = Color(0xFF161D2E)
val SurfaceBorder = Color(0xFF263248)
val AccentViolet = Color(0xFF7C3AED)
val AccentVioletLight = Color(0xFF9061F9)
val AccentCyan = Color(0xFF00E5FF)
val AccentGold = Color(0xFFF59E0B)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)