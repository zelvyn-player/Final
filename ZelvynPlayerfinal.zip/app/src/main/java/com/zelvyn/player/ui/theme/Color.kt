package com.zelvyn.player.ui.theme

import androidx.compose.ui.graphics.Color

// Strict Monochromatic Black & White Token System (No AI-Generated Neon Clichés)
val CanvasDark = Color(0xFF0A0A0C)
val SurfaceSubtle = Color(0xFF141418)
val SurfaceElevated = Color(0xFF1C1C22)
val SurfacePressed = Color(0xFF24242C)
val BorderSubtle = Color(0xFF2A2A32)
val BorderHighlight = Color(0xFF3E3E4A)

val TextPrimary = Color(0xFFF4F4F6)
val TextSecondary = Color(0xFF8E8E98)
val TextTertiary = Color(0xFF5A5A64)

val AccentWarm = Color(0xFFE2E2E6)
val AccentWarning = Color(0xFFD97706)
val AccentError = Color(0xFFDC2626)
