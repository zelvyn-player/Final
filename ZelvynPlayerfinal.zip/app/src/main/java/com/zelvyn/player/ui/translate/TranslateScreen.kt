package com.zelvyn.player.ui.translate

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.data.TranslationCoordinator
import com.zelvyn.player.model.SpeechStyle
import com.zelvyn.player.model.TranslationMode
import com.zelvyn.player.model.TranslationStatus
import com.zelvyn.player.ui.theme.*

@Composable
fun TranslateScreen(
    translationCoordinator: TranslationCoordinator,
    apiKey: String,
    onNavigateSettings: () -> Unit
) {
    val currentSource by translationCoordinator.sourceLanguage.collectAsState()
    val currentTarget by translationCoordinator.targetLanguage.collectAsState()
    val status by translationCoordinator.status.collectAsState()
    val statusMsg by translationCoordinator.statusMessage.collectAsState()
    val isActive by translationCoordinator.isTranslationActive.collectAsState()

    var selectedMode by remember { mutableStateOf(TranslationMode.VOICE_AND_SUBTITLE) }
    var speechStyle by remember { mutableStateOf(SpeechStyle.NATURAL) }

    val languages = listOf("Auto Detect", "Spanish", "Hindi", "French", "German", "Japanese", "Urdu", "Bengali", "Mandarin", "Portuguese", "Arabic", "Russian", "Korean", "Turkish", "Italian", "Vietnamese", "English")

    var showSourceDialog by remember { mutableStateOf(false) }
    var showTargetDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasDark)
            .statusBarsPadding()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Live Translation",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            IconButton(onClick = onNavigateSettings) {
                Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = TextSecondary)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Center Status Orb
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(SurfaceSubtle)
                .border(1.dp, if (isActive) BorderHighlight else BorderSubtle, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isActive) Icons.Rounded.Mic else Icons.Rounded.MicNone,
                contentDescription = null,
                tint = if (isActive) TextPrimary else TextTertiary,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = when (status) {
                TranslationStatus.CAPTURING_AUDIO -> "Listening for dialogue..."
                TranslationStatus.TRANSLATING -> "Processing with Gemini API..."
                TranslationStatus.ACTIVE -> "Translation active"
                TranslationStatus.NO_SPEECH -> "No dialogue in current scene"
                TranslationStatus.ERROR_NO_INTERNET -> "No internet connection"
                TranslationStatus.ERROR_API_KEY -> "Gemini API key missing"
                else -> if (isActive) "Ready" else "Inactive (play video to start)"
            },
            color = if (status == TranslationStatus.ERROR_API_KEY || status == TranslationStatus.ERROR_NO_INTERNET) AccentWarning else TextSecondary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium
        )

        if (statusMsg != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = statusMsg!!,
                color = TextTertiary,
                fontSize = 11.sp
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Source & Target Selector Cards
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceSubtle)
                .border(1.dp, BorderSubtle, RoundedCornerShape(12.dp))
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { showSourceDialog = true }
            ) {
                Text(text = "Source", fontSize = 11.sp, color = TextTertiary)
                Text(text = currentSource, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            }

            Icon(Icons.Rounded.SwapHoriz, contentDescription = null, tint = TextTertiary, modifier = Modifier.padding(horizontal = 8.dp))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .clickable { showTargetDialog = true },
                horizontalAlignment = Alignment.End
            ) {
                Text(text = "Target", fontSize = 11.sp, color = TextTertiary)
                Text(text = currentTarget, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Mode Selector: Voice | Subtitle | Both
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(SurfaceSubtle)
                .padding(3.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            TranslationMode.entries.forEach { mode ->
                val isSelected = mode == selectedMode
                val label = when (mode) {
                    TranslationMode.VOICE -> "Voice"
                    TranslationMode.SUBTITLE -> "Subtitle"
                    TranslationMode.VOICE_AND_SUBTITLE -> "Dual Output"
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) SurfaceElevated else Color.Transparent)
                        .clickable { selectedMode = mode }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                        color = if (isSelected) TextPrimary else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Speech Style
        Text(
            text = "SPEECH STYLE",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = TextTertiary,
            letterSpacing = 1.sp,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Button(
                onClick = { speechStyle = SpeechStyle.NATURAL },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (speechStyle == SpeechStyle.NATURAL) SurfaceElevated else SurfaceSubtle
                ),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (speechStyle == SpeechStyle.NATURAL) BorderHighlight else BorderSubtle),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "Natural", color = TextPrimary, fontSize = 13.sp)
            }
            Button(
                onClick = { speechStyle = SpeechStyle.CLEAR },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (speechStyle == SpeechStyle.CLEAR) SurfaceElevated else SurfaceSubtle
                ),
                shape = RoundedCornerShape(8.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, if (speechStyle == SpeechStyle.CLEAR) BorderHighlight else BorderSubtle),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "Clear", color = TextPrimary, fontSize = 13.sp)
            }
        }
    }

    if (showSourceDialog) {
        LanguageSelectDialog(
            title = "Select Source Language",
            options = languages,
            selected = currentSource,
            onSelect = {
                translationCoordinator.setLanguages(it, currentTarget)
                showSourceDialog = false
            },
            onDismiss = { showSourceDialog = false }
        )
    }

    if (showTargetDialog) {
        LanguageSelectDialog(
            title = "Select Target Language",
            options = languages.filter { it != "Auto Detect" },
            selected = currentTarget,
            onSelect = {
                translationCoordinator.setLanguages(currentSource, it)
                showTargetDialog = false
            },
            onDismiss = { showTargetDialog = false }
        )
    }
}

@Composable
fun LanguageSelectDialog(
    title: String,
    options: List<String>,
    selected: String,
    onSelect: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = SurfaceElevated,
        title = { Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Bold, color = TextPrimary) },
        text = {
            LazyColumn(modifier = Modifier.height(280.dp)) {
                items(options) { lang ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(lang) }
                            .padding(vertical = 10.dp, horizontal = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = lang, color = TextPrimary, fontSize = 14.sp)
                        if (lang == selected) {
                            Icon(Icons.Rounded.Check, contentDescription = null, tint = TextPrimary, modifier = Modifier.size(16.dp))
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close", color = TextSecondary) }
        }
    )
}
