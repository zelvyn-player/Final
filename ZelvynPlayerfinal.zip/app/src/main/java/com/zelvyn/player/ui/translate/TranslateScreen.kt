package com.zelvyn.player.ui.translate

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.model.SpeechStyle
import com.zelvyn.player.model.TranslationMode
import com.zelvyn.player.ui.components.NeonAudioWaveform
import com.zelvyn.player.ui.theme.*

@Composable
fun TranslateScreen() {
    var sourceLang by remember { mutableStateOf("Auto Detect") }
    var targetLang by remember { mutableStateOf("Spanish") }
    var selectedMode by remember { mutableStateOf(TranslationMode.VOICE_AND_SUBTITLE) }
    var speechStyle by remember { mutableStateOf(SpeechStyle.NATURAL) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(DarkBackground)
            .statusBarsPadding()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "Translate",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
            IconButton(onClick = {}) {
                Icon(Icons.Rounded.Settings, contentDescription = "Settings", tint = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Box(
            modifier = Modifier
                .size(100.dp)
                .clip(CircleShape)
                .background(AccentViolet.copy(alpha = 0.2f))
                .border(2.dp, AccentViolet, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Mic,
                contentDescription = null,
                tint = AccentViolet,
                modifier = Modifier.size(48.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))
        Text(text = "Listening...", color = AccentCyan, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        
        Spacer(modifier = Modifier.height(10.dp))
        NeonAudioWaveform(isListening = true, barCount = 20)

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(SurfaceElevated)
                .border(1.dp, SurfaceBorder, RoundedCornerShape(16.dp))
                .padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "From", fontSize = 11.sp, color = TextMuted)
                Text(text = sourceLang, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            }
            Icon(Icons.Rounded.SwapHoriz, contentDescription = null, tint = AccentCyan)
            Column(horizontalAlignment = Alignment.End) {
                Text(text = "To", fontSize = 11.sp, color = TextMuted)
                Text(text = targetLang, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(SurfaceElevated)
                .padding(4.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            TranslationMode.entries.forEach { mode ->
                val isSelected = mode == selectedMode
                val label = when (mode) {
                    TranslationMode.VOICE -> "Voice"
                    TranslationMode.SUBTITLE -> "Subtitle"
                    TranslationMode.VOICE_AND_SUBTITLE -> "Voice + Subtitle"
                }
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) AccentViolet else Color.Transparent)
                        .clickable { selectedMode = mode }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = label,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                        color = if (isSelected) Color.White else TextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Speech Style",
            fontSize = 13.sp,
            color = TextSecondary,
            modifier = Modifier.align(Alignment.Start)
        )
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = { speechStyle = SpeechStyle.NATURAL },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (speechStyle == SpeechStyle.NATURAL) AccentViolet else SurfaceElevated
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "Natural", color = Color.White)
            }
            Button(
                onClick = { speechStyle = SpeechStyle.CLEAR },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (speechStyle == SpeechStyle.CLEAR) AccentViolet else SurfaceElevated
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.weight(1f)
            ) {
                Text(text = "Clear", color = Color.White)
            }
        }
    }
}