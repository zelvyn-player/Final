package com.zelvyn.player.data

import android.content.Context
import android.content.SharedPreferences
import com.zelvyn.player.model.UserPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences("zelvyn_prefs", Context.MODE_PRIVATE)

    private val _userPreferences = MutableStateFlow(loadPreferences())
    val userPreferences: StateFlow<UserPreferences> = _userPreferences.asStateFlow()

    private fun loadPreferences(): UserPreferences {
        return UserPreferences(
            geminiApiKey = prefs.getString("gemini_api_key", "") ?: "",
            defaultTargetLang = prefs.getString("default_target_lang", "Spanish") ?: "Spanish",
            subtitleFontSizeSp = prefs.getInt("subtitle_font_size", 15),
            subtitleBackgroundAlpha = prefs.getFloat("subtitle_bg_alpha", 0.88f),
            hasCompletedOnboarding = prefs.getBoolean("has_completed_onboarding", false)
        )
    }

    fun setGeminiApiKey(key: String) {
        prefs.edit().putString("gemini_api_key", key.trim()).apply()
        _userPreferences.value = _userPreferences.value.copy(geminiApiKey = key.trim())
    }

    fun setDefaultTargetLang(lang: String) {
        prefs.edit().putString("default_target_lang", lang).apply()
        _userPreferences.value = _userPreferences.value.copy(defaultTargetLang = lang)
    }

    fun setSubtitleFontSize(sizeSp: Int) {
        prefs.edit().putInt("subtitle_font_size", sizeSp).apply()
        _userPreferences.value = _userPreferences.value.copy(subtitleFontSizeSp = sizeSp)
    }

    fun setSubtitleBackgroundAlpha(alpha: Float) {
        prefs.edit().putFloat("subtitle_bg_alpha", alpha).apply()
        _userPreferences.value = _userPreferences.value.copy(subtitleBackgroundAlpha = alpha)
    }

    fun setOnboardingCompleted(completed: Boolean) {
        prefs.edit().putBoolean("has_completed_onboarding", completed).apply()
        _userPreferences.value = _userPreferences.value.copy(hasCompletedOnboarding = completed)
    }
}
