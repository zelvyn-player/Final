package com.zelvyn.player

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.audio.DeviceHardwareController
import com.zelvyn.player.audio.ZelvynAudioCaptureProcessor
import com.zelvyn.player.data.MediaStoreRepository
import com.zelvyn.player.data.PreferencesManager
import com.zelvyn.player.data.TranslationCoordinator
import com.zelvyn.player.model.VideoItem
import com.zelvyn.player.ui.library.LibraryScreen
import com.zelvyn.player.ui.navigation.AppTab
import com.zelvyn.player.ui.navigation.ZelvynBottomNavBar
import com.zelvyn.player.ui.onboarding.OnboardingScreen
import com.zelvyn.player.ui.player.PlayerScreen
import com.zelvyn.player.ui.privacy.PrivacyPolicyScreen
import com.zelvyn.player.ui.settings.SettingsScreen
import com.zelvyn.player.ui.theme.ZelvynTheme
import com.zelvyn.player.ui.translate.TranslateScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var exoPlayer: ExoPlayer
    private lateinit var mediaStoreRepository: MediaStoreRepository
    private lateinit var hardwareController: DeviceHardwareController
    private lateinit var prefsManager: PreferencesManager
    private val audioDspManager = AudioDspManager()
    private val translationCoordinator = TranslationCoordinator(lifecycleScope)

    private lateinit var audioCaptureProcessor: ZelvynAudioCaptureProcessor

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        prefsManager = PreferencesManager(this)
        mediaStoreRepository = MediaStoreRepository(this)
        hardwareController = DeviceHardwareController(this)

        // Setup custom Media3 audio processor for capturing audio during playback
        audioCaptureProcessor = ZelvynAudioCaptureProcessor { pcmData, sampleRate, channels ->
            val userPrefs = prefsManager.userPreferences.value
            translationCoordinator.onAudioChunkCaptured(
                pcmData = pcmData,
                sampleRate = sampleRate,
                channels = channels,
                currentPlaybackPosMs = if (::exoPlayer.isInitialized) exoPlayer.currentPosition else 0L,
                apiKey = userPrefs.geminiApiKey
            )
        }

        // Initialize ExoPlayer with AudioProcessor pipeline attached
        val renderersFactory = object : DefaultRenderersFactory(this) {
            override fun buildAudioSink(
                context: android.content.Context,
                enableFloatOutput: Boolean,
                enableAudioTrackPlaybackParams: Boolean
            ): AudioSink {
                return DefaultAudioSink.Builder(context)
                    .setAudioProcessors(arrayOf(audioCaptureProcessor))
                    .build()
            }
        }

        exoPlayer = ExoPlayer.Builder(this, renderersFactory).build()

        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                audioDspManager.bindAudioSession(audioSessionId)
            }

            override fun onPositionDiscontinuity(
                oldPosition: androidx.media3.common.Player.PositionInfo,
                newPosition: androidx.media3.common.Player.PositionInfo,
                reason: Int
            ) {
                if (reason == androidx.media3.common.Player.DISCONTINUITY_REASON_SEEK) {
                    translationCoordinator.onSeekInvalidate()
                    audioCaptureProcessor.flush()
                }
            }
        })

        // Subtitle sync loop
        lifecycleScope.launch {
            while (true) {
                if (::exoPlayer.isInitialized && exoPlayer.isPlaying) {
                    translationCoordinator.onPlaybackPositionChanged(exoPlayer.currentPosition)
                }
                delay(150)
            }
        }

        setContent {
            ZelvynTheme {
                val userPrefs by prefsManager.userPreferences.collectAsState()
                var selectedTab by remember { mutableStateOf(AppTab.LIBRARY) }
                var activeVideo by remember { mutableStateOf<VideoItem?>(null) }
                var videoList by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var isViewingPrivacySubscreen by remember { mutableStateOf(false) }

                val activeSegment by translationCoordinator.activeSegment.collectAsState()
                val translationStatus by translationCoordinator.status.collectAsState()
                val translationStatusMsg by translationCoordinator.statusMessage.collectAsState()
                val isTranslationActive by translationCoordinator.isTranslationActive.collectAsState()

                LaunchedEffect(Unit) {
                    videoList = mediaStoreRepository.getLocalVideos()
                }

                if (!userPrefs.hasCompletedOnboarding) {
                    OnboardingScreen(
                        onFinished = { prefsManager.setOnboardingCompleted(true) }
                    )
                } else if (activeVideo != null) {
                    PlayerScreen(
                        exoPlayer = exoPlayer,
                        video = activeVideo!!,
                        activeSegment = activeSegment,
                        translationStatus = translationStatus,
                        translationStatusMsg = translationStatusMsg,
                        isTranslationActive = isTranslationActive,
                        audioDspManager = audioDspManager,
                        hardwareController = hardwareController,
                        subtitleFontSizeSp = userPrefs.subtitleFontSizeSp,
                        subtitleBgAlpha = userPrefs.subtitleBackgroundAlpha,
                        onBackPress = {
                            exoPlayer.stop()
                            audioCaptureProcessor.isCapturing = false
                            translationCoordinator.stopSession()
                            activeVideo = null
                            showSystemBars()
                        },
                        onToggleLiveTranslation = {
                            if (isTranslationActive) {
                                audioCaptureProcessor.isCapturing = false
                                translationCoordinator.stopSession()
                            } else {
                                audioCaptureProcessor.isCapturing = true
                                translationCoordinator.startSession(
                                    source = "Auto Detect",
                                    target = userPrefs.defaultTargetLang,
                                    apiKey = userPrefs.geminiApiKey
                                )
                            }
                        }
                    )
                } else {
                    Scaffold(
                        bottomBar = {
                            ZelvynBottomNavBar(
                                selectedTab = selectedTab,
                                onTabSelected = {
                                    isViewingPrivacySubscreen = false
                                    selectedTab = it
                                }
                            )
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when {
                                isViewingPrivacySubscreen || selectedTab == AppTab.PRIVACY -> {
                                    PrivacyPolicyScreen(
                                        onBack = { isViewingPrivacySubscreen = false }
                                    )
                                }
                                selectedTab == AppTab.LIBRARY -> {
                                    LibraryScreen(
                                        videos = videoList,
                                        onVideoSelected = { video ->
                                            activeVideo = video
                                            hideSystemBars()
                                            exoPlayer.setMediaItem(MediaItem.fromUri(video.uri))
                                            exoPlayer.prepare()
                                            exoPlayer.play()
                                        }
                                    )
                                }
                                selectedTab == AppTab.TRANSLATE -> {
                                    TranslateScreen(
                                        translationCoordinator = translationCoordinator,
                                        apiKey = userPrefs.geminiApiKey,
                                        onNavigateSettings = { selectedTab = AppTab.SETTINGS }
                                    )
                                }
                                selectedTab == AppTab.SETTINGS -> {
                                    SettingsScreen(
                                        prefsManager = prefsManager,
                                        onNavigatePrivacy = { isViewingPrivacySubscreen = true }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onResume() {
        super.onResume()
        if (::exoPlayer.isInitialized) exoPlayer.play()
    }

    override fun onPause() {
        super.onPause()
        if (::exoPlayer.isInitialized) exoPlayer.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        audioDspManager.release()
        if (::exoPlayer.isInitialized) {
            exoPlayer.release()
        }
    }
}
