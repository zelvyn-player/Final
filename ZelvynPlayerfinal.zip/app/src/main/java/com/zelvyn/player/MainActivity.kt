package com.zelvyn.player

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import com.zelvyn.player.audio.AudioDspManager
import com.zelvyn.player.audio.DeviceHardwareController
import com.zelvyn.player.data.MediaStoreRepository
import com.zelvyn.player.data.TranslationCoordinator
import com.zelvyn.player.model.PlaylistItem
import com.zelvyn.player.model.VideoItem
import com.zelvyn.player.ui.cloud.CloudAndMoreScreen
import com.zelvyn.player.ui.library.LibraryScreen
import com.zelvyn.player.ui.navigation.AppTab
import com.zelvyn.player.ui.navigation.ZelvynBottomNavBar
import com.zelvyn.player.ui.player.PlayerScreen
import com.zelvyn.player.ui.theme.ZelvynTheme
import com.zelvyn.player.ui.translate.TranslateScreen
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var exoPlayer: ExoPlayer
    private lateinit var mediaStoreRepository: MediaStoreRepository
    private lateinit var hardwareController: DeviceHardwareController
    private val audioDspManager = AudioDspManager()
    private val translationCoordinator = TranslationCoordinator(lifecycleScope)

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        mediaStoreRepository = MediaStoreRepository(this)
        hardwareController = DeviceHardwareController(this)
        exoPlayer = ExoPlayer.Builder(this).build()

        exoPlayer.addListener(object : androidx.media3.common.Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                audioDspManager.bindAudioSession(audioSessionId)
            }
        })

        lifecycleScope.launch {
            while (true) {
                if (::exoPlayer.isInitialized && exoPlayer.isPlaying) {
                    translationCoordinator.onPlaybackPositionChanged(exoPlayer.currentPosition)
                }
                delay(150)
            }
        }

        setContent {
            ZelvynTheme {
                var selectedTab by remember { mutableStateOf(AppTab.LIBRARY) }
                var activeVideo by remember { mutableStateOf<VideoItem?>(null) }
                var videoList by remember { mutableStateOf<List<VideoItem>>(emptyList()) }
                var playlists by remember { mutableStateOf<List<PlaylistItem>>(emptyList()) }
                val activeSegment by translationCoordinator.activeSegment.collectAsState()

                LaunchedEffect(Unit) {
                    videoList = mediaStoreRepository.getLocalVideos()
                    playlists = mediaStoreRepository.getPlaylists()
                }

                if (activeVideo != null) {
                    PlayerScreen(
                        exoPlayer = exoPlayer,
                        video = activeVideo!!,
                        queue = videoList,
                        playlists = playlists,
                        activeSegment = activeSegment,
                        audioDspManager = audioDspManager,
                        hardwareController = hardwareController,
                        onBackPress = {
                            exoPlayer.stop()
                            activeVideo = null
                            showSystemBars()
                        },
                        onToggleLiveTranslation = {
                            if (translationCoordinator.isTranslationActive.value) {
                                translationCoordinator.stopSession()
                            } else {
                                translationCoordinator.startSession("English", "Spanish")
                            }
                        },
                        onSelectQueueItem = { nextVideo ->
                            activeVideo = nextVideo
                            exoPlayer.setMediaItem(MediaItem.fromUri(nextVideo.uri))
                            exoPlayer.prepare()
                            exoPlayer.play()
                        }
                    )
                } else {
                    Scaffold(
                        bottomBar = {
                            ZelvynBottomNavBar(
                                selectedTab = selectedTab,
                                onTabSelected = { selectedTab = it }
                            )
                        }
                    ) { innerPadding ->
                        Box(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(innerPadding)
                        ) {
                            when (selectedTab) {
                                AppTab.LIBRARY, AppTab.HOME -> {
                                    LibraryScreen(
                                        videos = videoList,
                                        onVideoSelected = { video ->
                                            activeVideo = video
                                            hideSystemBars()
                                            exoPlayer.setMediaItem(MediaItem.fromUri(video.uri))
                                            exoPlayer.prepare()
                                            exoPlayer.play()
                                        }
                                    )
                                }
                                AppTab.TRANSLATE -> {
                                    TranslateScreen()
                                }
                                AppTab.CLOUD -> {
                                    CloudAndMoreScreen("Cloud Sync & Features")
                                }
                                AppTab.MORE -> {
                                    CloudAndMoreScreen("Settings & Security")
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private fun hideSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        insetsController.hide(WindowInsetsCompat.Type.systemBars())
    }

    private fun showSystemBars() {
        WindowCompat.setDecorFitsSystemWindows(window, true)
        val insetsController = WindowCompat.getInsetsController(window, window.decorView)
        insetsController.show(WindowInsetsCompat.Type.systemBars())
    }

    override fun onResume() {
        super.onResume()
        if (::exoPlayer.isInitialized) exoPlayer.play()
    }

    override fun onPause() {
        super.onPause()
        if (::exoPlayer.isInitialized) exoPlayer.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        audioDspManager.release()
        if (::exoPlayer.isInitialized) {
            exoPlayer.release()
        }
    }
}