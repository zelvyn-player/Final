package com.zelvyn.player.ui.privacy

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zelvyn.player.ui.theme.*

@Composable
fun PrivacyPolicyScreen(
    onBack: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(CanvasDark)
            .statusBarsPadding()
            .padding(horizontal = 20.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Rounded.ArrowBack, contentDescription = "Back", tint = TextPrimary)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "Privacy Policy",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
            )
        }

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(14.dp),
            modifier = Modifier.fillMaxSize().padding(top = 8.dp, bottom = 24.dp)
        ) {
            item {
                Text(
                    text = "Last updated: August 2026",
                    fontSize = 12.sp,
                    color = TextTertiary
                )
            }

            item {
                PrivacySection(
                    title = "1. Local Playback & Media Storage",
                    body = "ZELVYN Player functions primarily as an offline, on-device media player. Video and audio files stored on your device are indexed locally using Android's MediaStore API and are never uploaded to our servers."
                )
            }

            item {
                PrivacySection(
                    title = "2. Audio Processing & Live Translation",
                    body = "When you explicitly activate the 'Translate' feature during playback, ZELVYN Player captures rolling segments of audio directly from the video stream. These audio segments are transmitted securely via HTTPS to Google's Gemini API for speech recognition and translation."
                )
            }

            item {
                PrivacySection(
                    title = "3. Gemini API & Data Retention",
                    body = "Audio data sent to the Gemini API is processed ephemerally to produce text transcripts and translations. No raw audio or transcripts are permanently stored on ZELVYN Player servers. Google processes this request according to Google's Generative AI Privacy terms."
                )
            }

            item {
                PrivacySection(
                    title = "4. Permissions Requested",
                    body = "• RECORD_AUDIO: Used exclusively to process playback dialogue when live translation is enabled.\n• READ_MEDIA_VIDEO: Required to discover and play local videos stored on your device.\n• INTERNET: Required to send translation requests to the Gemini API."
                )
            }

            item {
                PrivacySection(
                    title = "5. Contact & Data Deletion",
                    body = "You can delete all stored preferences and your API key at any time by clearing app data in Android Settings. For inquiries, contact privacy@zelvynplayer.app."
                )
            }
        }
    }
}

@Composable
fun PrivacySection(
    title: String,
    body: String
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(SurfaceSubtle)
            .padding(14.dp)
    ) {
        Text(text = title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = TextPrimary)
        Spacer(modifier = Modifier.height(6.dp))
        Text(text = body, fontSize = 12.sp, color = TextSecondary, lineHeight = 17.sp)
    }
}
